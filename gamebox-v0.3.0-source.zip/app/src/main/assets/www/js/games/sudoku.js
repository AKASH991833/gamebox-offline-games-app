(function(){
"use strict";
var SLUG="sudoku";
GB.shell({title:"Sudoku",chips:[{id:"score",label:"Mistakes"},{id:"best",label:"Best",value:GB.best(SLUG)||"-"}],
 rules:"<ul><li>Every row, column and 3x3 box must contain <b>1-9</b> exactly once.</li><li>Tap a cell, then a number. Wrong entries turn red and count as mistakes.</li><li>Related cells and matching numbers highlight to help you scan.</li><li>Harder grids and faster times score higher.</li></ul>"});
var solution,puzzle,given,sel=-1,mistakes=0,startedAt,acc=0,timerIv=null,diff="easy",done=false;
var HOLES={easy:38,medium:46,hard:52},MULT={easy:1,medium:1.6,hard:2.4};
function setChip(id,v){var e=document.getElementById(id);if(e)e.textContent=v;}
function elapsed(){return acc+(startedAt?Date.now()-startedAt:0);}
function tick(){if(!done)document.getElementById("status").textContent="Time: "+(((elapsed()/1000)|0))+"s - every row, column and box needs 1-9";}
function fullGrid(){var g=[];for(var i=0;i<81;i++)g.push(0);
 function ok(i,v){var r=(i/9)|0,c=i%9;
  for(var k=0;k<9;k++){if(g[r*9+k]===v||g[k*9+c]===v)return false;}
  var br=r-r%3,bc=c-c%3;
  for(var a=0;a<3;a++)for(var b=0;b<3;b++)if(g[(br+a)*9+bc+b]===v)return false;
  return true;}
 function fill(p){if(p===81)return true;
  var opts=[1,2,3,4,5,6,7,8,9].sort(function(){return Math.random()-0.5});
  for(var j=0;j<9;j++){if(ok(p,opts[j])){g[p]=opts[j];
   if(fill(p+1))return true;g[p]=0;}}return false;}
 fill(0);return g;}
function dig(g,holes){
 var p=g.slice(),idx=[];
 for(var i=0;i<81;i++)idx.push(i);
 idx.sort(function(){return Math.random()-0.5});
 function count(grid){
  var first=-1;for(var i=0;i<81;i++)if(!grid[i]){first=i;break;}
  if(first===-1)return 1;var n=0;
  for(var v=1;v<=9;v++){var r=(first/9)|0,c=first%9,okv=true;
   for(var k=0;k<9&&okv;k++){if(grid[r*9+k]===v||grid[k*9+c]===v)okv=false;}
   var br=r-r%3,bc=c-c%3;
   for(var a=0;a<3&&okv;a++)for(var b=0;b<3;b++)
    if(grid[(br+a)*9+bc+b]===v){okv=false;break;}
   if(okv){grid[first]=v;n+=count(grid);grid[first]=0;if(n>1)return n;}}
  return n;}
 var removed=0;
 for(var t=0;t<idx.length&&removed<holes;t++){
  var i=idx[t],bak=p[i];p[i]=0;
  var cp=p.slice();if(count(cp)!==1)p[i]=bak;else removed++;}
 return p;}
function start(){
 if(timerIv)clearInterval(timerIv);
 document.getElementById("status").textContent="Building a puzzle...";
 setTimeout(function(){
  solution=fullGrid();puzzle=dig(solution,HOLES[diff]);
  given=puzzle.map(function(v){return v!==0});
  sel=-1;mistakes=0;startedAt=Date.now();acc=0;done=false;
  setChip("score",0);setChip("best",GB.best(SLUG)||"-");
  timerIv=setInterval(tick,1000);tick();
  var pad=document.getElementById("pad");pad.innerHTML="";
  for(var n=1;n<=9;n++){(function(n){
   var b=document.createElement("button");b.className="pbtn";b.textContent=n;
   b.addEventListener("click",function(){enter(n);});pad.appendChild(b);})(n);}
  var e=document.createElement("button");e.className="pbtn";e.textContent="\u00D7";
  e.addEventListener("click",function(){enter(0);});pad.appendChild(e);
  render();},30);}
function render(){
 var b=document.getElementById("board");b.innerHTML="";
 var selR=sel>=0?(sel/9)|0:-1,selC=sel>=0?sel%9:-1;
 var selV=sel>=0?puzzle[sel]:0;
 for(var i=0;i<81;i++){(function(i){
  var el=document.createElement("button");
  var r=(i/9)|0,c=i%9,rel=sel>=0&&(r===selR||c===selC||((r/3)|0)===((selR/3)|0)&&((c/3)|0)===((selC/3)|0));
  el.className="sq"+(given[i]?" given":"")+(i===sel?" sel":rel?" rel":"")+(!given[i]&&selV&&puzzle[i]===selV&&i!==sel?" same":"");
  if(puzzle[i])el.textContent=puzzle[i];
  if(!given[i]&&puzzle[i]&&puzzle[i]!==solution[i])el.classList.add("bad");
  el.addEventListener("click",function(){if(!given[i]){sel=i;GB.sfx.flip();render();}});
  b.appendChild(el);})(i);}}
function enter(n){
 if(sel<0||given[sel]||done)return;
 puzzle[sel]=n;GB.sfx.tap();
 if(n&&n!==solution[sel]){mistakes++;setChip("score",mistakes);GB.sfx.hit();GB.buzz(40);}
 render();
 if(puzzle.every(function(v,i){return v===solution[i]})){
  done=true;if(timerIv)clearInterval(timerIv);
  var secs=(elapsed()/1000)|0;
  var score=Math.max(10,Math.round((1200-secs-mistakes*50)*MULT[diff]));
  GB.saveBest(SLUG,score);setChip("best",GB.best(SLUG));GB.buzz(60);
  GB.gameOver({title:"Solved!",won:true,
   sub:"Time "+secs+"s, "+mistakes+" mistakes ("+diff+") - Score: <b>"+score+"</b>",
   again:"New Puzzle",onAgain:start});}}
var segEl=document.getElementById("diffSeg");
segEl.querySelectorAll("button").forEach(function(b){
 b.addEventListener("click",function(){
  segEl.querySelectorAll("button").forEach(function(x){x.classList.remove("on")});
  b.classList.add("on");diff=b.getAttribute("data-d");GB.sfx.tap();start();});});
GB.game.restart=start;
GB.onPauseChange(function(p){
 if(p){if(startedAt){acc+=Date.now()-startedAt;startedAt=null;}
  if(timerIv){clearInterval(timerIv);timerIv=null;}}
 else{if(!done){if(!startedAt)startedAt=Date.now();
  if(!timerIv)timerIv=setInterval(tick,1000);}}});
start();
})();
