(function(){
"use strict";
var GAMES=[
 {slug:"2048",    name:"2048",         cat:"Puzzle"},
 {slug:"snake",   name:"Snake Rush",   cat:"Arcade"},
 {slug:"tictactoe",name:"Tic Tac Toe", cat:"Puzzle"},
 {slug:"memory",  name:"Memory Match", cat:"Puzzle"},
 {slug:"mines",   name:"Mine Sweeper", cat:"Puzzle"},
 {slug:"breakout",name:"Brick Breaker",cat:"Arcade"},
 {slug:"flappy",  name:"Flappy Dot",   cat:"Arcade"},
 {slug:"sudoku",  name:"Sudoku",       cat:"Puzzle"},
 {slug:"stack",   name:"Tower Stack",  cat:"Arcade"},
 {slug:"mole",    name:"Mole Smash",   cat:"Action"},
 {slug:"simon",   name:"Beat Echo",    cat:"Action"},
 {slug:"pong",    name:"Paddle Clash", cat:"Action"}
];
var $=function(s){return document.querySelector(s)};
var store={
  get:function(k,d){try{var v=localStorage.getItem("gb_"+k);return v===null?d:JSON.parse(v)}catch(e){return d}},
  set:function(k,v){try{localStorage.setItem("gb_"+k,JSON.stringify(v))}catch(e){}}
};
/* theme */
function applyTheme(){var qp=new URLSearchParams(location.search).get("theme");if(qp==="light"||qp==="dark")store.set("theme",qp);document.documentElement.setAttribute("data-theme",store.get("theme","dark"));}
applyTheme();
$("#themeBtn").addEventListener("click",function(){
  store.set("theme",store.get("theme","dark")==="dark"?"light":"dark");applyTheme();
});
/* favorites */
var favs=store.get("favs",{});
function saveFavs(){store.set("favs",favs);}
var tab="all";
function heartSvg(on){return '<svg viewBox="0 0 24 24" class="ic"><path d="M12 21C7 16.5 3 13.1 3 9.3 3 6.4 5.2 4.5 7.7 4.5c1.7 0 3.3.9 4.3 2.4 1-1.5 2.6-2.4 4.3-2.4 2.5 0 4.7 1.9 4.7 4.8 0 3.8-4 7.2-9 11.7z" fill="'+(on?'currentColor':'none')+'" stroke="currentColor" stroke-width="2"/></svg>';}
function render(){
  var grid=$("#grid");grid.innerHTML="";
  var list=GAMES.filter(function(g){return tab==="all"||favs[g.slug];});
  $("#emptyFav").classList.toggle("hidden",!(tab==="fav"&&list.length===0));
  list.forEach(function(g){
    var card=document.createElement("div");card.className="card";card.style.animationDelay=(list.indexOf(g)*0.03)+"s";
    var img=document.createElement("img");img.className="cover";img.alt=g.name;img.src="icons/"+g.slug+".svg";
    var fav=document.createElement("button");fav.className="fav-btn"+(favs[g.slug]?" on":"");fav.innerHTML=heartSvg(!!favs[g.slug]);
    fav.addEventListener("click",function(e){e.stopPropagation();favs[g.slug]=!favs[g.slug];if(!favs[g.slug])delete favs[g.slug];saveFavs();render();});
    var nm=document.createElement("div");nm.className="name";nm.textContent=g.name;
    var ct=document.createElement("div");ct.className="cat";ct.textContent=g.cat;
    card.appendChild(img);card.appendChild(fav);card.appendChild(nm);card.appendChild(ct);
    card.addEventListener("click",function(){location.href="games/"+g.slug+".html";});
    grid.appendChild(card);
  });
}
$("#tabAll").addEventListener("click",function(){tab="all";$("#tabAll").classList.add("active");$("#tabFav").classList.remove("active");render();});
$("#tabFav").addEventListener("click",function(){tab="fav";$("#tabFav").classList.add("active");$("#tabAll").classList.remove("active");render();});
/* share + no ads */
$("#shareBtn").addEventListener("click",function(){
  var text="GameBox - 12 offline games in one tiny app. No internet needed, no ads!";
  if(window.AndroidBridge&&AndroidBridge.share){AndroidBridge.share(text);}
  else if(navigator.clipboard){navigator.clipboard.writeText(text);note("Share text copied");}
  else{note(text);}
});
$("#noadsBtn").addEventListener("click",function(){note("100% free. No ads, no internet needed.");});
function note(msg){
  if(window.AndroidBridge&&AndroidBridge.toast){AndroidBridge.toast(msg);return;}
  var t=document.createElement("div");t.textContent=msg;
  t.style.cssText="position:fixed;left:50%;bottom:100px;transform:translateX(-50%);background:var(--pill);color:var(--text);padding:10px 18px;border-radius:999px;font-size:13px;z-index:99;border:1px solid var(--pill-border)";
  document.body.appendChild(t);setTimeout(function(){t.remove()},2000);
}
/* scores */
$("#trophyBtn").addEventListener("click",function(){
  var list=$("#scoresList");list.innerHTML="";
  GAMES.forEach(function(g){
    var v=store.get("best_"+g.slug,null);
    var row=document.createElement("div");row.className="score-row";
    row.innerHTML='<img src="icons/'+g.slug+'.svg" alt=""><div class="sn">'+g.name+'</div><div class="sv'+(v===null?" none":"")+'">'+(v===null?"Not played":v)+'</div>';
    list.appendChild(row);
  });
  $("#scoresOverlay").classList.remove("hidden");
});
$("#scoresClose").addEventListener("click",function(){$("#scoresOverlay").classList.add("hidden");});
$("#scoresOverlay").addEventListener("click",function(e){if(e.target===this)this.classList.add("hidden");});
render();
})();
