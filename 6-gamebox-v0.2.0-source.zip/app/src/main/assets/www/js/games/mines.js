(function(){
"use strict";
var SLUG="mines",N=9,MINES=10;
GB.shell({title:"Mine Sweeper",chips:[{id:"left",label:"Mines",value:MINES},{id:"best",label:"Best",value:GB.best(SLUG)||"-"}],
 rules:"<ul><li><b>Tap</b> a cell to reveal it. Numbers count nearby mines.</li><li><b>Long-press</b> (or turn Flag mode on) to mark a suspected mine.</li><li>Your first tap is always safe.</li><li>Reveal every safe cell to win. Faster clears score higher.</li></ul>"});
var cells,flags,rev,over=false,flagMode=false,started=false,startedAt,acc=0,timerIv=null;
var boardEl=document.getElementById("board");
function setChip(id,v){var e=document.getElementById(id);if(e)e.textContent=v;}
function nb(i){var r=(i/N)|0,c=i%N,out=[];
 for(var dr=-1;dr<=1;dr++)for(var dc=-1;dc<=1;dc++){if(!dr&&!dc)continue;
  var rr=r+dr,cc=c+dc;if(rr>=0&&cc>=0&&rr<N&&cc<N)out.push(rr*N+cc);}return out;}
function start(){
 if(timerIv)clearInterval(timerIv);
 cells=Array(N*N).fill(0);flags={};rev={};over=false;started=false;startedAt=null;acc=0;
 setChip("left",MINES);setChip("best",GB.best(SLUG)||"-");render();}
function placeMines(safeIdx){
 var placed=0;
 while(placed<MINES){var i=(Math.random()*N*N)|0;
  if(i===safeIdx||cells[i]==="M")continue;
  if(nb(safeIdx).indexOf(i)>=0&&Math.random()<0.5)continue;
  cells[i]="M";placed++;}
 for(var i=0;i<N*N;i++){if(cells[i]==="M")continue;var n=0;
  nb(i).forEach(function(j){if(cells[j]==="M")n++;});cells[i]=n;}}
function render(){
 boardEl.innerHTML="";
 for(var i=0;i<N*N;i++){(function(i){
  var el=document.createElement("button");el.className="mcell";
  if(rev[i]){el.classList.add("rev");
   if(cells[i]==="M"){el.classList.add("mine");el.textContent="\u{1F4A5}";}
   else if(cells[i]>0){el.textContent=cells[i];el.classList.add("n"+cells[i]);}}
  else if(flags[i]){el.classList.add("flag");el.textContent="\u{1F6A9}";}
  var lp=null;
  el.addEventListener("touchstart",function(){lp=setTimeout(function(){lp=null;toggleFlag(i);},480);},{passive:true});
  el.addEventListener("touchend",function(e){if(lp){clearTimeout(lp);lp=null;tap(i);}e.preventDefault();});
  el.addEventListener("contextmenu",function(e){e.preventDefault();toggleFlag(i);});
  el.addEventListener("click",function(){tap(i);});
  boardEl.appendChild(el);})(i);}}
function toggleFlag(i){
 if(over||rev[i])return;
 flags[i]=!flags[i];if(!flags[i])delete flags[i];
 GB.sfx.flip();GB.buzz(20);
 setChip("left",MINES-Object.keys(flags).length);render();}
function tap(i){
 if(over||rev[i]||flags[i])return;
 if(flagMode){toggleFlag(i);return;}
 if(!started){started=true;placeMines(i);startedAt=Date.now();timerIv=setInterval(tick,1000);tick();}
 if(cells[i]==="M"){boom(i);return;}
 GB.sfx.tap();flood(i);render();checkWin();}
function tick(){setChip("left",MINES-Object.keys(flags).length);}
function flood(i){var st=[i];
 while(st.length){var k=st.pop();if(rev[k]||flags[k])continue;rev[k]=true;
  if(cells[k]===0)nb(k).forEach(function(j){if(!rev[j]&&!flags[j])st.push(j);});}}
function boom(i){
 over=true;if(timerIv)clearInterval(timerIv);
 for(var j=0;j<N*N;j++)if(cells[j]==="M")rev[j]=true;
 rev[i]=true;render();GB.buzz(120);
 GB.gameOver({title:"Boom!",sub:"You hit a mine. Try again - the next board is one tap away.",again:"New Game",onAgain:start});}
function checkWin(){
 var hidden=0;for(var i=0;i<N*N;i++)if(!rev[i])hidden++;
 if(hidden===MINES){over=true;if(timerIv)clearInterval(timerIv);
  var secs=((acc+(startedAt?Date.now()-startedAt:0))/1000)|0;
  var score=Math.max(10,999-secs);
  GB.saveBest(SLUG,score);setChip("best",GB.best(SLUG));GB.buzz(60);
  GB.gameOver({title:"You Win!",won:true,sub:"Cleared in "+secs+"s - Score: <b>"+score+"</b>",again:"New Game",onAgain:start});}}
document.getElementById("flagBtn").addEventListener("click",function(){
 flagMode=!flagMode;this.classList.toggle("on",flagMode);
 this.textContent="Flag: "+(flagMode?"ON":"OFF");GB.sfx.tap();});
document.getElementById("restart").addEventListener("click",function(){GB.sfx.tap();start();});
GB.game.restart=start;
GB.onPauseChange(function(p){
 if(p){if(startedAt){acc+=Date.now()-startedAt;startedAt=null;}if(timerIv){clearInterval(timerIv);timerIv=null;}}
 else{if(started&&!startedAt&&!over){startedAt=Date.now();timerIv=setInterval(tick,1000);}}});
start();
})();
