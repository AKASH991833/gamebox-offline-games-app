(function(){
"use strict";
var SLUG="bubbles",W=360,H=560,R=16,COLS=11,TOP=36,MARGIN=(W-COLS*2*R)/2;
var SX=W/2,SY=H-46;
var cv=document.getElementById("cv"),ctx=GB.ctx(cv,W,H);
GB.shell({title:"Bubble Pop",chips:[{id:"score",label:"Score"},{id:"best",label:"Best",value:GB.best(SLUG)},{id:"shots",label:"Row In"}],
 rules:"<ul><li><b>Drag</b> to aim, release to shoot the bubble.</li><li>Groups of <b>3 or more</b> of the same color pop. Anything left hanging drops for bonus points.</li><li>Pop 10 points each, drops 20 each.</li><li>Every 6 shots a new row pushes in from the top. If bubbles cross the dashed line, the run ends.</li></ul>"});
var COLORS=["#F43F5E","#FACC15","#4ADE80","#22D3EE","#C084FC"];
var grid,cur,next,flying,aim,score,shots,alive;
function setChip(id,v){var e=document.getElementById(id);if(e)e.textContent=v;}
function key(r,c){return r+","+c;}
function cellXY(r,c){return{x:MARGIN+R+c*2*R+(r%2)*R,y:TOP+r*R*1.72+R};}
function neighbors(r,c){
 return r%2?[[r-1,c],[r-1,c+1],[r,c-1],[r,c+1],[r+1,c],[r+1,c+1]]
           :[[r-1,c-1],[r-1,c],[r,c-1],[r,c+1],[r+1,c-1],[r+1,c]];}
function presentColors(){var s={};Object.keys(grid).forEach(function(k){s[grid[k]]=1;});
 var a=Object.keys(s);return a.length?a:COLORS;}
function pickColor(){var a=presentColors();return a[(Math.random()*a.length)|0];}
function start(){
 grid={};
 for(var r=0;r<5;r++)for(var c=0;c<COLS;c++){
  if(r%2&&c===COLS-1)continue;
  grid[key(r,c)]=COLORS[(Math.random()*COLORS.length)|0];}
 cur=pickColor();next=pickColor();flying=null;aim=-Math.PI/2;score=0;shots=6;alive=true;
 setChip("score",0);setChip("best",GB.best(SLUG));setChip("shots",shots);draw();}
function cluster(r,c,color){
 var seen={},stack=[[r,c]],out=[];
 while(stack.length){var n=stack.pop(),k=key(n[0],n[1]);
  if(seen[k]||grid[k]!==color)continue;seen[k]=1;out.push(k);
  neighbors(n[0],n[1]).forEach(function(m){stack.push(m);});}
 return out;}
function dropFloating(){
 var seen={},stack=[];
 Object.keys(grid).forEach(function(k){
  if(parseInt(k,10)===0)stack.push(k.split(",").map(Number));});
 while(stack.length){var n=stack.pop(),k=key(n[0],n[1]);
  if(seen[k]||!grid[k])continue;seen[k]=1;
  neighbors(n[0],n[1]).forEach(function(m){stack.push(m);});}
 var dropped=0;
 Object.keys(grid).forEach(function(k){if(!seen[k]){delete grid[k];dropped++;}});
 return dropped;}
function snap(x,y){
 var best=null,bd=1e9;
 for(var r=0;r<16;r++)for(var c=0;c<COLS;c++){
  if(grid[key(r,c)])continue;
  if(r%2&&c===COLS-1)continue;
  var p=cellXY(r,c),d=(p.x-x)*(p.x-x)+(p.y-y)*(p.y-y);
  if(d<bd){bd=d;best=[r,c];}}
 return best;}
function addScore(p){score+=p;setChip("score",score);
 if(score>GB.best(SLUG)){GB.saveBest(SLUG,score);setChip("best",score);}}
function pushRow(){
 var ng={},nk=key;
 Object.keys(grid).forEach(function(k){
  var parts=k.split(","),r=+parts[0]+1,c=+parts[1];
  if(r%2&&c===COLS-1)return;
  ng[nk(r,c)]=grid[k];});
 grid=ng;
 for(var c=0;c<COLS;c++)grid[key(0,c)]=COLORS[(Math.random()*COLORS.length)|0];
 if(overflow()){alive=false;GB.saveBest(SLUG,score);GB.sfx.die();
  GB.gameOver({title:"Game Over",sub:"Score: <b>"+score+"</b> &nbsp; Best: <b>"+GB.best(SLUG)+"</b>",onAgain:start});}}
function overflow(){
 var line=SY-3*R;
 return Object.keys(grid).some(function(k){
  var parts=k.split(",");return cellXY(+parts[0],+parts[1]).y>line;});}
function fire(){
 if(!alive||flying)return;
 flying={x:SX,y:SY,vx:Math.cos(aim)*560,vy:Math.sin(aim)*560,color:cur};
 GB.sfx.flip();}
function step(dt){
 if(!alive)return;
 if(!flying)return;
 flying.x+=flying.vx*dt;flying.y+=flying.vy*dt;
 if(flying.x<R+2){flying.x=R+2;flying.vx*=-1;}
 if(flying.x>W-R-2){flying.x=W-R-2;flying.vx*=-1;}
 var hit=flying.y<TOP+R;
 if(!hit){var keys=Object.keys(grid);
  for(var i=0;i<keys.length;i++){
   var parts=keys[i].split(","),p=cellXY(+parts[0],+parts[1]);
   var dx=p.x-flying.x,dy=p.y-flying.y;
   if(dx*dx+dy*dy<(2*R-3)*(2*R-3)){hit=true;break;}}}
 if(hit){
  var cell=snap(flying.x,flying.y);
  if(!cell){flying=null;return;}
  grid[key(cell[0],cell[1])]=flying.color;
  var cl=cluster(cell[0],cell[1],flying.color);
  if(cl.length>=3){
   cl.forEach(function(k){delete grid[k];});
   addScore(cl.length*10);
   var dropped=dropFloating();
   if(dropped)addScore(dropped*20);
   GB.sfx.point();GB.buzz(15);}
  else GB.sfx.hit();
  shots--;
  if(shots<=0){shots=6;pushRow();}
  setChip("shots",shots);
  if(alive&&overflow()){alive=false;GB.saveBest(SLUG,score);GB.sfx.die();
   GB.gameOver({title:"Game Over",sub:"Score: <b>"+score+"</b> &nbsp; Best: <b>"+GB.best(SLUG)+"</b>",onAgain:start});}
  if(alive&&Object.keys(grid).length===0){
   addScore(250);GB.sfx.win();
   for(var r=0;r<4;r++)for(var c=0;c<COLS;c++){
    if(r%2&&c===COLS-1)continue;
    grid[key(r,c)]=COLORS[(Math.random()*COLORS.length)|0];}
   GB.toast("Board cleared! +250");}
  flying=null;
  if(alive){cur=next;next=pickColor();}}}
function draw(){
 ctx.fillStyle=GB.isDark()?"#1E1338":"#EFE9FB";ctx.fillRect(0,0,W,H);
 ctx.setLineDash([6,6]);
 ctx.strokeStyle=GB.isDark()?"rgba(255,77,109,.55)":"rgba(244,63,94,.55)";ctx.lineWidth=2;
 ctx.beginPath();ctx.moveTo(8,SY-3*R);ctx.lineTo(W-8,SY-3*R);ctx.stroke();
 ctx.setLineDash([]);
 Object.keys(grid).forEach(function(k){
  var parts=k.split(","),p=cellXY(+parts[0],+parts[1]);
  ctx.fillStyle=grid[k];ctx.beginPath();ctx.arc(p.x,p.y,R-1.5,0,7);ctx.fill();
  ctx.fillStyle="rgba(255,255,255,.28)";ctx.beginPath();ctx.arc(p.x-5,p.y-5,4.5,0,7);ctx.fill();});
 if(alive&&!flying){
  ctx.strokeStyle=GB.isDark()?"rgba(255,255,255,.5)":"rgba(36,22,64,.4)";
  ctx.lineWidth=2.5;ctx.setLineDash([2,9]);
  ctx.beginPath();ctx.moveTo(SX,SY);
  var ex=SX+Math.cos(aim)*70,ey=SY+Math.sin(aim)*70;
  ctx.lineTo(ex,ey);ctx.stroke();ctx.setLineDash([]);}
 ctx.fillStyle=cur;ctx.beginPath();ctx.arc(SX,SY,R-1,0,7);ctx.fill();
 ctx.fillStyle="rgba(255,255,255,.3)";ctx.beginPath();ctx.arc(SX-5,SY-5,4.5,0,7);ctx.fill();
 if(flying){ctx.fillStyle=flying.color;ctx.beginPath();ctx.arc(flying.x,flying.y,R-1.5,0,7);ctx.fill();}
 ctx.fillStyle=next;ctx.beginPath();ctx.arc(SX+52,SY+6,9,0,7);ctx.fill();
 ctx.fillStyle=GB.isDark()?"rgba(255,255,255,.5)":"rgba(36,22,64,.5)";
 ctx.font="11px sans-serif";ctx.fillText("next",SX+38,SY+26);}
GB.loop(step,draw);
function pointTo(clientX,clientY){
 var r=cv.getBoundingClientRect();
 var x=(clientX-r.left)*(W/r.width),y=(clientY-r.top)*(H/r.height);
 var a=Math.atan2(y-SY,x-SX);
 var lim=0.25;
 if(a>-lim&&a<Math.PI/2)a=-lim;
 if(a>=Math.PI/2||a<-Math.PI+lim)a=-Math.PI+lim;
 aim=a;}
cv.addEventListener("touchstart",function(e){pointTo(e.touches[0].clientX,e.touches[0].clientY);},{passive:true});
cv.addEventListener("touchmove",function(e){e.preventDefault();pointTo(e.touches[0].clientX,e.touches[0].clientY);},{passive:false});
cv.addEventListener("touchend",function(){fire();});
cv.addEventListener("mousemove",function(e){pointTo(e.clientX,e.clientY);});
cv.addEventListener("click",function(){fire();});
document.addEventListener("keydown",function(e){
 if(e.key==="ArrowLeft"){e.preventDefault();aim=Math.max(-Math.PI+0.25,aim-0.07);}
 else if(e.key==="ArrowRight"){e.preventDefault();aim=Math.min(-0.25,aim+0.07);}
 else if(e.key===" "||e.key==="ArrowUp"){e.preventDefault();fire();}});
GB.game.restart=start;
start();
})();
