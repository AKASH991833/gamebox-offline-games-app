(function(){
"use strict";
var SLUG="wordguess";
GB.shell({title:"Word Guess",pausable:false,chips:[{id:"score",label:"Streak"},{id:"best",label:"Best",value:GB.best(SLUG)}],
 rules:"<ul><li>Guess the hidden word one <b>letter</b> at a time.</li><li>Each wrong letter adds a body part to the gallows - <b>6 wrong</b> and the round is lost.</li><li>The category line is your hint.</li><li>Win rounds in a row to build your streak.</li></ul>"});
var WORDS=[
 ["ANIMALS","TIGER ELEPHANT GIRAFFE MONKEY DOLPHIN PENGUIN RABBIT LEOPARD KANGAROO SQUIRREL"],
 ["FOOD","PIZZA BURGER PASTA BIRYANI SANDWICH CHOCOLATE PANCAKE NOODLES SAMOSA MANGO"],
 ["SPORTS","CRICKET FOOTBALL TENNIS BADMINTON HOCKEY BOXING SWIMMING CYCLING KABADDI ARCHERY"],
 ["COUNTRIES","INDIA JAPAN BRAZIL CANADA FRANCE GERMANY EGYPT AUSTRALIA MEXICO NORWAY"],
 ["TECH","LAPTOP MOBILE CAMERA ROBOT ROCKET SATELLITE PRINTER BATTERY CHARGER KEYBOARD"],
 ["NATURE","RIVER MOUNTAIN FOREST DESERT OCEAN VALLEY ISLAND SUNSET THUNDER RAINBOW"]];
var word,cat,guessed,wrong,streak=0,over;
var wordEl=document.getElementById("word"),kbEl=document.getElementById("kb"),
    catEl=document.getElementById("cat"),bodyEl=document.getElementById("body");
function setChip(id,v){var e=document.getElementById(id);if(e)e.textContent=v;}
var PARTS=[
 '<circle cx="74" cy="40" r="12"/>',
 '<path d="M74 52 V84"/>',
 '<path d="M74 58 L58 72"/>',
 '<path d="M74 58 L90 72"/>',
 '<path d="M74 84 L60 104"/>',
 '<path d="M74 84 L88 104"/>'];
function start(){
 var pick=WORDS[(Math.random()*WORDS.length)|0];
 cat=pick[0];
 var list=pick[1].split(" ");
 word=list[(Math.random()*list.length)|0];
 guessed={};wrong=0;over=false;
 catEl.textContent=cat;
 bodyEl.innerHTML="";
 setChip("score",streak);setChip("best",GB.best(SLUG));
 renderWord();renderKb();}
function renderWord(){
 wordEl.innerHTML="";
 word.split("").forEach(function(ch){
  var d=document.createElement("div");d.className="ltr";
  d.textContent=guessed[ch]?ch:"";
  wordEl.appendChild(d);});}
function renderKb(){
 kbEl.innerHTML="";
 "ABCDEFGHIJKLMNOPQRSTUVWXYZ".split("").forEach(function(ch){
  var b=document.createElement("button");b.textContent=ch;
  if(guessed[ch]){b.disabled=true;b.className=word.indexOf(ch)>=0?"good":"bad";}
  b.addEventListener("click",function(){guess(ch);});
  kbEl.appendChild(b);});}
function guess(ch){
 if(over||guessed[ch])return;
 guessed[ch]=1;
 if(word.indexOf(ch)>=0){GB.sfx.flip();}
 else{wrong++;GB.sfx.hit();GB.buzz(25);
  bodyEl.innerHTML=PARTS.slice(0,wrong).join("");}
 renderWord();renderKb();
 var won=word.split("").every(function(c){return guessed[c];});
 if(won){over=true;streak++;GB.saveBest(SLUG,streak);
  setChip("score",streak);setChip("best",GB.best(SLUG));
  GB.sfx.win();GB.buzz(40);
  GB.gameOver({title:"You Got It!",won:true,
   sub:"The word was <b>"+word+"</b> &nbsp; Streak: <b>"+streak+"</b>",
   again:"Next Word",onAgain:start});return;}
 if(wrong>=6){over=true;streak=0;setChip("score",0);
  GB.sfx.die();GB.buzz(80);
  GB.gameOver({title:"Out of Tries",
   sub:"The word was <b>"+word+"</b>",
   again:"Try Again",onAgain:start});}}
document.addEventListener("keydown",function(e){
 var k=e.key.toUpperCase();
 if(/^[A-Z]$/.test(k))guess(k);});
GB.game.pausable=false;
start();
})();
