(function(){
"use strict";
var SLUG="runner",W=360,H=520,GROUND=H-70;
var cv=document.getElementById("cv"),ctx=GB.ctx(cv,W,H);
GB.shell({title:"Dash Runner",chips:[{id:"score",label:"Score"},{id:"best",label:"Best",value:GB.best(SLUG)}],
 rules:"<ul><li><b>Tap</b> to jump. Tap again in the air for a <b>double jump</b>.</li><li><b>Swipe down</b> to duck under flying drones.</li><li>Blocks must be jumped, drones must be ducked (or jumped early).</li><li>Speed keeps rising. Score is distance in meters.</li></ul>"});
var py,vy,jumps,ducking,obstacles,speed,dist,alive,clouds,spawnT,runT;
function setChip(id,v){var e=document.getElementById(id);if(e)e.textContent=v;}
function start(){
 py=GROUND;vy=0;jumps=0;ducking=false;obstacles=[];speed=230;dist=0;alive=true;spawnT=1.1;runT=0;
 clouds=[];for(var i=0;i<5;i++)clouds.push({x:Math.random()*W,y:30+Math.random()*90,s:14+Math.random()*16,v:8+Math.random()*10});
 setChip("score",0);setChip("best",GB.best(SLUG));draw();}
function jump(){if(!alive)return;
 if(jumps<2){vy=-560;if(jumps===1)vy=-500;jumps++;ducking=false;GB.sfx.flip();}}
function duck(){if(!alive)return;
 if(py<GROUND){vy=Math.max(vy,500);}
 ducking=true;setTimeout(function(){ducking=false;},450);}
function spawn(){
 var flying=Math.random()<0.35&&dist>80;
 if(flying)obstacles.push({x:W+30,y:GROUND-88,w:34,h:22,fly:true});
 else{var w=18+Math.random()*22;obstacles.push({x:W+30,y:GROUND,w:w,h:34+Math.random()*30,fly:false});}}
function step(dt){
 clouds.forEach(function(c){c.x-=(c.v+speed*0.05)*dt;if(c.x<-40){c.x=W+40;c.y=30+Math.random()*90;}});
 if(!alive)return;
 runT+=dt;speed=230+Math.min(340,runT*9);
 dist+=speed*dt*0.06;
 var s=Math.floor(dist);setChip("score",s);
 if(s>GB.best(SLUG)){GB.saveBest(SLUG,s);setChip("best",s);}
 vy+=1650*dt;py+=vy*dt;
 if(py>=GROUND){py=GROUND;vy=0;jumps=0;}
 spawnT-=dt;
 if(spawnT<=0){spawn();spawnT=Math.max(0.55,1.15-speed*0.0009)+Math.random()*0.5;}
 obstacles.forEach(function(o){o.x-=speed*dt;});
 obstacles=obstacles.filter(function(o){return o.x>-60;});
 var ph=ducking?26:46,pw=26,px=62;
 for(var i=0;i<obstacles.length;i++){var o=obstacles[i];
  var oTop=o.fly?o.y:o.y-o.h,oBot=o.fly?o.y+o.h:o.y;
  if(px+pw>o.x+4&&px-pw<o.x+o.w-4&&py>oTop+4&&py-ph<oBot-4){
   alive=false;GB.saveBest(SLUG,Math.floor(dist));GB.sfx.die();GB.buzz(80);
   GB.gameOver({title:"Game Over",sub:"Distance: <b>"+Math.floor(dist)+"m</b> &nbsp; Best: <b>"+GB.best(SLUG)+"m</b>",onAgain:start});
   return;}}}
function draw(){
 var sky=GB.isDark()?"#1E1338":"#E9E2F8";
 ctx.fillStyle=sky;ctx.fillRect(0,0,W,H);
 ctx.fillStyle=GB.isDark()?"rgba(255,255,255,.16)":"rgba(36,22,64,.12)";
 clouds.forEach(function(c){ctx.beginPath();ctx.arc(c.x,c.y,c.s,0,7);ctx.arc(c.x+c.s,c.y+4,c.s*0.75,0,7);ctx.fill();});
 ctx.fillStyle=GB.isDark()?"#3B2A63":"#D3C6EC";ctx.fillRect(0,GROUND,W,H-GROUND);
 ctx.fillStyle=GB.isDark()?"rgba(255,255,255,.12)":"rgba(36,22,64,.12)";
 for(var gx=-((dist*40)%46);gx<W;gx+=46)ctx.fillRect(gx,GROUND+16,22,4);
 obstacles.forEach(function(o){
  if(o.fly){
   ctx.fillStyle="#F43F5E";ctx.beginPath();ctx.arc(o.x+o.w/2,o.y+o.h/2,o.w/2,0,7);ctx.fill();
   ctx.fillStyle="#fff";ctx.beginPath();ctx.arc(o.x+o.w/2+5,o.y+o.h/2-3,3.4,0,7);ctx.fill();
   ctx.strokeStyle="#F43F5E";ctx.lineWidth=3;
   var f=Math.sin(performance.now()/70)*4;
   ctx.beginPath();ctx.moveTo(o.x+4,o.y);ctx.lineTo(o.x-8,o.y-8+f);ctx.moveTo(o.x+o.w-4,o.y);ctx.lineTo(o.x+o.w+8,o.y-8-f);ctx.stroke();}
  else{
   ctx.fillStyle="#F59E0B";ctx.fillRect(o.x,o.y-o.h,o.w,o.h);
   ctx.fillStyle="#B45309";ctx.fillRect(o.x,o.y-o.h,o.w,6);}});
 var ph=ducking?26:46,px=62;
 ctx.fillStyle="#4ADE80";
 ctx.beginPath();
 if(ducking){ctx.roundRect?ctx.roundRect(px-26,py-26,52,26,10):ctx.rect(px-26,py-26,52,26);}
 else{ctx.roundRect?ctx.roundRect(px-15,py-46,30,46,10):ctx.rect(px-15,py-46,30,46);}
 ctx.fill();
 ctx.fillStyle="#14532D";
 ctx.beginPath();ctx.arc(px+(ducking?12:6),py-(ducking?18:36),3.2,0,7);ctx.fill();}
GB.loop(step,draw);
var stage=document.querySelector(".stage");
stage.addEventListener("touchstart",function(e){jump();},{passive:true});
stage.addEventListener("mousedown",function(){jump();});
GB.swipe(stage,function(d){if(d==="down")duck();},18);
document.addEventListener("keydown",function(e){
 if(e.key===" "||e.key==="ArrowUp"){e.preventDefault();jump();}
 else if(e.key==="ArrowDown"){e.preventDefault();duck();}});
GB.game.restart=start;
start();
})();
