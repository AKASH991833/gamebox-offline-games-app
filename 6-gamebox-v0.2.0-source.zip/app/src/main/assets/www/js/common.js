(function(){
"use strict";
var GB=window.GB={};

/* ---------- storage (keys compatible with v0.1.0) ---------- */
GB.store={get:function(k,d){try{var v=localStorage.getItem("gb_"+k);return v===null?d:JSON.parse(v)}catch(e){return d}},
          set:function(k,v){try{localStorage.setItem("gb_"+k,JSON.stringify(v))}catch(e){}}};
GB.saveBest=function(slug,val){var cur=GB.store.get("best_"+slug,null);if(cur===null||val>cur)GB.store.set("best_"+slug,val);};
GB.best=function(slug){return GB.store.get("best_"+slug,0);};

/* ---------- theme ---------- */
var qp=new URLSearchParams(location.search).get("theme");
if(qp==="light"||qp==="dark")GB.store.set("theme",qp);
document.documentElement.setAttribute("data-theme",GB.store.get("theme","dark"));
GB.isDark=function(){return document.documentElement.getAttribute("data-theme")!=="light";};

/* ---------- sound (tiny WebAudio synth, no assets) ---------- */
var AC=null;
GB.muted=GB.store.get("muted",false);
function ac(){if(!AC){try{AC=new (window.AudioContext||window.webkitAudioContext)();}catch(e){AC=null;}}
 if(AC&&AC.state==="suspended"){try{AC.resume();}catch(e){}}return AC;}
GB.tone=function(freq,dur,type,vol,slideTo){
 if(GB.muted)return;var c=ac();if(!c)return;
 try{var o=c.createOscillator(),g=c.createGain();o.type=type||"sine";
  o.frequency.setValueAtTime(freq,c.currentTime);
  if(slideTo)o.frequency.exponentialRampToValueAtTime(Math.max(1,slideTo),c.currentTime+dur);
  g.gain.setValueAtTime(vol||0.1,c.currentTime);
  g.gain.exponentialRampToValueAtTime(0.0001,c.currentTime+dur);
  o.connect(g);g.connect(c.destination);o.start();o.stop(c.currentTime+dur+0.02);}catch(e){}};
GB.sfx={
 tap:function(){GB.tone(660,0.06,"triangle",0.07);},
 flip:function(){GB.tone(440,0.05,"triangle",0.06);},
 point:function(){GB.tone(880,0.12,"sine",0.11,1320);},
 hit:function(){GB.tone(200,0.12,"square",0.09,80);},
 die:function(){GB.tone(320,0.35,"sawtooth",0.09,60);},
 win:function(){GB.tone(523,0.12,"triangle",0.11);setTimeout(function(){GB.tone(659,0.12,"triangle",0.11);},120);setTimeout(function(){GB.tone(784,0.22,"triangle",0.11);},240);}
};
GB.toggleMute=function(){GB.muted=!GB.muted;GB.store.set("muted",GB.muted);return GB.muted;};
GB.buzz=function(ms){try{if(navigator.vibrate)navigator.vibrate(ms);}catch(e){}};

/* ---------- pause system ---------- */
GB.paused=false;
GB.game={restart:null,pausable:true};
var pauseCbs=[];
GB.onPauseChange=function(fn){pauseCbs.push(fn);};
function setPaused(p){if(GB.paused===p)return;GB.paused=p;
 pauseCbs.forEach(function(f){try{f(p);}catch(e){}});updatePauseBtn();}

var pauseOv=null;
GB.pause=function(){if(!GB.game.pausable||GB.paused)return;setPaused(true);showPauseOv();};
GB.resume=function(){if(!GB.paused)return;setPaused(false);hidePauseOv();};
GB.togglePause=function(){if(GB.paused)GB.resume();else GB.pause();GB.sfx.tap();};

function showPauseOv(){hidePauseOv();
 pauseOv=el("div","gb-ov");var card=el("div","gb-card");
 card.appendChild(el("div","gb-ov-title","Paused"));
 var bR=el("button","gbtn primary","Resume");
 bR.addEventListener("click",function(){GB.sfx.tap();GB.resume();});
 var bN=el("button","gbtn","Restart");
 bN.addEventListener("click",function(){GB.sfx.tap();GB.resume();if(GB.game.restart)GB.game.restart();});
 var bH=el("button","gbtn","Home");
 bH.addEventListener("click",function(){GB.sfx.tap();location.href="../index.html";});
 card.appendChild(bR);card.appendChild(bN);card.appendChild(bH);
 pauseOv.appendChild(card);document.body.appendChild(pauseOv);}
function hidePauseOv(){if(pauseOv){pauseOv.remove();pauseOv=null;}}
document.addEventListener("visibilitychange",function(){
 if(document.hidden&&GB.game.pausable)GB.pause();});

/* ---------- rAF loop with delta time ---------- */
GB.loop=function(stepFn,drawFn){
 var last=performance.now(),raf=0,alive=true;
 function frame(now){if(!alive)return;
  var dt=(now-last)/1000;last=now;if(dt>0.05)dt=0.05;
  if(!GB.paused){stepFn(dt);if(drawFn)drawFn();}
  raf=requestAnimationFrame(frame);}
 raf=requestAnimationFrame(frame);
 return{stop:function(){alive=false;cancelAnimationFrame(raf);}};};

/* ---------- crisp canvas (devicePixelRatio aware) ---------- */
GB.ctx=function(cv,W,H){var dpr=Math.min(2,window.devicePixelRatio||1);
 cv.width=Math.round(W*dpr);cv.height=Math.round(H*dpr);
 var c=cv.getContext("2d");c.scale(dpr,dpr);return c;};

/* ---------- DOM helpers ---------- */
function el(tag,cls,html){var e=document.createElement(tag);if(cls)e.className=cls;if(html!==undefined)e.innerHTML=html;return e;}
GB.el=el;

var IC={
 back:'<svg viewBox="0 0 24 24" style="fill:none"><path d="M15 4l-8 8 8 8" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" fill="none"/></svg>',
 pause:'<svg viewBox="0 0 24 24"><path d="M7 5h4v14H7zM13 5h4v14h-4z"/></svg>',
 play:'<svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>',
 help:'<svg viewBox="0 0 24 24" style="fill:none"><path d="M9.2 9a3 3 0 1 1 4.6 2.5c-1 .7-1.8 1.3-1.8 2.5" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/><circle cx="12" cy="17.6" r="1.4" fill="currentColor"/></svg>',
 sndOn:'<svg viewBox="0 0 24 24"><path d="M4 9v6h4l5 4V5L8 9H4z"/><path d="M16 9a4 4 0 0 1 0 6M18.5 6.5a8 8 0 0 1 0 11" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round"/></svg>',
 sndOff:'<svg viewBox="0 0 24 24"><path d="M4 9v6h4l5 4V5L8 9H4z"/><path d="M16 9l6 6M22 9l-6 6" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round"/></svg>'
};
GB.icons=IC;

/* ---------- header shell ---------- */
var pauseBtn=null;
GB.shell=function(opts){
 opts=opts||{};
 var host=document.getElementById("gbh");if(!host)return;
 GB.game.pausable=opts.pausable!==false;
 var bar=el("div","gbar");
 var back=el("button","backbtn",IC.back);back.setAttribute("aria-label","Home");
 back.addEventListener("click",function(){GB.sfx.tap();location.href="../index.html";});
 bar.appendChild(back);
 var title=el("div","gtitle");title.textContent=opts.title||"";
 bar.appendChild(title);
 var chips=el("div","scorebox");
 (opts.chips||[]).forEach(function(c){
  var s=el("div","schip");s.innerHTML=c.label+' <b id="'+c.id+'">'+(c.value===undefined?0:c.value)+"</b>";chips.appendChild(s);});
 bar.appendChild(chips);
 var acts=el("div","gactions");
 if(GB.game.pausable){
  pauseBtn=el("button","icobtn",IC.pause);pauseBtn.setAttribute("aria-label","Pause");
  pauseBtn.addEventListener("click",function(){GB.togglePause();});
  acts.appendChild(pauseBtn);}
 var snd=el("button","icobtn",GB.muted?IC.sndOff:IC.sndOn);snd.setAttribute("aria-label","Sound");
 snd.addEventListener("click",function(){var m=GB.toggleMute();snd.innerHTML=m?IC.sndOff:IC.sndOn;if(!m)GB.sfx.tap();});
 acts.appendChild(snd);
 if(opts.rules){
  var help=el("button","icobtn",IC.help);help.setAttribute("aria-label","How to play");
  help.addEventListener("click",function(){GB.sfx.tap();GB.showRules(opts.rules);});
  acts.appendChild(help);}
 bar.appendChild(acts);
 host.appendChild(bar);
};
function updatePauseBtn(){if(pauseBtn)pauseBtn.innerHTML=GB.paused?IC.play:IC.pause;}

/* ---------- rules overlay ---------- */
GB.showRules=function(html){
 var wasPaused=GB.paused;
 if(GB.game.pausable&&!wasPaused)setPaused(true);
 var ov=el("div","gb-ov");var card=el("div","gb-card");
 card.appendChild(el("div","gb-ov-title","How to Play"));
 var body=el("div","gb-rules",html);card.appendChild(body);
 var b=el("button","gbtn primary","Got it");
 b.addEventListener("click",function(){GB.sfx.tap();ov.remove();if(GB.game.pausable&&!wasPaused)setPaused(false);});
 card.appendChild(b);ov.appendChild(card);document.body.appendChild(ov);
};

/* ---------- game over / end overlay ---------- */
GB.gameOver=function(opts){
 opts=opts||{};
 var ov=el("div","gb-ov");var card=el("div","gb-card");
 card.appendChild(el("div","gb-ov-title",opts.title||"Game Over"));
 if(opts.sub)card.appendChild(el("div","gb-ov-sub",opts.sub));
 var bA=el("button","gbtn primary",opts.again||"Play Again");
 bA.addEventListener("click",function(){GB.sfx.tap();ov.remove();if(opts.onAgain)opts.onAgain();});
 var bH=el("button","gbtn","Home");
 bH.addEventListener("click",function(){GB.sfx.tap();location.href="../index.html";});
 card.appendChild(bA);card.appendChild(bH);
 ov.appendChild(card);document.body.appendChild(ov);
 if(opts.won){GB.sfx.win();}else{GB.sfx.die();}
};

/* ---------- swipe + drag helpers ---------- */
GB.swipe=function(node,fn,minDist){
 minDist=minDist||22;var sx=0,sy=0,active=false;
 node.addEventListener("touchstart",function(e){var t=e.touches[0];sx=t.clientX;sy=t.clientY;active=true;},{passive:true});
 node.addEventListener("touchend",function(e){if(!active)return;active=false;
  var t=e.changedTouches[0],dx=t.clientX-sx,dy=t.clientY-sy;
  if(Math.max(Math.abs(dx),Math.abs(dy))<minDist)return;
  fn(Math.abs(dx)>Math.abs(dy)?(dx>0?"right":"left"):(dy>0?"down":"up"));},{passive:true});};
GB.dragX=function(node,W,fn){
 function px(cx){var r=node.getBoundingClientRect();return (cx-r.left)*(W/r.width);}
 node.addEventListener("touchstart",function(e){fn(px(e.touches[0].clientX));},{passive:true});
 node.addEventListener("touchmove",function(e){e.preventDefault();fn(px(e.touches[0].clientX));},{passive:false});
 node.addEventListener("mousemove",function(e){if(e.buttons)fn(px(e.clientX));});
 node.addEventListener("mousedown",function(e){fn(px(e.clientX));});};

/* ---------- toast ---------- */
GB.toast=function(msg){
 if(window.AndroidBridge&&AndroidBridge.toast){AndroidBridge.toast(msg);return;}
 var t=el("div","gb-toast");t.textContent=msg;document.body.appendChild(t);
 setTimeout(function(){t.classList.add("out");},1600);setTimeout(function(){t.remove();},2100);};
})();
