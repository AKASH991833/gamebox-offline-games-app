// spidersolitaire-app.js
// Wires SpiderSolitaireCore to the spidersolitaire.html UI. Solitaire,
// like Klondike/FreeCell here - no opponent, no AI, just a difficulty
// picker (how many suits are in play) chosen before "New game", the
// same way Kakuro/Bulls and Cows offer a picker before starting.
//
// Cards show their rank as text and their suit as a small SVG from
// card-faces.js: red suits (hearts, diamonds) hollow, black suits
// (spades, clubs) filled, the same faces as Klondike/FreeCell, so the
// red/black colour is readable on a monochrome E-Ink display. Spider
// itself only cares about suits, not colour. Face-down tableau cards
// get a hatched back instead of a color, the same "structural, not
// color" convention used everywhere else in this app.
//
// Tap-to-select-source, tap-to-select-destination, exactly like
// Klondike/FreeCell: tap the exposed top card of a column (or the
// start of a valid same-suit descending run further up that column)
// to select it, then tap a tableau column to move it there. Clicking a
// different valid source while something is already selected just
// switches the selection, rather than requiring a deselect first. A
// dedicated "Deal" button deals the next batch of 10 cards from the
// stock (one face-up card onto each column), which the rules disallow
// while any column is empty.
//
// Card sizing: height and overlap are set in JS from the measured column
// width by CardFaces.layoutColumns (card-faces.js), shared with
// Klondike/FreeCell, since CSS `aspect-ratio` is unreliable on some
// E-Ink browsers - recomputed on resize.

function spiderCardLabel(card) {
  return CardFaces.label(card);
}

function t18nSpider(key) {
  return (typeof I18n !== "undefined") ? I18n.t(key) : key;
}

const AppStateSpider = {
  state: null,
  selected: null, // { type: "column", col, index } | null
  gameOver: false,
  moveCount: 0,
  undoStack: []
};

const SPIDER_SAVE_KEY = "einkchess_save_spidersolitaire";

function saveSpiderGame() {
  if (typeof GameStorage === "undefined") return;
  GameStorage.save(SPIDER_SAVE_KEY, {
    state: AppStateSpider.state,
    moveCount: AppStateSpider.moveCount
  });
}

function clearSavedSpiderGame() {
  if (typeof GameStorage === "undefined") return;
  GameStorage.clear(SPIDER_SAVE_KEY);
}

function setStatusSpider(elementId, text) {
  const el = document.getElementById(elementId);
  if (el) I18n.setMsg(el, text || "");
}

function setGameResultSpider(text) {
  const el = document.getElementById("game-result");
  if (el) I18n.setMsg(el, text || "");
  if (!text && window.ResultModal) {
    window.ResultModal.hide();
  }
}

function announceGameResultSpider(title, message) {
  setGameResultSpider(message);
  setStatusSpider("board-info", message);
  if (window.ResultModal) {
    window.ResultModal.show(title, message);
  }
}

function resetUndoStackSpider() {
  AppStateSpider.undoStack = [];
}

function pushUndoSnapshotSpider() {
  AppStateSpider.undoStack.push({
    state: SpiderSolitaireCore.cloneState(AppStateSpider.state),
    moveCount: AppStateSpider.moveCount
  });
}

function initSpiderApp() {
  if (typeof BoardA11y !== "undefined") BoardA11y.enableArrowNav("#board-container");
  const menuToggle = document.getElementById("menu-toggle");
  const settingsPanel = document.getElementById("settings-panel");
  const levelInline = document.getElementById("spidersolitaire-level-inline");
  const startGameBtn = document.getElementById("start-spidersolitaire-game");

  function closeSettingsPanel() {
    if (!settingsPanel) return;
    settingsPanel.classList.add("hidden");
    if (menuToggle) I18n.setKey(menuToggle, "menu_toggle");
  }

  function openSettingsPanel() {
    if (!settingsPanel) return;
    settingsPanel.classList.remove("hidden");
    if (menuToggle) I18n.setKey(menuToggle, "menu_close");
  }

  if (menuToggle && settingsPanel) {
    menuToggle.addEventListener("click", () => {
      if (settingsPanel.classList.contains("hidden")) openSettingsPanel();
      else closeSettingsPanel();
    });
  }

  function startNewGameSpider(suitCount) {
    AppStateSpider.state = SpiderSolitaireCore.createInitialState(suitCount);
    AppStateSpider.selected = null;
    AppStateSpider.gameOver = false;
    AppStateSpider.moveCount = 0;
    resetUndoStackSpider();
    setGameResultSpider("");
    showBoardSectionSpider();
    buildSpiderBoardDOM();
    updateSpiderBoard();
    updateGameLabelsSpider();
    setStatusSpider("board-info", t18nSpider("spidersolitaire_hint_default"));
  }

  startGameBtn.addEventListener("click", () => {
    const suitCount = levelInline ? parseInt(levelInline.value, 10) : 2;
    startNewGameSpider(suitCount);
  });

  if (typeof I18n !== "undefined") {
    I18n.onChange(() => {
      if (AppStateSpider.state) updateSpiderBoard();
    });
  }

  const savedGame = typeof GameStorage !== "undefined" ? GameStorage.load(SPIDER_SAVE_KEY) : null;
  if (savedGame && savedGame.state) {
    AppStateSpider.state = savedGame.state;
    AppStateSpider.moveCount = savedGame.moveCount;
    AppStateSpider.selected = null;
    AppStateSpider.gameOver = false;
    resetUndoStackSpider();
    if (levelInline) levelInline.value = String(AppStateSpider.state.suitCount);
    setGameResultSpider("");
    showBoardSectionSpider();
    buildSpiderBoardDOM();
    updateSpiderBoard();
    updateGameLabelsSpider();
    setStatusSpider("board-info", t18nSpider("spidersolitaire_hint_default"));
  }
  // Otherwise no board is pre-built: the placeholder shows until the
  // player picks a difficulty and presses "New game".
}

function selectionsEqualSpider(a, b) {
  if (!a || !b || a.type !== b.type) return false;
  return a.col === b.col && a.index === b.index;
}

function trySelectSourceSpider(col, index) {
  if (!SpiderSolitaireCore.isMovableSequenceStart(AppStateSpider.state, col, index)) return false;
  AppStateSpider.selected = { type: "column", col, index };
  return true;
}

function onSpiderColumnClick(colIndex, cardIndex) {
  if (AppStateSpider.gameOver || !AppStateSpider.state) return;
  const sel = AppStateSpider.selected;

  if (sel && typeof cardIndex === "number" && selectionsEqualSpider(sel, { type: "column", col: colIndex, index: cardIndex })) {
    AppStateSpider.selected = null;
    updateSpiderBoard();
    setStatusSpider("board-info", t18nSpider("spidersolitaire_hint_default"));
    return;
  }

  if (sel) {
    const count = AppStateSpider.state.tableau[sel.col].length - sel.index;
    const result = SpiderSolitaireCore.moveColumnToColumn(AppStateSpider.state, sel.col, count, colIndex);
    if (result.ok) {
      pushUndoSnapshotSpider();
      AppStateSpider.state = result.state;
      AppStateSpider.selected = null;
      AppStateSpider.moveCount++;
      finishSpiderAction(result.completedSuit ? [result.completedSuit] : []);
      return;
    }
  }

  // No selection, or the move above failed - try treating this click as
  // picking a new source instead (a single click can both fail a move
  // and immediately start a new one, so re-picking never needs a
  // separate deselect click first).
  if (typeof cardIndex === "number" && trySelectSourceSpider(colIndex, cardIndex)) {
    updateSpiderBoard();
    setStatusSpider("board-info", t18nSpider("spidersolitaire_hint_selected"));
  } else {
    setStatusSpider("board-info", sel ? t18nSpider("spidersolitaire_msg_cant_place") : t18nSpider("spidersolitaire_msg_cant_pick"));
  }
}

function onSpiderDealClick() {
  if (AppStateSpider.gameOver || !AppStateSpider.state) return;
  if (!SpiderSolitaireCore.canDealStock(AppStateSpider.state)) {
    setStatusSpider("board-info", AppStateSpider.state.stock.length === 0
      ? t18nSpider("spidersolitaire_msg_stock_empty")
      : t18nSpider("spidersolitaire_msg_needs_full_columns"));
    return;
  }
  const result = SpiderSolitaireCore.dealFromStock(AppStateSpider.state);
  if (!result.ok) {
    setStatusSpider("board-info", t18nSpider("spidersolitaire_msg_stock_empty"));
    return;
  }
  pushUndoSnapshotSpider();
  AppStateSpider.state = result.state;
  AppStateSpider.selected = null;
  AppStateSpider.moveCount++;
  finishSpiderAction(result.completedSuits || []);
}

function finishSpiderAction(completedSuits) {
  updateSpiderBoard();
  updateGameLabelsSpider();

  if (SpiderSolitaireCore.isWon(AppStateSpider.state)) {
    AppStateSpider.gameOver = true;
    announceGameResultSpider(t18nSpider("spidersolitaire_win_title"), t18nSpider("spidersolitaire_win_message"));
    updateGameLabelsSpider();
  } else if (completedSuits && completedSuits.length) {
    setStatusSpider("board-info", t18nSpider("spidersolitaire_msg_sequence_completed"));
  } else {
    setStatusSpider("board-info", t18nSpider("spidersolitaire_hint_default"));
  }
}

function undoLastMove() {
  if (!AppStateSpider.undoStack || !AppStateSpider.undoStack.length) return;
  const prev = AppStateSpider.undoStack.pop();
  AppStateSpider.state = prev.state;
  AppStateSpider.moveCount = prev.moveCount;
  AppStateSpider.selected = null;
  AppStateSpider.gameOver = false;
  setGameResultSpider("");
  updateSpiderBoard();
  updateGameLabelsSpider();
  setStatusSpider("board-info", t18nSpider("spidersolitaire_msg_undone"));
}

function showBoardSectionSpider() {
  const section = document.getElementById("board-section");
  if (section) section.classList.remove("hidden");
  const placeholder = document.getElementById("board-placeholder");
  const boardContainer = document.getElementById("board-container");
  if (placeholder) placeholder.classList.add("hidden");
  if (boardContainer) boardContainer.classList.remove("hidden");
}

/*** Board rendering ***/

function buildSpiderBoardDOM() {
  const stockEl = document.getElementById("spider-stock");
  const sequencesEl = document.getElementById("spider-sequences");
  const columnsEl = document.getElementById("spider-columns");
  if (!stockEl || !sequencesEl || !columnsEl) return;

  stockEl.innerHTML = "";
  stockEl.addEventListener("click", onSpiderDealClick);

  columnsEl.innerHTML = "";
  for (let c = 0; c < SpiderSolitaireCore.COLUMN_COUNT; c++) {
    const col = document.createElement("div");
    col.className = "spider-column";
    col.dataset.col = c;
    col.addEventListener("click", () => onSpiderColumnClick(c, null));
    columnsEl.appendChild(col);
  }
}

function updateSpiderBoard() {
  const state = AppStateSpider.state;
  if (!state) return;
  const sel = AppStateSpider.selected;

  const stockEl = document.getElementById("spider-stock");
  if (stockEl) {
    const deals = SpiderSolitaireCore.remainingStockDeals(state);
    const canDeal = SpiderSolitaireCore.canDealStock(state);
    stockEl.className = "spider-cell spider-stock" + (state.stock.length > 0 ? " spider-card-back" : "");
    stockEl.textContent = state.stock.length > 0 ? String(deals) : "";
    stockEl.disabled = state.stock.length === 0;
    stockEl.classList.toggle("spider-stock-blocked", state.stock.length > 0 && !canDeal);
    I18n.setAria(stockEl, t18nSpider("spidersolitaire_aria_stock") + ": " +
      (state.stock.length > 0 ? deals + " " + t18nSpider("spidersolitaire_aria_deals_left") : t18nSpider("spidersolitaire_aria_empty")));
  }

  const sequencesEl = document.getElementById("spider-sequences");
  if (sequencesEl) {
    sequencesEl.textContent = state.completed + " / " + SpiderSolitaireCore.TOTAL_SEQUENCES;
    I18n.setAria(sequencesEl, t18nSpider("spidersolitaire_aria_sequences") + ": " + state.completed + " / " + SpiderSolitaireCore.TOTAL_SEQUENCES);
  }

  const columnsEl = document.getElementById("spider-columns");
  if (columnsEl) {
    columnsEl.querySelectorAll(".spider-column").forEach((colEl) => {
      const c = parseInt(colEl.dataset.col, 10);
      colEl.innerHTML = "";
      const column = state.tableau[c];
      if (!column.length) {
        const empty = document.createElement("span");
        empty.className = "spider-empty-slot";
        empty.setAttribute("aria-hidden", "true");
        colEl.appendChild(empty);
        return;
      }
      column.forEach((card, index) => {
        const cardEl = document.createElement("button");
        cardEl.type = "button";
        cardEl.style.zIndex = String(index + 1);
        if (card.faceUp) {
          cardEl.className = "spider-card";
          CardFaces.render(cardEl, card);
          const isSelected = !!(sel && sel.col === c && index >= sel.index);
          cardEl.classList.toggle("spider-card-selected", isSelected);
          I18n.setAria(cardEl, spiderCardLabel(card));
        } else {
          cardEl.className = "spider-card spider-card-back";
          I18n.setAria(cardEl, t18nSpider("spidersolitaire_aria_face_down"));
        }
        cardEl.addEventListener("click", (e) => {
          e.stopPropagation();
          onSpiderColumnClick(c, index);
        });
        colEl.appendChild(cardEl);
      });
    });
  }

  ensureSpiderCardAspectRatio();
  if (window.requestAnimationFrame) {
    window.requestAnimationFrame(ensureSpiderCardAspectRatio);
  } else {
    setTimeout(ensureSpiderCardAspectRatio, 0);
  }
  ensureSpiderResizeHandler();
}

// Card height and overlap come from CardFaces.layoutColumns (card-faces.js),
// recomputed after every render and on resize.
let einkSpiderResizeHandlerAttached = false;
let einkSpiderResizeTimeoutId = null;

function ensureSpiderCardAspectRatio() {
  CardFaces.layoutColumns(document.getElementById("spider-columns"), ".spider-column", ".spider-card", ".spider-empty-slot");
}

function ensureSpiderResizeHandler() {
  if (einkSpiderResizeHandlerAttached) return;
  einkSpiderResizeHandlerAttached = true;
  window.addEventListener("resize", () => {
    if (einkSpiderResizeTimeoutId !== null) clearTimeout(einkSpiderResizeTimeoutId);
    einkSpiderResizeTimeoutId = setTimeout(() => {
      einkSpiderResizeTimeoutId = null;
      ensureSpiderCardAspectRatio();
    }, 150);
  });
}

function updateGameLabelsSpider() {
  const meta = document.getElementById("game-meta");
  if (meta) meta.textContent = AppStateSpider.moveCount ? t18nSpider("spidersolitaire_move_label") + " " + AppStateSpider.moveCount : "";
  updateUndoButtonVisibilitySpider();

  if (AppStateSpider.gameOver) clearSavedSpiderGame();
  else saveSpiderGame();
}

function updateUndoButtonVisibilitySpider() {
  const btn = document.getElementById("undo-btn");
  if (!btn) return;
  const hasUndo = (AppStateSpider.undoStack || []).length > 0;
  btn.disabled = !(hasUndo);
}

document.addEventListener("DOMContentLoaded", initSpiderApp);
