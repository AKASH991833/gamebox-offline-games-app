(function(){
"use strict";
var SLUG="stack",W=360,H=480;
var cv=document.getElementById("cv"),ctx=GB.ctx(cv,W,H);
GB.shell({title:"Tower Stack",chips:[{id:"score",label:"Height"},{id:"best",label:"Best",value:GB.best(SLUG)}],
 rules:"<ul><li><b>Tap</b> to drop the moving block onto the tower.</li><li>Any overhang is sliced off - miss completely and the run ends.</li><li>A <b>perfect</b> drop keeps your full width and scores double.</li><li>The tower speeds up as it grows.</li></ul>"});
var COLS=["#8B5CF6","#EC4899","#F43F5E","#F97316","#FACC15","#4ADE80","#22D3EE","#A78BFA"];
var blocks,cur,dir,speed,score,playing,camY,parts,perfects,flash;
function setChip(id,v){var e=document.getElementById(id);if(e)e.textContent=v;}
function start(){
 blocks=[{x:40,w:280,y:H-40,h:26,color:COLS[0]}];
 score=0;speed=150;playing=true;camY=0;parts=[];perfects=0;flash=null;
 setChip("score",0);setChip("best",GB.best(SLUG));newMover();}
function newMover(){
 var top=blocks[blocks.length-1];
 cur={x:-top.w,w:top.w,y:top.y-32,h:26,color:COLS[blocks.length%COLS.length]};dir=1;}
function burst(x,y,color){
 for(var i=0;i<8;i++)parts.push({x:x,y:y,dx:(Math.random()-0.5)*160,dy:-Math.random()*160,t:0.5,color:color});}
function drop(){
 if(GB.paused)return;
 if(!playing)return;
 var top=blocks[blocks.length-1];
 var left=Math.max(cur.x,top.x),right=Math.min(cur.x+cur.w,top.x+top.w);
 var w=right-left,off=Math.abs(cur.x-top.x);
 if(w<=0){die();return;}
 var perfect=off<5;
 if(perfect){left=top.x;w=top.w;perfects++;score+=2;flash={t:0.7};GB.sfx.win();GB.buzz(30);}
 else{score++;GB.sfx.point();GB.buzz(12);}
 setChip("score",score);GB.saveBest(SLUG,score);setChip("best",GB.best(SLUG));
 var nb={x:left,w:w,y:cur.y,h:26,color:perfect?"#FFD93D":cur.color};
 blocks.push(nb);burst(left+w/2,cur.y,nb.color);
 if(!perfect){var cut=cur.x<top.x?{x:cur.x,w:top.x-cur.x}:{x:top.x+top.w,w:cur.x+cur.w-(top.x+top.w)};
  if(cut.w>0.5)parts.push({x:cut.x+cut.w/2,y:cur.y+13,dx:0,dy:40,t:0.6,color:cur.color,block:true,w:cut.w});}
 speed=Math.min(340,speed+7);newMover();}
function die(){
 playing=false;GB.saveBest(SLUG,score);GB.buzz(90);
 GB.gameOver({title:"Game Over",
  sub:"Height: <b>"+score+"</b> &nbsp; Perfect drops: <b>"+perfects+"</b>",onAgain:start});}
function step(dt){
 if(!playing)return;
 cur.x+=speed*dir*dt;
 if(cur.x+cur.w>W){cur.x=W-cur.w;dir=-1;}
 if(cur.x<0){cur.x=0;dir=1;}
 var targetY=Math.min(0,blocks[blocks.length-1].y-190);
 camY+=(targetY-camY)*Math.min(1,dt*7);
 if(flash){flash.t-=dt;if(flash.t<=0)flash=null;}
 parts.forEach(function(p){p.t-=dt;p.x+=p.dx*dt;p.y+=p.dy*dt;p.dy+=420*dt;});
 parts=parts.filter(function(p){return p.t>0;});}
function rr(x,y,w,h,r){ctx.beginPath();ctx.moveTo(x+r,y);ctx.arcTo(x+w,y,x+w,y+h,r);ctx.arcTo(x+w,y+h,x,y+h,r);ctx.arcTo(x,y+h,x,y,r);ctx.arcTo(x,y,x+w,y,r);ctx.closePath();ctx.fill();}
function drawBlock(b){ctx.fillStyle="#0e192c55";rr(b.x+3,b.y+4,b.w,b.h,5);ctx.fillStyle=b.color;rr(b.x,b.y,b.w,b.h,5);ctx.fillStyle="#ffffff44";rr(b.x+3,b.y+2,Math.max(1,b.w-6),5,2);ctx.fillStyle="#14253b55";ctx.fillRect(b.x+2,b.y+b.h-7,Math.max(1,b.w-4),5);if(b.w>24){ctx.fillStyle="#f3edcd44";for(var x=b.x+9;x<b.x+b.w-9;x+=21){ctx.fillRect(x,b.y+10,9,5)}}}
function draw(){
 var bg=ctx.createLinearGradient(0,0,0,H);bg.addColorStop(0,"#1c2b47");bg.addColorStop(1,"#526878");ctx.fillStyle=bg;ctx.fillRect(0,0,W,H);
 ctx.fillStyle="#e1d2ad";ctx.beginPath();ctx.arc(285,72,24,0,7);ctx.fill();
 for(var layer=0;layer<3;layer++){ctx.fillStyle=["#34475d","#293e54","#22334c"][layer];for(var i=0;i<12;i++){var bx=i*37-10,bh=35+(i*31+layer*47)%100;ctx.fillRect(bx,H-bh-layer*20,30,bh+layer*20);if(layer===2){ctx.fillStyle="#d9ca9522";for(var y=H-bh+7;y<H;y+=13)ctx.fillRect(bx+7,y,3,4);ctx.fillStyle="#22334c"}}}
 ctx.save();ctx.translate(0,-camY);
 blocks.forEach(function(b){drawBlock(b);});
 if(playing&&cur){drawBlock(cur);}
 parts.forEach(function(p){ctx.globalAlpha=Math.max(0,p.t/0.5);
  ctx.fillStyle=p.color;
  if(p.block)rr(p.x-p.w/2,p.y-13,p.w,26,7);else ctx.fillRect(p.x-2.5,p.y-2.5,5,5);});
 ctx.globalAlpha=1;ctx.restore();
 if(flash){ctx.globalAlpha=Math.min(1,flash.t);
  ctx.fillStyle="#FFD93D";ctx.font="800 26px sans-serif";ctx.textAlign="center";
  ctx.fillText("PERFECT!",W/2,120);ctx.globalAlpha=1;}}
GB.loop(step,draw);
cv.addEventListener("pointerdown",function(){drop();});
document.addEventListener("keydown",function(e){if(e.key===" "){e.preventDefault();drop();}});
GB.game.restart=start;
start();
})();
