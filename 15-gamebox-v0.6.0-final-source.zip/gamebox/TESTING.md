# GameBox quality batch, work in progress

This is source code and reproducible tests, not a new Android release.

The catalog has 87 games, including seven new original games: Carrom Studio (arcade practice rules), Boundary Nights (six-ball batting), Neon Outpost (five-wave arena), Moon Dock (three-site landing challenge), Orbit Pinball (three-ball arcade table), Pocket Greens (six-hole mini golf), and Circuit Keep (six-wave tower defense). Existing arcade games have graphics and control improvements. Ridge Rider remains experimental and is not in the catalog.

Run `node tests/core-tests.js` for carrom physics/pocket, cricket timing and lunar landing checks. These are automated rules and simulation checks, not human-play ratings. The Moon Dock completion test uses a feedback controller. Arena completion checks include an invulnerable fixture; that fixture is not a natural-play win.

Browser checks covered all 87 catalog entry pages at a 360px viewport with external requests blocked, and selected pause/replay/input/layout checks at other sizes. Actual Android installation, update, saved-data survival and low-end-device performance have not been tested. A browser check does not establish those properties.

All delivered v0.4 games remain in this source. No paid services, cards or network are required by gameplay. The historical MIT and other bundled notices are retained in www/classics and the credits page.

Additional control checks cover single-action pointer behavior in Road Rush, Dash Runner and Crossy Dash; keyboard catalog activation and modal focus trapping; favorite add/remove persistence; best-score retention; pause/keyboard/pointer/restart behavior in Block Drop, Flappy Dot, Tower Stack, Target Tap and Mole Smash. Block Drop swipes no longer also rotate the piece. Mole Smash gameplay timers now use the paused game loop, so a pause freezes target expiry as well as the round clock. Its complete 30-second automated round, hit scoring and replay were checked. These are browser checks only.

Browser test scripts require Node.js, Playwright, an installed Chromium and Python 3. Run them one at a time; they serve the www folder at localhost:8766. `core-tests.js` uses Node.js built-ins only. The scripts are not included in the APK.

Orbit Pinball rules tests cover launch gating, bumper points, three-ball drain and ended-state gating. Thirty randomized-control simulations ran for up to 300 seconds each with finite-state checks; they do not imply all rounds ended. A no-input policy drained all three balls in about 26 seconds. Held/timed flippers can keep a ball alive much longer. Its UI checks include pointer cancel, pause, replay and three viewport widths. The end-dialog screenshot is an injected three-drain fixture, not a human-play result.

All 87 game pages were also opened from file:// in desktop Chromium without JavaScript errors. This is a local-file compatibility check, not an Android WebView check. Extra shared-control checks cover rules dialogs on 2048 and pause/restart in Snake, Galaxy Guard and Brick Breaker. Galaxy Guard now shows one end dialog when multiple aliens land together. Snake permits entering its vacating tail cell, detects a filled board instead of searching forever for food, and ignores turns while paused. Those boundary cases have browser tests.

Pocket Greens has six distinct courses with rails, walls, sand and water. A search-based shot planner completed all six through the real physics engine in ten total strokes; that is a controller result, not a human-play result. Separate tests cover 600 random shots settling, shot lock, water penalty, low-speed cup capture, drag input, pause cancels aim, progression, final dialog and replay.

A short-screen audit at 360x640 and a landscape audit at 760x390 found tall boards centered behind their headers. The shared layout now keeps the header outside board content, reduces canvas width on short portrait screens and lets taller content scroll. After the fix, all original/new game pages had no header/canvas overlap or horizontal overflow in those audited sizes. Some rules or controls may require scrolling in landscape. Actual screenshots of the corrected short-screen cricket and lunar layouts were inspected.

2048 now discards pending animation callbacks after restart or undo, so an old move cannot spawn a tile into a reset game. Tests cover pair merging, that animation race and blocking moves under the rules dialog.

Circuit Keep has two tower types, three upgrade levels, fast/armored enemies, energy rewards and six manually started waves. Economy/pad/wave gating checks pass. No-build loses at wave 2 and an unupgraded three-tower layout loses at wave 6. The same layout with upgrades survives all six using ordinary game rules, full core health and 78 kills. This is an automated strategy, not human play. Its UI checks cover pad input, upgrades, progression, pause rejecting builds, replay and three viewport widths.

Further old-game checks: Brick Breaker side-depth calculation used an undefined brick radius, which could choose the wrong reflection axis. It now uses the ball radius, with underside reflection, score, level advance, three-life loss and replay tested. Maze Run now advances and snaps at actual cell centers instead of updating the cell before reaching it; a route solver completed 100 generated levels through the movement code. Paddle Clash's rules now describe its actual winning-match score, rather than claiming a rally-streak record. Flappy Dot and Tower Stack have new scene and sprite/block art, checked in starting and played states. Tower Stack's played-state screenshot uses positioned-drop fixtures, not human timing.


## v0.6.0 identity correction
- Same87 catalog routes and existing package/signing identity.
-53 original classic cover replacements.87SVGs parse. No repeated classic structures remain under color/number normalization. The old racer/blocks structural match was a simplistic audit false positive; their visible road and falling-block artwork is different.
- All56classic actual screens inspected at390x844, plus112checks at360x640 and760x390 with no horizontal overflow.
- Removed blanket chess border and purple treatment; reviewed point boards, card layouts, actor icons and puzzle clues.
-12portable browser suites and4core suites passed on the correction source. All12 suites rerun against the final packaged source and passed.
- No connected Android device or KVM. Browser tests do not establish installation, update-data survival, low-end performance or physical touch quality.

- Final extension: all31original game screens visually checked. Environment-matched themes and8mechanic-specific board surfaces replace the shared purple treatment.12browser suites rerun successfully. Sudoku generation, 2048 labels, Memory backs and played Mole state checked after readiness, not only first paint.

- Mole active control: disabled Round running label during play, Start restored on timed end. Synthetic active click preserved scored points; one timed end dialog. Prior handler already guarded active starts; this change makes the UI honest. Added browser-mole-active-tests.js.
