(function(){
"use strict";
var SLUG="flappy",W=360,H=480;
var cv=document.getElementById("cv"),ctx=GB.ctx(cv,W,H);
GB.shell({title:"Flappy Dot",chips:[{id:"score",label:"Score"},{id:"best",label:"Best",value:GB.best(SLUG)}],
 rules:"<ul><li><b>Tap</b> to flap upward. Gravity does the rest.</li><li>Fly through the gaps between pipes - each one is <b>+1</b>.</li><li>Touching a pipe, the floor or the ceiling ends the run.</li><li>Score 10/20/30 for bronze, silver and gold medals.</li></ul>"});
var bird,pipes,clouds,score,playing,ready,dist;
function setChip(id,v){var e=document.getElementById(id);if(e)e.textContent=v;}
function start(){
 bird={x:82,y:H/2,vy:0,r:12,rot:0};pipes=[];score=0;playing=true;ready=true;dist=0;
 clouds=[];for(var i=0;i<4;i++)clouds.push({x:Math.random()*W,y:30+Math.random()*140,s:16+Math.random()*18});
 setChip("score",0);setChip("best",GB.best(SLUG));}
function flap(){
 if(GB.paused)return;
 if(!playing)return;
 if(ready)ready=false;
 bird.vy=-255;GB.sfx.flip();}
function die(){
 playing=false;GB.saveBest(SLUG,score);GB.buzz(90);
 var medal=score>=30?"Gold":score>=20?"Silver":score>=10?"Bronze":null;
 GB.gameOver({title:"Game Over",
  sub:"Score: <b>"+score+"</b> &nbsp; Best: <b>"+GB.best(SLUG)+"</b>"+(medal?"<br>Medal: <b>"+medal+"</b>":""),
  onAgain:start});}
function step(dt){
 clouds.forEach(function(c){c.x-=12*dt;if(c.x<-40){c.x=W+40;c.y=30+Math.random()*140;}});
 if(!playing||ready)return;
 dist+=dt;
 bird.vy+=900*dt;bird.y+=bird.vy*dt;
 bird.rot=Math.max(-0.45,Math.min(1.2,bird.vy/420));
 var speed=150+Math.min(90,score*2.2);
 var spacing=1.75;
 var last=pipes[pipes.length-1];
 if(!last||last.x<W-speed*spacing){
  var gap=135-Math.min(25,score);
  var top=55+Math.random()*(H-gap-165);
  pipes.push({x:W+10,top:top,gap:gap,passed:false});}
 pipes.forEach(function(p){p.x-=speed*dt;
  if(!p.passed&&p.x+60<bird.x){p.passed=true;score++;setChip("score",score);
   GB.saveBest(SLUG,score);setChip("best",GB.best(SLUG));GB.sfx.point();}});
 pipes=pipes.filter(function(p){return p.x>-70;});
 if(bird.y>H-bird.r-2||bird.y<bird.r)return die();
 for(var i=0;i<pipes.length;i++){var p=pipes[i];
  if(bird.x+bird.r>p.x&&bird.x-bird.r<p.x+60&&(bird.y-bird.r<p.top||bird.y+bird.r>p.top+p.gap))return die();}}
function rr(x,y,w,h,r){ctx.beginPath();ctx.moveTo(x+r,y);ctx.arcTo(x+w,y,x+w,y+h,r);ctx.arcTo(x+w,y+h,x,y+h,r);ctx.arcTo(x,y+h,x,y,r);ctx.arcTo(x,y,x+w,y,r);ctx.closePath();ctx.fill();}
function draw(){
 var dark=GB.isDark();
 var g=ctx.createLinearGradient(0,0,0,H);g.addColorStop(0,"#273956");g.addColorStop(.65,"#7c7994");g.addColorStop(1,"#c09e93");ctx.fillStyle=g;ctx.fillRect(0,0,W,H);
 ctx.fillStyle="#f0d7af";ctx.beginPath();ctx.arc(280,80,27,0,7);ctx.fill();
 for(var layer=0;layer<2;layer++){ctx.fillStyle=layer?"#3f5665":"#607180";ctx.beginPath();ctx.moveTo(0,H);for(var x=0;x<=W;x+=8)ctx.lineTo(x,340+layer*40+Math.sin(x/70+layer)*25+Math.sin(x/31)*8);ctx.lineTo(W,H);ctx.fill()}
 ctx.fillStyle="rgba(247,231,220,.22)";
 clouds.forEach(function(c){ctx.beginPath();ctx.arc(c.x,c.y,c.s,0,7);ctx.arc(c.x+c.s*0.9,c.y+4,c.s*0.7,0,7);ctx.arc(c.x-c.s*0.9,c.y+5,c.s*0.65,0,7);ctx.fill();});
 pipes.forEach(function(p){
  var pg=ctx.createLinearGradient(p.x,0,p.x+60,0);
  pg.addColorStop(0,"#3b7567");pg.addColorStop(.4,"#80ac8a");pg.addColorStop(1,"#31584d");
  ctx.fillStyle=pg;rr(p.x,-4,60,p.top+4,8);rr(p.x,p.top+p.gap,60,H-p.top-p.gap+4,8);
  ctx.fillStyle="#b9c597";rr(p.x-3,p.top-13,66,13,4);rr(p.x-3,p.top+p.gap,66,13,4);ctx.fillStyle="#203f4133";for(var py=18;py<p.top-18;py+=26)ctx.fillRect(p.x+5,py,50,2);for(var py=p.top+p.gap+25;py<H;py+=26)ctx.fillRect(p.x+5,py,50,2);});
 ctx.fillStyle="#c4b891";ctx.fillRect(0,H-10,W,10);ctx.fillStyle="#66785a";ctx.fillRect(0,H-12,W,4);
 ctx.save();ctx.translate(bird.x,bird.y);ctx.rotate(bird.rot);
 ctx.fillStyle="#76594d55";ctx.beginPath();ctx.ellipse(2,3,15,11,0,0,7);ctx.fill();var feather=ctx.createLinearGradient(-10,-11,10,11);feather.addColorStop(0,"#ffdf8f");feather.addColorStop(1,"#d49356");ctx.fillStyle=feather;ctx.beginPath();ctx.ellipse(0,0,14,11,0,0,7);ctx.fill();ctx.fillStyle="#d7a665";ctx.beginPath();ctx.moveTo(-10,0);ctx.lineTo(-21,-5);ctx.lineTo(-18,5);ctx.closePath();ctx.fill();ctx.fillStyle="#fff4d9";ctx.beginPath();ctx.ellipse(5,-4,5,6,0,0,7);ctx.fill();
 ctx.fillStyle="#F59E0B";ctx.beginPath();ctx.moveTo(bird.r-2,0);ctx.lineTo(bird.r+7,-3);ctx.lineTo(bird.r+7,3);ctx.closePath();ctx.fill();
 ctx.fillStyle="#3b2f04";ctx.beginPath();ctx.arc(4,-3,2.6,0,7);ctx.fill();
 ctx.fillStyle="#FBBF24";ctx.beginPath();ctx.ellipse(-4,3,7,4+Math.sin(dist*25)*2,-0.4,0,7);ctx.fill();
 ctx.restore();
 if(ready&&playing){ctx.fillStyle="#fff0dc";
  ctx.font="700 16px sans-serif";ctx.textAlign="center";ctx.fillText("Tap to start",W/2,H/2-40);}}
GB.loop(step,draw);
cv.addEventListener("pointerdown",function(){flap();});
document.addEventListener("keydown",function(e){if(e.key===" "){e.preventDefault();flap();}});
GB.game.restart=start;
start();
})();
