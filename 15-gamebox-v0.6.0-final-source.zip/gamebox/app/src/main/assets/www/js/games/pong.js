(function(){
"use strict";
var SLUG="pong",W=360,H=480,TARGET=7;
var cv=document.getElementById("cv"),ctx=GB.ctx(cv,W,H);
GB.shell({title:"Paddle Clash",chips:[{id:"score",label:"You",value:0},{id:"aisc",label:"CPU",value:0},{id:"best",label:"Best",value:GB.best(SLUG)}],
 rules:"<ul><li><b>Drag</b> to move your paddle (bottom, cyan).</li><li>First to <b>7 points</b> wins the match.</li><li>Hit the ball with the paddle edge to add angle. The rally speeds up over time.</li><li>Winning match score is 700, plus 25 for each point you kept the CPU below 7.</li></ul>"});
var me,ai,ball,pScore,aiScore,streak,bestStreak,playing,serveT;
function setChip(id,v){var e=document.getElementById(id);if(e)e.textContent=v;}
function hud(){setChip("score",pScore);setChip("aisc",aiScore);setChip("best",GB.best(SLUG));}
function start(){
 me={x:W/2-45,w:90,h:12,y:H-30};ai={x:W/2-45,w:90,h:12,y:18};
 pScore=0;aiScore=0;streak=0;bestStreak=0;playing=true;
 serve(-1);hud();}
function serve(dir){
 ball={x:W/2,y:H/2,dx:(Math.random()<0.5?-1:1)*120,dy:dir*210,r:8};serveT=0.7;}
function point(mine){
 if(mine){pScore++;streak++;bestStreak=Math.max(bestStreak,streak);GB.sfx.point();GB.buzz(25);}
 else{aiScore++;streak=0;GB.sfx.die();GB.buzz(70);}
 hud();
 if(pScore>=TARGET||aiScore>=TARGET){
  playing=false;
  var won=pScore>=TARGET;
  if(won){var sc=pScore*100+Math.max(0,TARGET-aiScore)*25;
   GB.saveBest(SLUG,sc);hud();}
  GB.gameOver({title:won?"You Win the Match!":"Match Lost",won:won,
   sub:pScore+" - "+aiScore+(won?"<br>Match score: <b>"+(pScore*100+Math.max(0,TARGET-aiScore)*25)+"</b>":""),
   again:"Play Again",onAgain:start});return;}
 serve(mine?-1:1);}
function step(dt){
 if(!playing)return;
 if(serveT>0){serveT-=dt;return;}
 ball.x+=ball.dx*dt;ball.y+=ball.dy*dt;
 if(ball.x<ball.r){ball.x=ball.r;ball.dx=Math.abs(ball.dx);GB.sfx.hit();}
 if(ball.x>W-ball.r){ball.x=W-ball.r;ball.dx=-Math.abs(ball.dx);GB.sfx.hit();}
 var sp=Math.hypot(ball.dx,ball.dy);
 var aiSpeed=Math.min(300,150+sp*0.25);
 var target=ball.x-ai.w/2+(ball.dy<0?ball.dx*0.15:0);
 var d=target-ai.x;ai.x+=Math.max(-aiSpeed*dt,Math.min(aiSpeed*dt,d));
 ai.x=Math.max(0,Math.min(W-ai.w,ai.x));
 if(ball.dy<0&&ball.y-ball.r<=ai.y+ai.h&&ball.y+ball.r>=ai.y&&ball.x>=ai.x-4&&ball.x<=ai.x+ai.w+4){
  var off=(ball.x-(ai.x+ai.w/2))/(ai.w/2);
  ball.dy=Math.abs(ball.dy)*1.02;ball.dx=off*sp*0.75;ball.y=ai.y+ai.h+ball.r+0.5;GB.sfx.hit();}
 if(ball.dy>0&&ball.y+ball.r>=me.y&&ball.y-ball.r<=me.y+me.h&&ball.x>=me.x-4&&ball.x<=me.x+me.w+4){
  var off2=(ball.x-(me.x+me.w/2))/(me.w/2);
  var ns=Math.min(520,sp*1.04);
  ball.dy=-Math.abs(ball.dy)/sp*ns;ball.dx=off2*ns*0.85;ball.y=me.y-ball.r-0.5;GB.sfx.hit();GB.buzz(8);}
 if(ball.y>H+18)point(false);
 if(ball.y<-18)point(true);}
function rr(x,y,w,h,r){ctx.beginPath();ctx.moveTo(x+r,y);ctx.arcTo(x+w,y,x+w,y+h,r);ctx.arcTo(x+w,y+h,x,y+h,r);ctx.arcTo(x,y+h,x,y,r);ctx.arcTo(x,y,x+w,y,r);ctx.closePath();ctx.fill();}
function draw(){
 ctx.fillStyle=GB.isDark()?"#1E1338":"#EFE9FB";ctx.fillRect(0,0,W,H);
 ctx.strokeStyle=GB.isDark()?"rgba(255,255,255,.15)":"rgba(36,22,64,.15)";
 ctx.setLineDash([8,8]);ctx.beginPath();ctx.moveTo(10,H/2);ctx.lineTo(W-10,H/2);ctx.stroke();ctx.setLineDash([]);
 ctx.fillStyle="#F43F5E";rr(ai.x,ai.y,ai.w,ai.h,6);
 ctx.fillStyle="#22D3EE";rr(me.x,me.y,me.w,me.h,6);
 ctx.fillStyle="#FFD93D";ctx.beginPath();ctx.arc(ball.x,ball.y,ball.r,0,7);ctx.fill();
 if(serveT>0&&playing){ctx.fillStyle=GB.isDark()?"rgba(255,255,255,.5)":"rgba(36,22,64,.5)";
  ctx.font="800 26px sans-serif";ctx.textAlign="center";
  ctx.fillText(Math.ceil(serveT)>0?Math.ceil(serveT*2):"",W/2,H/2+40);}}
GB.loop(step,draw);
GB.dragX(cv,W,function(x){me.x=Math.max(0,Math.min(W-me.w,x-me.w/2));});
GB.game.restart=start;
start();
})();
