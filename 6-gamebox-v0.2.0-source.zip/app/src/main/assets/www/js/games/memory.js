(function(){
"use strict";
var SLUG="memory";
var SYMS=["\u{1F388}","\u{1F381}","\u{2B50}","\u{1F3AE}","\u{1F3B2}","\u{1F3C0}","\u{1F3B8}","\u{1F680}"];
GB.shell({title:"Memory Match",chips:[{id:"score",label:"Moves"},{id:"best",label:"Best",value:GB.best(SLUG)||"-"}],
 rules:"<ul><li>Cards are shown face-up for a moment - <b>memorize</b> them.</li><li>Flip two cards per move. A matching pair stays open.</li><li>Match all <b>8 pairs</b>. Fewer moves and less time mean a higher score.</li></ul>"});
var cards,open=[],matched=0,moves=0,lock=true,startedAt,acc=0,timerIv=null,els=[];
var boardEl=document.getElementById("board"),statusEl=document.getElementById("status");
function setChip(id,v){var e=document.getElementById(id);if(e)e.textContent=v;}
function fmt(s){var m=(s/60)|0,ss=s%60;return (m?m+"m ":"")+ss+"s";}
function elapsed(){return acc+(startedAt?Date.now()-startedAt:0);}
function tick(){statusEl.textContent="Time: "+fmt((elapsed()/1000)|0);}
function start(){
 if(timerIv)clearInterval(timerIv);
 cards=SYMS.concat(SYMS).map(function(s,i){return{s:s,id:i}});
 for(var i=cards.length-1;i>0;i--){var j=(Math.random()*(i+1))|0,t=cards[i];cards[i]=cards[j];cards[j]=t;}
 open=[];matched=0;moves=0;lock=true;startedAt=null;acc=0;els=[];
 setChip("score",0);setChip("best",GB.best(SLUG)||"-");
 statusEl.textContent="Memorize the cards...";
 render(true);
 setTimeout(function(){els.forEach(function(el){el.classList.remove("open")});
  lock=false;startedAt=Date.now();timerIv=setInterval(tick,1000);tick();},1600);}
function render(faceUp){
 boardEl.innerHTML="";
 cards.forEach(function(c,i){
  var el=document.createElement("button");el.className="mcard"+(faceUp?" open":"");
  el.innerHTML='<div class="face back">?</div><div class="face front">'+c.s+"</div>";
  el.addEventListener("click",function(){flip(i,el);});
  boardEl.appendChild(el);els.push(el);});}
function flip(i,el){
 if(lock||el.classList.contains("open")||el.classList.contains("done"))return;
 GB.sfx.flip();el.classList.add("open");open.push({i:i,el:el});
 if(open.length===2){moves++;setChip("score",moves);
  if(cards[open[0].i].s===cards[open[1].i].s){
   open.forEach(function(o){o.el.classList.add("done")});matched++;open=[];
   GB.sfx.point();GB.buzz(15);
   if(matched===8)win();}
  else{lock=true;var o1=open[0],o2=open[1];
   setTimeout(function(){[o1,o2].forEach(function(o){o.el.classList.remove("open")});
    open=[];lock=false;},700);}}}
function win(){
 if(timerIv)clearInterval(timerIv);
 var secs=(elapsed()/1000)|0;
 var score=Math.max(10,300-(moves-8)*10-Math.max(0,secs-40));
 GB.saveBest(SLUG,score);setChip("best",GB.best(SLUG));GB.buzz(60);
 statusEl.textContent="Solved in "+moves+" moves, "+fmt(secs)+"!";
 GB.gameOver({title:"You Win!",won:true,
  sub:moves+" moves in "+fmt(secs)+" - Score: <b>"+score+"</b>",onAgain:start});}
document.getElementById("restart").addEventListener("click",function(){GB.sfx.tap();start();});
GB.game.restart=start;
GB.onPauseChange(function(p){
 if(p){if(startedAt){acc+=Date.now()-startedAt;startedAt=null;}
  if(timerIv){clearInterval(timerIv);timerIv=null;}}
 else{if(!startedAt&&!lock&&matched<8){startedAt=Date.now();}
  if(!timerIv&&!lock&&matched<8){timerIv=setInterval(tick,1000);}}});
start();
})();
