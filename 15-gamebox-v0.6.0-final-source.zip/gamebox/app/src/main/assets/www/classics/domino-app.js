// domino-app.js
// Wires DominoCore/DominoAi to domino.html.
//
// Layout (top to bottom), chosen so a long line of tiles never has to be
// read or tapped on a small e-ink screen:
//   - one row with the two open ends, each shown as a big number and
//     tappable - these are the only targets for placing a tile;
//   - the line of tiles played so far, as one horizontal row that
//     scrolls sideways (for reference only);
//   - the player's own hand. Tap a tile to pick it, then tap an open end.
// Opponents' hands and the stock are shown as counts, not face-down rows.
//
// With two or more people on one device, each hand is covered between
// turns ("Pass the device to Player 2") so nobody sees another's tiles.
// Against the computer the human is always Player 1.
//
// Variant "Triangles" (DominoCore, state.variant): instead of the ends
// row and the line, the board of triangles is drawn, scaled to the width.
// Picking a tile marks every free triangle it fits on with a number; tap
// one to lay the tile there.

const DOMINO_SAVE_KEY = "einkchess_save_domino";

const AppStateDomino = {
  mode: "vs-ai",       // "vs-ai" | "hotseat"
  numPlayers: 2,
  aiLevel: 2,
  state: null,
  started: false,
  gameOver: false,
  selected: null,      // hand index picked by the player to move
  revealed: true,      // hotseat: whether the current hand is uncovered
  lastPlaced: null,    // { side } of the latest tile, for the last-move mark
  busy: false,         // a computer move is scheduled
  result: null,        // final message, kept for re-rendering
  newKeys: []          // tiles the human just drew ("4-1"), marked in the hand
};

// Against the computer the human is "You" and the computers "Computer 1"
// and so on; on one device the seats are "Player 1" and so on. Sentences
// about the human have their own wording ("You passed."), they are not
// built from the name.
function playerNameDomino(i) {
  if (AppStateDomino.mode === "vs-ai") return i === 0 ? "You" : "Computer " + i;
  return "Player " + (i + 1);
}

function isYouDomino(i) {
  return AppStateDomino.mode === "vs-ai" && i === 0;
}

function isAiPlayerDomino(i) {
  return AppStateDomino.mode === "vs-ai" && i !== 0;
}

// Whose hand is shown: the human's against the computer, otherwise the
// player to move.
function viewerDomino() {
  return AppStateDomino.mode === "vs-ai" ? 0 : AppStateDomino.state.turn;
}

function tileTextDomino(tile) {
  return tile.join("-");
}

function isTriDomino() {
  return !!(AppStateDomino.state && DominoCore.isTriangle(AppStateDomino.state));
}

function setStatusDomino(text) {
  if (((AppStateDomino.mode === "vs-ai")) && text) {
    text = UiStatus.rewrite(text, AppStateDomino);
  }
  const el = document.getElementById("board-info");
  if (el) I18n.setMsg(el, text || "");
}

function setGameResultDomino(text) {
  const el = document.getElementById("game-result");
  if (el) I18n.setMsg(el, text || "");
  if (!text && window.ResultModal) window.ResultModal.hide();
}

function saveDominoGame() {
  if (typeof GameStorage === "undefined") return;
  GameStorage.save(DOMINO_SAVE_KEY, {
    mode: AppStateDomino.mode,
    numPlayers: AppStateDomino.numPlayers,
    aiLevel: AppStateDomino.aiLevel,
    state: AppStateDomino.state,
    lastPlaced: AppStateDomino.lastPlaced
  });
}

function clearSavedDominoGame() {
  if (typeof GameStorage !== "undefined") GameStorage.clear(DOMINO_SAVE_KEY);
}

function recordStatsDomino(outcome) {
  if (typeof GameStats === "undefined" || AppStateDomino.mode !== "vs-ai") return;
  GameStats.record("domino", outcome);
}

/*** Tile drawing ***/

// Pip centres inside one 50x50 half.
const DOMINO_PIP_LAYOUT = {
  0: [],
  1: [[25, 25]],
  2: [[13, 13], [37, 37]],
  3: [[13, 13], [25, 25], [37, 37]],
  4: [[13, 13], [37, 13], [13, 37], [37, 37]],
  5: [[13, 13], [37, 13], [25, 25], [13, 37], [37, 37]],
  6: [[13, 13], [37, 13], [13, 25], [37, 25], [13, 37], [37, 37]]
};

function pipsSvgDomino(value, dx, dy) {
  return DOMINO_PIP_LAYOUT[value].map((p) =>
    '<circle class="domino-pip" cx="' + (p[0] + dx) + '" cy="' + (p[1] + dy) + '" r="5"/>').join("");
}

// A tile as inline SVG in the page's text colour. Doubles in the line
// stand crosswise, as they traditionally do.
function tileSvgDomino(tile, vertical) {
  if (vertical) {
    return '<svg class="domino-svg domino-svg-v" viewBox="0 0 50 100" aria-hidden="true" focusable="false">' +
      '<rect class="domino-face" x="1.5" y="1.5" width="47" height="97" rx="6"/>' +
      '<line class="domino-divider" x1="6" y1="50" x2="44" y2="50"/>' +
      pipsSvgDomino(tile[0], 0, 0) + pipsSvgDomino(tile[1], 0, 50) + "</svg>";
  }
  return '<svg class="domino-svg" viewBox="0 0 100 50" aria-hidden="true" focusable="false">' +
    '<rect class="domino-face" x="1.5" y="1.5" width="97" height="47" rx="6"/>' +
    '<line class="domino-divider" x1="50" y1="6" x2="50" y2="44"/>' +
    pipsSvgDomino(tile[0], 0, 0) + pipsSvgDomino(tile[1], 50, 0) + "</svg>";
}

// A triangle tile for the hand: pointing up, a number in each corner.
function triTileSvgDomino(tile) {
  return '<svg class="domino-svg domino-svg-tri" viewBox="0 0 100 88" aria-hidden="true" focusable="false">' +
    '<path class="domino-face" d="M50 3L97 85H3Z" stroke-linejoin="round"/>' +
    '<text class="domino-tri-num" x="50" y="34">' + tile[0] + "</text>" +
    '<text class="domino-tri-num" x="25" y="76">' + tile[1] + "</text>" +
    '<text class="domino-tri-num" x="75" y="76">' + tile[2] + "</text></svg>";
}

// Corner points of triangle (r, c) in board units (side W, height H), in
// DominoCore.triCorners order.
const DOMINO_TRI_W = 60;
const DOMINO_TRI_H = 52;

function triPointsDomino(r, c) {
  const x0 = c * DOMINO_TRI_W / 2, y0 = r * DOMINO_TRI_H, W = DOMINO_TRI_W, H = DOMINO_TRI_H;
  if (DominoCore.pointsUp(r, c)) return [[x0 + W / 2, y0], [x0, y0 + H], [x0 + W, y0 + H]];
  return [[x0, y0], [x0 + W, y0], [x0 + W / 2, y0 + H]];
}

/*** Game flow ***/

function initDominoApp() {
  if (typeof MoveHints !== "undefined") MoveHints.onChange(() => renderDomino());
  const menuToggle = document.getElementById("menu-toggle");
  const settingsPanel = document.getElementById("settings-panel");
  const modeOffline = document.getElementById("mode-offline");
  const modeOfflineAi = document.getElementById("mode-offline-ai");
  const levelWrap = document.getElementById("domino-level-wrap");
  const levelSelect = document.getElementById("domino-level-inline");
  const playersSelect = document.getElementById("domino-num-players");
  const variantSelect = document.getElementById("domino-variant");
  const startBtn = document.getElementById("start-domino-game");
  const resignBtn = document.getElementById("resign-button");
  let pendingMode = "vs-ai";

  function setMode(mode) {
    pendingMode = mode;
    if (modeOffline) modeOffline.classList.toggle("active-mode", mode === "hotseat");
    if (modeOfflineAi) modeOfflineAi.classList.toggle("active-mode", mode === "vs-ai");
    if (levelWrap) levelWrap.classList.toggle("hidden", mode !== "vs-ai");
  }

  if (menuToggle && settingsPanel) {
    menuToggle.addEventListener("click", () => {
      const hidden = settingsPanel.classList.toggle("hidden");
      I18n.setKey(menuToggle, hidden ? "menu_toggle" : "menu_close");
    });
  }
  if (modeOffline) modeOffline.addEventListener("click", () => setMode("hotseat"));
  if (modeOfflineAi) modeOfflineAi.addEventListener("click", () => setMode("vs-ai"));

  if (startBtn) {
    startBtn.addEventListener("click", () => {
      const n = playersSelect ? parseInt(playersSelect.value, 10) : 2;
      const level = levelSelect ? parseInt(levelSelect.value, 10) : 2;
      startNewGameDomino(pendingMode, n, level, variantSelect ? variantSelect.value : "classic");
      const status = document.getElementById("offline-domino-status");
      if (status) {
        const levelNames = { 1: "Easy", 2: "Medium", 3: "Hard" };
        I18n.setMsg(status, pendingMode === "vs-ai"
          ? "Computer opponents: " + (n - 1) + " · computer level: " + levelNames[level]
          : "Local " + n + "-player hotseat game (no computer).");
      }
    });
  }

  if (resignBtn) resignBtn.addEventListener("click", resignDomino);

  document.getElementById("domino-end-left").addEventListener("click", () => onEndClickDomino("left"));
  document.getElementById("domino-end-right").addEventListener("click", () => onEndClickDomino("right"));
  document.getElementById("domino-stock-button").addEventListener("click", onDrawClickDomino);
  document.getElementById("domino-pass-button").addEventListener("click", onPassClickDomino);
  document.getElementById("domino-show-hand").addEventListener("click", () => {
    AppStateDomino.revealed = true;
    renderDomino();
    promptHumanDomino();
  });

  setMode("vs-ai");

  const saved = typeof GameStorage !== "undefined" ? GameStorage.load(DOMINO_SAVE_KEY) : null;
  if (saved && saved.state && !saved.state.gameOver) {
    AppStateDomino.mode = saved.mode;
    AppStateDomino.numPlayers = saved.numPlayers;
    AppStateDomino.aiLevel = saved.aiLevel;
    AppStateDomino.state = saved.state;
    AppStateDomino.lastPlaced = saved.lastPlaced || null;
    AppStateDomino.started = true;
    AppStateDomino.gameOver = false;
    AppStateDomino.selected = null;
    AppStateDomino.revealed = saved.mode !== "hotseat";
    setMode(saved.mode);
    if (variantSelect) variantSelect.value = DominoCore.isTriangle(saved.state) ? "triangle" : "classic";
    showBoardDomino();
    renderDomino();
    continueTurnDomino();
  }
}

function showBoardDomino() {
  const placeholder = document.getElementById("board-placeholder");
  const container = document.getElementById("board-container");
  if (placeholder) placeholder.classList.add("hidden");
  if (container) container.classList.remove("hidden");
  const settingsPanel = document.getElementById("settings-panel");
  const menuToggle = document.getElementById("menu-toggle");
  if (settingsPanel) settingsPanel.classList.add("hidden");
  if (menuToggle) I18n.setKey(menuToggle, "menu_toggle");
}

function startNewGameDomino(mode, numPlayers, level, variant) {
  AppStateDomino.mode = mode;
  AppStateDomino.numPlayers = numPlayers;
  AppStateDomino.aiLevel = level;
  AppStateDomino.state = DominoCore.createInitialState(numPlayers, null, variant === "triangle" ? "triangle" : null);
  AppStateDomino.started = true;
  AppStateDomino.gameOver = false;
  AppStateDomino.selected = null;
  AppStateDomino.lastPlaced = null;
  AppStateDomino.result = null;
  AppStateDomino.busy = false;
  setGameResultDomino("");
  showBoardDomino();

  // The opening tile is forced, so it is played straight away.
  const s = AppStateDomino.state;
  const opener = s.turn;
  const index = s.hands[opener].findIndex((t) => DominoCore.sameTile(t, s.openingTile));
  const r = DominoCore.applyMove(s, index, DominoCore.isTriangle(s) ? "0,0" : "right");
  AppStateDomino.state = r.state;
  AppStateDomino.lastPlaced = { side: r.side };
  AppStateDomino.revealed = mode !== "hotseat";
  afterActionDomino(opener, (isYouDomino(opener) ? "You open with " : playerNameDomino(opener) + " opens with ") + tileTextDomino(r.tile) + ".");
}

// Starts whatever the player to move has to do next.
function continueTurnDomino() {
  if (AppStateDomino.gameOver || !AppStateDomino.started) return;
  const s = AppStateDomino.state;
  if (isAiPlayerDomino(s.turn)) {
    if (AppStateDomino.busy) return;
    AppStateDomino.busy = true;
    setTimeout(aiTurnDomino, AiPacing.delay(700));
    return;
  }
  if (AppStateDomino.mode === "hotseat" && !AppStateDomino.revealed) {
    renderDomino();
    return;
  }
  promptHumanDomino();
}

function promptHumanDomino() {
  const s = AppStateDomino.state;
  const action = DominoCore.requiredAction(s);
  const who = isYouDomino(s.turn) ? "Your turn. " : playerNameDomino(s.turn) + "'s turn. ";
  if (action === "play") setStatusDomino(who + chooseTextDomino());
  else if (action === "draw") setStatusDomino(who + "No tile fits - draw from the stock.");
  else if (action === "pass") setStatusDomino(who + passTextDomino());
  renderDomino();
}

function aiTurnDomino() {
  AppStateDomino.busy = false;
  if (AppStateDomino.gameOver || !AppStateDomino.started) return;
  let s = AppStateDomino.state;
  if (!isAiPlayerDomino(s.turn)) return;
  let action = DominoCore.requiredAction(s);
  let drawn = 0;
  while (action === "draw") {
    s = DominoCore.drawTile(s).state;
    drawn++;
    action = DominoCore.requiredAction(s);
  }
  AppStateDomino.state = s;
  if (action === "pass") {
    finishPassDomino(drawn);
    return;
  }
  const move = DominoAi.chooseMove(s, AppStateDomino.aiLevel);
  playMoveDomino(move.index, DominoCore.isTriangle(s) ? move.slot : move.side, drawn);
}

function drewTilesTextDomino(player, keys) {
  const one = keys.length === 1, s = keys.slice(0, -1).join(", "), r = keys[keys.length - 1];
  if (isYouDomino(player)) return one ? "You drew the tile " + r + "." : "You drew the tiles " + s + " and " + r + ".";
  const who = playerNameDomino(player);
  return one ? who + " drew the tile " + r + "." : who + " drew the tiles " + s + " and " + r + ".";
}

function drawNoteDomino(player, drawn) {
  if (!drawn) return "";
  if (isYouDomino(player)) return drawn === 1 ? "You drew 1 tile. " : "You drew " + drawn + " tiles. ";
  const who = playerNameDomino(player);
  return drawn === 1 ? who + " drew 1 tile. " : who + " drew " + drawn + " tiles. ";
}

function playMoveDomino(index, side, drawn) {
  const s = AppStateDomino.state;
  const player = s.turn;
  const r = DominoCore.applyMove(s, index, side);
  AppStateDomino.state = r.state;
  AppStateDomino.lastPlaced = { side: r.side };
  AppStateDomino.selected = null;
  const played = isYouDomino(player) ? "You played " : playerNameDomino(player) + " played ";
  const msg = drawNoteDomino(player, drawn) + played + tileTextDomino(r.tile) + ".";
  afterActionDomino(player, msg);
}

function finishPassDomino(drawn) {
  const player = AppStateDomino.state.turn;
  AppStateDomino.state = DominoCore.pass(AppStateDomino.state);
  AppStateDomino.selected = null;
  afterActionDomino(player, drawNoteDomino(player, drawn) + (isYouDomino(player) ? "You passed." : playerNameDomino(player) + " passed."));
}

function afterActionDomino(player, msg) {
  const s = AppStateDomino.state;
  if (s.gameOver) {
    renderDomino();
    endGameDomino(msg);
    return;
  }
  if (AppStateDomino.mode === "hotseat") {
    AppStateDomino.revealed = false;
    AppStateDomino.newKeys = [];
    msg += " Pass the device to " + playerNameDomino(s.turn) + ".";
  }
  if (AppStateDomino.mode === "vs-ai" && !isAiPlayerDomino(s.turn)) msg += " " + statusPromptDomino();
  setStatusDomino(msg);
  renderDomino();
  saveDominoGame();
  if (isAiPlayerDomino(s.turn)) continueTurnDomino();
}

function statusPromptDomino() {
  const action = DominoCore.requiredAction(AppStateDomino.state);
  if (action === "draw") return "No tile fits - draw from the stock.";
  if (action === "pass") return passTextDomino();
  return chooseTextDomino();
}

function chooseTextDomino() {
  return isTriDomino() ? "Choose a tile, then a marked place." : "Choose a tile, then an open end.";
}

// Why the player has to pass: an empty stock, or (triangles) three tiles
// drawn this turn already.
function passTextDomino() {
  const s = AppStateDomino.state;
  if (isTriDomino() && s.stock.length) return "No tile fits after three draws - pass.";
  return "No tile fits and the stock is empty - pass.";
}

function endGameDomino(lastMsg) {
  const s = AppStateDomino.state;
  AppStateDomino.gameOver = true;
  AppStateDomino.selected = null;
  let title;
  let msg;
  if (s.blocked) {
    msg = lastMsg + (isTriDomino() ? " The board is blocked." : " The line is blocked.");
    if (s.draw) msg += " The lowest pip total is shared - it's a draw.";
    else if (isYouDomino(s.winner)) msg += " You win with the lowest pip total.";
    else msg += " " + playerNameDomino(s.winner) + " wins with the lowest pip total.";
  } else {
    msg = lastMsg + (isYouDomino(s.winner) ? " You played your last tile." : " " + playerNameDomino(s.winner) + " played their last tile.");
  }
  if (s.draw) {
    title = "Draw";
    recordStatsDomino("draw");
  } else if (AppStateDomino.mode === "vs-ai") {
    title = s.winner === 0 ? "You win!" : "You lose";
    recordStatsDomino(s.winner === 0 ? "win" : "loss");
  } else {
    title = playerNameDomino(s.winner) + " wins";
  }
  AppStateDomino.result = msg;
  setGameResultDomino(msg);
  setStatusDomino(msg);
  if (window.ResultModal) window.ResultModal.show(title, msg);
  clearSavedDominoGame();
  renderDomino();
}

function resignDomino() {
  if (AppStateDomino.gameOver || !AppStateDomino.started) return;
  const s = AppStateDomino.state;
  const loser = AppStateDomino.mode === "vs-ai" ? 0 : s.turn;
  // The others' lowest pip total decides who is left as winner.
  let winner = null;
  let low = Infinity;
  s.hands.forEach((h, i) => {
    if (i === loser) return;
    const total = DominoCore.pipTotal(h);
    if (total < low) { low = total; winner = i; }
  });
  s.gameOver = true;
  s.winner = winner;
  AppStateDomino.gameOver = true;
  const msg = (isYouDomino(loser) ? "You resigned. " : playerNameDomino(loser) + " resigned. ") + playerNameDomino(winner) + " wins.";
  const title = AppStateDomino.mode === "vs-ai" ? "You lose" : playerNameDomino(winner) + " wins";
  recordStatsDomino("loss");
  setGameResultDomino(msg);
  setStatusDomino(msg);
  if (window.ResultModal) window.ResultModal.show(title, msg);
  clearSavedDominoGame();
  renderDomino();
}

/*** Human input ***/

function humanCanActDomino() {
  const s = AppStateDomino.state;
  if (!AppStateDomino.started || AppStateDomino.gameOver) return false;
  if (isAiPlayerDomino(s.turn)) {
    setStatusDomino("Computer thinking…");
    return false;
  }
  if (AppStateDomino.mode === "hotseat" && !AppStateDomino.revealed) return false;
  return true;
}

// Whether playable tiles and the places they fit are marked (setting
// "Show move suggestions", move-hints.js; off by default).
function hintsDomino() {
  return typeof MoveHints === "undefined" || MoveHints.enabled();
}

function onHandTileClickDomino(index) {
  if (!humanCanActDomino()) return;
  AppStateDomino.newKeys = [];
  const s = AppStateDomino.state;
  const tile = s.hands[s.turn][index];
  if (!tile) return;
  if (AppStateDomino.selected === index) {
    AppStateDomino.selected = null;
    renderDomino();
    return;
  }
  if (isTriDomino()) {
    const slots = DominoCore.slotsForTile(s, tile);
    if (!slots.length) {
      AppStateDomino.selected = null;
      setStatusDomino("That tile doesn't fit anywhere.");
      renderDomino();
      return;
    }
    AppStateDomino.selected = index;
    if (!hintsDomino()) setStatusDomino("Tap a free place to lay tile " + tileTextDomino(tile) + ".");
    else setStatusDomino(slots.length === 1
      ? "Tap the marked place to lay tile " + tileTextDomino(tile) + "."
      : "Tile " + tileTextDomino(tile) + " fits in " + slots.length + " places - tap one.");
    renderDomino();
    return;
  }
  const sides = DominoCore.sidesForTile(s, tile);
  if (!sides.length) {
    AppStateDomino.selected = null;
    setStatusDomino("That tile doesn't fit on either end.");
    renderDomino();
    return;
  }
  AppStateDomino.selected = index;
  if (!hintsDomino()) setStatusDomino("Tap an end to place tile " + tileTextDomino(tile) + ".");
  else setStatusDomino(sides.length === 2
    ? "Tile " + tileTextDomino(tile) + " fits on both ends - tap one."
    : "Tap the highlighted end to place tile " + tileTextDomino(tile) + ".");
  renderDomino();
}

function onEndClickDomino(side) {
  if (!humanCanActDomino()) return;
  const s = AppStateDomino.state;
  if (AppStateDomino.selected === null) {
    setStatusDomino("Choose a tile from your hand first.");
    return;
  }
  const tile = s.hands[s.turn][AppStateDomino.selected];
  if (DominoCore.sidesForTile(s, tile).indexOf(side) === -1) {
    setStatusDomino("That tile doesn't fit on this end.");
    return;
  }
  playMoveDomino(AppStateDomino.selected, side, 0);
}

function onSlotClickDomino(slot) {
  if (!humanCanActDomino()) return;
  const s = AppStateDomino.state;
  if (AppStateDomino.selected === null) return;
  const tile = s.hands[s.turn][AppStateDomino.selected];
  if (DominoCore.slotsForTile(s, tile).indexOf(slot) === -1) {
    setStatusDomino("That tile doesn't fit here.");
    return;
  }
  playMoveDomino(AppStateDomino.selected, slot, 0);
}

function onDrawClickDomino() {
  if (!humanCanActDomino()) return;
  let s = AppStateDomino.state;
  if (DominoCore.requiredAction(s) !== "draw") {
    setStatusDomino(DominoCore.canPlay(s, s.turn) ? "You have a tile that fits - no need to draw." : "The stock is empty.");
    return;
  }
  const player = s.turn;
  const had = new Set(s.hands[player].map(tileTextDomino));
  let drawn = 0;
  while (DominoCore.requiredAction(s) === "draw") {
    s = DominoCore.drawTile(s).state;
    drawn++;
  }
  AppStateDomino.state = s;
  AppStateDomino.selected = null;
  // The drawer's hand stays open (the turn goes on with a play or a pass),
  // so the new tiles are named and marked - on one device too.
  const fresh = s.hands[player].map(tileTextDomino).filter((k) => !had.has(k));
  AppStateDomino.newKeys = fresh;
  const note = fresh.length ? drewTilesTextDomino(player, fresh) + " " : drawNoteDomino(player, drawn);
  if (DominoCore.requiredAction(s) === "pass") setStatusDomino(note + passTextDomino());
  else setStatusDomino(note + chooseTextDomino());
  renderDomino();
  saveDominoGame();
}

function onPassClickDomino() {
  if (!humanCanActDomino()) return;
  AppStateDomino.newKeys = [];
  const s = AppStateDomino.state;
  if (DominoCore.requiredAction(s) !== "pass") {
    setStatusDomino(DominoCore.canPlay(s, s.turn) ? "You have a tile that fits - no need to pass." : "Draw from the stock first.");
    return;
  }
  finishPassDomino(0);
}

/*** Rendering ***/

function renderDomino() {
  const s = AppStateDomino.state;
  if (!s) return;
  renderPlayersDomino(s);
  const tri = DominoCore.isTriangle(s);
  const endsRow = document.querySelector(".domino-ends");
  const lineEl = document.getElementById("domino-line");
  const gridEl = document.getElementById("domino-grid");
  if (endsRow) endsRow.classList.toggle("hidden", tri);
  if (lineEl) lineEl.classList.toggle("hidden", tri);
  if (gridEl) gridEl.classList.toggle("hidden", !tri);
  if (tri) {
    renderGridDomino(s);
  } else {
    renderEndsDomino(s);
    renderLineDomino(s);
  }
  renderHandDomino(s);
  renderButtonsDomino(s);
  const resignBtn = document.getElementById("resign-button");
  if (resignBtn) resignBtn.classList.toggle("hidden", AppStateDomino.gameOver || !AppStateDomino.started);
}

function renderPlayersDomino(s) {
  const el = document.getElementById("domino-players");
  if (!el) return;
  el.innerHTML = "";
  s.hands.forEach((hand, i) => {
    const row = document.createElement("div");
    row.className = "game-player" + (i === s.turn && !AppStateDomino.gameOver ? " game-player-active" : "");
    const name = document.createElement("span");
    name.className = "game-player-name";
    I18n.setMsg(name, playerNameDomino(i));
    const count = document.createElement("span");
    count.className = "game-player-count";
    if (AppStateDomino.gameOver) {
      const total = DominoCore.pipTotal(hand);
      I18n.setMsg(count, hand.length + " tiles, " + total + " pips");
    } else {
      I18n.setMsg(count, hand.length === 1 ? "1 tile" : hand.length + " tiles");
    }
    row.appendChild(name);
    row.appendChild(count);
    el.appendChild(row);
  });
  const stock = document.createElement("div");
  stock.className = "game-player game-player-stock";
  const sName = document.createElement("span");
  sName.className = "game-player-name";
  I18n.setMsg(sName, "Stock: " + s.stock.length + " tiles");
  stock.appendChild(sName);
  el.appendChild(stock);
}

function renderEndsDomino(s) {
  const ends = DominoCore.openEnds(s);
  const sel = AppStateDomino.selected;
  const selTile = sel !== null ? s.hands[s.turn][sel] : null;
  const fitting = selTile && hintsDomino() ? DominoCore.sidesForTile(s, selTile) : [];
  const last = AppStateDomino.lastPlaced ? AppStateDomino.lastPlaced.side : null;
  ["left", "right"].forEach((side) => {
    const btn = document.getElementById("domino-end-" + side);
    if (!btn) return;
    const value = ends ? ends[side] : null;
    btn.textContent = value === null ? "" : String(value);
    // On an empty line only the end the opening tile may go on is live.
    const canOpen = !ends && DominoCore.legalMoves(s, s.turn).some((m) => m.side === side);
    btn.disabled = AppStateDomino.gameOver || (!ends && !canOpen);
    btn.classList.toggle("domino-end-fits", fitting.indexOf(side) !== -1);
    btn.classList.toggle("domino-end-last", last === side);
    let label = (side === "left" ? "Left end " : "Right end ") + (value === null ? "" : value);
    if (fitting.indexOf(side) !== -1) label += ", fits";
    I18n.setAria(btn, label.trim());
  });
}

function renderLineDomino(s) {
  const el = document.getElementById("domino-line");
  if (!el) return;
  el.innerHTML = "";
  const last = AppStateDomino.lastPlaced ? AppStateDomino.lastPlaced.side : null;
  s.line.forEach((tile, i) => {
    const span = document.createElement("span");
    const dbl = DominoCore.isDouble(tile);
    span.className = "domino-tile domino-line-tile" + (dbl ? " domino-tile-double" : "");
    const isLast = (last === "left" && i === 0) || (last === "right" && i === s.line.length - 1);
    if (isLast) span.classList.add("domino-tile-last");
    span.innerHTML = tileSvgDomino(tile, dbl);
    el.appendChild(span);
  });
  // Keep the end that just changed in view.
  if (last === "left") el.scrollLeft = 0;
  else el.scrollLeft = el.scrollWidth;
}

// The board of triangles, scaled to the width: every laid tile with its
// corner numbers (the latest one with a thick outline) and, while a tile
// is picked, the free triangles it fits on as numbered, dashed places.
function renderGridDomino(s) {
  const el = document.getElementById("domino-grid");
  if (!el) return;
  const sel = AppStateDomino.selected;
  const selTile = sel !== null && s.hands[s.turn] ? s.hands[s.turn][sel] : null;
  // Without suggestions every free place is offered; a wrong one is
  // refused when tapped.
  const targets = !selTile || AppStateDomino.gameOver ? [] : hintsDomino() ? DominoCore.slotsForTile(s, selTile) : DominoCore.openSlots(s);
  const all = s.slots.concat(targets).concat(DominoCore.openSlots(s));
  if (!all.length) { el.innerHTML = ""; return; }
  let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
  all.forEach((slot) => {
    const rc = DominoCore.parseSlot(slot);
    triPointsDomino(rc[0], rc[1]).forEach((p) => {
      minX = Math.min(minX, p[0]); maxX = Math.max(maxX, p[0]);
      minY = Math.min(minY, p[1]); maxY = Math.max(maxY, p[1]);
    });
  });
  const pad = 4;
  const vbW = maxX - minX + 2 * pad, vbH = maxY - minY + 2 * pad;
  const last = AppStateDomino.lastPlaced ? AppStateDomino.lastPlaced.side : null;
  // At least 36 px per triangle side (wider boards scroll inside their
  // frame, never the page), at most 96 px.
  let svg = '<div class="domino-grid-inner" style="min-width:' + Math.round(vbW * 0.6) + "px;max-width:" + Math.round(vbW * 1.6) + 'px">' +
    '<svg class="domino-grid-svg" viewBox="' + (minX - pad) + " " + (minY - pad) + " " + vbW + " " + vbH +
    '" aria-hidden="true" focusable="false">';
  s.slots.forEach((slot) => {
    const rc = DominoCore.parseSlot(slot);
    const pts = triPointsDomino(rc[0], rc[1]);
    const cx = (pts[0][0] + pts[1][0] + pts[2][0]) / 3, cy = (pts[0][1] + pts[1][1] + pts[2][1]) / 3;
    svg += '<path class="domino-face' + (slot === last ? " domino-tri-last" : "") + '" d="M' + pts.map((p) => p[0] + " " + p[1]).join("L") + 'Z"/>';
    s.board[slot].forEach((v, i) => {
      const x = pts[i][0] + (cx - pts[i][0]) * 0.55, y = pts[i][1] + (cy - pts[i][1]) * 0.55 + 4.5;
      svg += '<text class="domino-tri-num domino-tri-num-board" x="' + x.toFixed(1) + '" y="' + y.toFixed(1) + '">' + v + "</text>";
    });
  });
  svg += "</svg></div>";
  el.innerHTML = svg;
  const inner = el.firstChild;
  // The places to tap are buttons laid over the drawing, so they can be
  // reached and read out like any other button.
  const overlay = document.createElement("div");
  overlay.className = "domino-grid-places";
  targets.forEach((slot, i) => {
    const rc = DominoCore.parseSlot(slot);
    const pts = triPointsDomino(rc[0], rc[1]);
    const cx = (pts[0][0] + pts[1][0] + pts[2][0]) / 3, cy = (pts[0][1] + pts[1][1] + pts[2][1]) / 3;
    const marker = document.createElementNS("http://www.w3.org/2000/svg", "path");
    marker.setAttribute("class", "domino-tri-place");
    marker.setAttribute("d", "M" + pts.map((p) => p[0] + " " + p[1]).join("L") + "Z");
    inner.firstChild.appendChild(marker);
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "domino-place-btn";
    btn.textContent = String(i + 1);
    btn.style.left = ((cx - (minX - pad)) / vbW * 100) + "%";
    btn.style.top = ((cy - (minY - pad)) / vbH * 100) + "%";
    I18n.setAria(btn, "Free place " + (i + 1));
    btn.addEventListener("click", () => onSlotClickDomino(slot));
    overlay.appendChild(btn);
  });
  inner.appendChild(overlay);
}

function renderHandDomino(s) {
  const handEl = document.getElementById("domino-hand");
  const cover = document.getElementById("domino-hand-cover");
  const coverText = document.getElementById("domino-hand-cover-text");
  if (!handEl) return;
  const hidden = AppStateDomino.mode === "hotseat" && !AppStateDomino.revealed && !AppStateDomino.gameOver;
  if (cover) cover.classList.toggle("hidden", !hidden);
  if (hidden && coverText) I18n.setMsg(coverText, "Pass the device to " + playerNameDomino(s.turn) + ".");
  handEl.classList.toggle("hidden", hidden);
  handEl.innerHTML = "";
  if (hidden) return;
  const viewer = viewerDomino();
  const myTurn = s.turn === viewer && !AppStateDomino.gameOver;
  s.hands[viewer].forEach((tile, i) => {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "domino-tile domino-hand-tile";
    const fits = myTurn && (DominoCore.isTriangle(s) ? DominoCore.slotsForTile(s, tile) : DominoCore.sidesForTile(s, tile)).length > 0;
    if (!fits && hintsDomino()) btn.classList.add("domino-tile-unplayable");
    if (AppStateDomino.selected === i) btn.classList.add("domino-tile-selected");
    const fresh = (AppStateDomino.newKeys || []).indexOf(tileTextDomino(tile)) !== -1;
    if (fresh) btn.classList.add("card-new");
    if (DominoCore.isTriangle(s)) btn.classList.add("domino-hand-tri");
    btn.innerHTML = DominoCore.isTriangle(s) ? triTileSvgDomino(tile) : tileSvgDomino(tile, false);
    let label = "Tile " + tileTextDomino(tile);
    if (AppStateDomino.selected === i) label += ", selected";
    if (fresh) label += ", new";
    I18n.setAria(btn, label);
    btn.addEventListener("click", () => onHandTileClickDomino(i));
    handEl.appendChild(btn);
  });
}

function renderButtonsDomino(s) {
  const drawBtn = document.getElementById("domino-stock-button");
  const passBtn = document.getElementById("domino-pass-button");
  const humanTurn = AppStateDomino.started && !AppStateDomino.gameOver && !isAiPlayerDomino(s.turn) &&
    (AppStateDomino.mode !== "hotseat" || AppStateDomino.revealed);
  const action = DominoCore.requiredAction(s);
  if (drawBtn) {
    drawBtn.disabled = !(humanTurn && action === "draw");
    drawBtn.classList.toggle("hidden", !humanTurn || action !== "draw");
  }
  if (passBtn) {
    passBtn.disabled = !(humanTurn && action === "pass");
    passBtn.classList.toggle("hidden", !humanTurn || action !== "pass");
  }
}

document.addEventListener("DOMContentLoaded", initDominoApp);
