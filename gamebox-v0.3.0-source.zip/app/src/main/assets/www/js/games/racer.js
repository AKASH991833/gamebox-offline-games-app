(function(){
"use strict";
var SLUG="racer",W=300,H=480,LANES=3,laneW=W/LANES;
var cv=document.getElementById("cv"),ctx=GB.ctx(cv,W,H);
GB.shell({title:"Road Rush",chips:[{id:"score",label:"Score"},{id:"best",label:"Best",value:GB.best(SLUG)}],
 rules:"<ul><li><b>Swipe</b> or tap the left/right half to change lanes.</li><li>Dodge traffic. Each coin is <b>+25</b> points; distance adds up on its own.</li><li>Traffic gets faster and denser the longer you survive.</li><li>One crash ends the run.</li></ul>"});
var lane,playerX,cars,coins,speed,dist,alive,spawnT,coinT,roadT,coinBonus,lastShown;
function setChip(id,v){var e=document.getElementById(id);if(e)e.textContent=v;}
function laneX(l){return l*laneW+laneW/2;}
function start(){
 lane=1;playerX=laneX(1);cars=[];coins=[];speed=200;dist=0;alive=true;spawnT=0.9;coinT=1.6;roadT=0;coinBonus=0;lastShown=-1;
 setChip("score",0);setChip("best",GB.best(SLUG));draw();}
function shift(d){if(!alive)return;var nl=Math.max(0,Math.min(LANES-1,lane+d));
 if(nl!==lane){lane=nl;GB.sfx.flip();}}
function spawnCar(){
 var used=cars.filter(function(c){return c.y<140;}).map(function(c){return c.lane;});
 var free=[0,1,2].filter(function(l){return used.indexOf(l)<0;});
 if(!free.length)return;
 var l=free[(Math.random()*free.length)|0];
 cars.push({lane:l,y:-70,w:laneW*0.52,h:64,speed:speed*(0.55+Math.random()*0.2),
  color:["#F43F5E","#60A5FA","#FACC15","#C084FC"][(Math.random()*4)|0]});}
function step(dt){
 roadT+=dt;
 if(!alive)return;
 speed=200+Math.min(260,dist*0.5);
 dist+=speed*dt*0.02;
 var tot=Math.floor(dist)+coinBonus;
 if(tot!==lastShown){lastShown=tot;setChip("score",tot);
  if(tot>GB.best(SLUG)){GB.saveBest(SLUG,tot);setChip("best",tot);}}
 playerX+=(laneX(lane)-playerX)*Math.min(1,dt*14);
 spawnT-=dt;if(spawnT<=0){spawnCar();spawnT=Math.max(0.5,1.05-dist*0.004)+Math.random()*0.4;}
 coinT-=dt;if(coinT<=0){coins.push({lane:(Math.random()*3)|0,y:-20,taken:false});coinT=1.4+Math.random();}
 cars.forEach(function(c){c.y+=(speed-c.speed*0.35)*dt;});
 cars=cars.filter(function(c){return c.y<H+80;});
 coins.forEach(function(c){c.y+=speed*dt;});
 coins=coins.filter(function(c){return c.y<H+30&&!c.taken;});
 coins.forEach(function(c){
  if(!c.taken&&c.lane===lane&&Math.abs(c.y-(H-70))<40){c.taken=true;coinBonus+=25;GB.sfx.point();GB.buzz(12);}});
 for(var i=0;i<cars.length;i++){var c=cars[i];
  if(c.lane===lane&&Math.abs(c.y-(H-70))<(c.h+52)/2-8){
   alive=false;var t2=Math.floor(dist)+coinBonus;GB.saveBest(SLUG,t2);GB.sfx.die();GB.buzz(80);
   GB.gameOver({title:"Crash!",sub:"Score: <b>"+t2+"</b> &nbsp; Best: <b>"+GB.best(SLUG)+"</b>",onAgain:start});
   return;}}}
function drawCar(x,y,w,h,color){
 ctx.fillStyle=color;
 ctx.beginPath();
 if(ctx.roundRect)ctx.roundRect(x-w/2,y-h/2,w,h,10);else ctx.rect(x-w/2,y-h/2,w,h);
 ctx.fill();
 ctx.fillStyle="rgba(0,0,0,.3)";ctx.fillRect(x-w/2+5,y-h/2+8,w-10,10);
 ctx.fillStyle="rgba(255,255,255,.5)";ctx.fillRect(x-w/2+5,y+h/2-16,w-10,8);}
function draw(){
 ctx.fillStyle=GB.isDark()?"#241741":"#DDD3F0";ctx.fillRect(0,0,W,H);
 ctx.fillStyle=GB.isDark()?"#1B1132":"#CFC2E6";ctx.fillRect(0,0,14,H);ctx.fillRect(W-14,0,14,H);
 ctx.fillStyle=GB.isDark()?"rgba(255,255,255,.35)":"rgba(36,22,64,.3)";
 var off=(roadT*speed)%44;
 for(var l=1;l<LANES;l++)for(var y=-44+off;y<H;y+=44)ctx.fillRect(l*laneW-2,y,4,24);
 coins.forEach(function(c){
  var p=1+Math.sin(performance.now()/180)*0.1;
  ctx.fillStyle="#FACC15";ctx.beginPath();ctx.arc(laneX(c.lane),c.y,11*p,0,7);ctx.fill();
  ctx.fillStyle="#B45309";ctx.font="bold 13px sans-serif";ctx.textAlign="center";
  ctx.fillText("$",laneX(c.lane),c.y+4.5);ctx.textAlign="left";});
 cars.forEach(function(c){drawCar(laneX(c.lane),c.y,c.w,c.h,c.color);});
 drawCar(playerX,H-70,laneW*0.5,54,"#4ADE80");
 ctx.fillStyle="rgba(0,0,0,.25)";ctx.fillRect(playerX-laneW*0.25+6,H-70-19,laneW*0.5-12,9);}
GB.loop(step,draw);
GB.swipe(document.querySelector(".stage"),function(d){
 if(d==="left")shift(-1);else if(d==="right")shift(1);});
document.querySelector(".gm-wrap").addEventListener("click",function(e){
 var r=e.currentTarget.getBoundingClientRect();
 shift((e.clientX-r.left)>r.width/2?1:-1);});
document.addEventListener("keydown",function(e){
 if(e.key==="ArrowLeft"){e.preventDefault();shift(-1);}
 else if(e.key==="ArrowRight"){e.preventDefault();shift(1);}});
GB.game.restart=start;
start();
})();
