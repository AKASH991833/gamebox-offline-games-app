(function(){
"use strict";
var GB=window.GB={
 store:{get:function(k,d){try{var v=localStorage.getItem("gb_"+k);return v===null?d:JSON.parse(v)}catch(e){return d}},set:function(k,v){try{localStorage.setItem("gb_"+k,JSON.stringify(v))}catch(e){}}},
 saveBest:function(slug,val){var cur=GB.store.get("best_"+slug,null);if(cur===null||val>cur)GB.store.set("best_"+slug,val);},
 best:function(slug){return GB.store.get("best_"+slug,0);}
};
var qp=new URLSearchParams(location.search).get("theme");if(qp==="light"||qp==="dark")GB.store.set("theme",qp);
document.documentElement.setAttribute("data-theme",GB.store.get("theme","dark"));
document.addEventListener("DOMContentLoaded",function(){
 var b=document.querySelector(".backbtn");
 if(b)b.addEventListener("click",function(){location.href="../index.html";});
});
})();
