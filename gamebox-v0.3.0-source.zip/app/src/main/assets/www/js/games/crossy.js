(function(){
"use strict";
var SLUG="crossy",COLS=9,VROWS=14,CELL=40,W=COLS*CELL,H=VROWS*CELL;
var cv=document.getElementById("cv"),ctx=GB.ctx(cv,W,H);
GB.shell({title:"Crossy Dash",chips:[{id:"score",label:"Score"},{id:"best",label:"Best",value:GB.best(SLUG)}],
 rules:"<ul><li><b>Tap</b> to hop one row forward. Swipe to hop sideways or back.</li><li>Cars, trucks and buses fill the road rows - time your crossing.</li><li>Grass rows are safe. Score is how many rows you cross.</li><li>Standing on a road when a vehicle passes through you ends the run.</li></ul>"});
var rows,player,camY,score,alive,hopT;
function setChip(id,v){var e=document.getElementById(id);if(e)e.textContent=v;}
var CCOLORS=["#F43F5E","#60A5FA","#FACC15","#C084FC","#FB923C","#2DD4BF"];
function makeRow(i){
 if(i<2||Math.random()<0.32)return{type:"grass",i:i};
 var dir=Math.random()<0.5?1:-1,speed=(40+Math.random()*70+score*1.5)*dir;
 var r={type:"road",i:i,cars:[],speed:speed};
 var n=1+((Math.random()*2.4)|0);
 for(var k=0;k<n;k++)r.cars.push({x:Math.random()*W,w:44+Math.random()*30,
  color:CCOLORS[(Math.random()*CCOLORS.length)|0]});
 return r;}
function ensure(){
 var maxI=rows[rows.length-1].i;
 while(maxI<player.row+VROWS){maxI++;rows.push(makeRow(maxI));}
 rows=rows.filter(function(r){return r.i>player.row-3;});}
function start(){
 rows=[];player={col:4,row:0,px:4*CELL+CELL/2,py:0};camY=0;score=0;alive=true;hopT=0;
 for(var i=-2;i<VROWS+2;i++)rows.push(makeRow(i));
 player.py=rowY(0);
 setChip("score",0);setChip("best",GB.best(SLUG));draw();}
function rowY(i){return H-CELL*1.5-(i-player.row)*CELL;}
function hop(dx,dr){
 if(!alive||hopT>0)return;
 var nc=player.col+dx,nr=player.row+dr;
 if(nc<0||nc>=COLS||nr<-1)return;
 player.col=nc;player.row=nr;hopT=0.12;GB.sfx.flip();GB.buzz(8);
 if(nr>score){score=nr;setChip("score",score);
  if(score>GB.best(SLUG)){GB.saveBest(SLUG,score);setChip("best",score);}}
 ensure();}
function die(){alive=false;GB.saveBest(SLUG,score);GB.sfx.die();GB.buzz(80);
 GB.gameOver({title:"Squashed!",sub:"Rows crossed: <b>"+score+"</b> &nbsp; Best: <b>"+GB.best(SLUG)+"</b>",onAgain:start});}
function step(dt){
 if(hopT>0)hopT-=dt;
 var tx=player.col*CELL+CELL/2,ty=rowY(player.row);
 player.px+=(tx-player.px)*Math.min(1,dt*16);
 player.py+=(ty-player.py)*Math.min(1,dt*16);
 if(!alive)return;
 rows.forEach(function(r){
  if(r.type!=="road")return;
  r.cars.forEach(function(c){
   c.x+=r.speed*dt;
   if(r.speed>0&&c.x>W+c.w)c.x=-c.w-Math.random()*120;
   if(r.speed<0&&c.x<-c.w*2)c.x=W+Math.random()*120;});});
 var pr=rows.filter(function(r){return r.i===player.row;})[0];
 if(pr&&pr.type==="road"){
  var pxx=player.col*CELL+CELL/2;
  for(var i=0;i<pr.cars.length;i++){var c=pr.cars[i];
   if(Math.abs(c.x-pxx)<(c.w/2+CELL*0.32)){die();return;}}}}
function draw(){
 ctx.fillStyle=GB.isDark()?"#1E1338":"#EFE9FB";ctx.fillRect(0,0,W,H);
 rows.forEach(function(r){
  var y=rowY(r.i);
  if(r.type==="grass"){
   ctx.fillStyle=(r.i%2===0)?(GB.isDark()?"#1F3D2B":"#D9EFE0"):(GB.isDark()?"#23473333":"#D9EFE0");
   ctx.fillStyle=(r.i%2===0)?(GB.isDark()?"#1F3D2B":"#CDE9D8"):(GB.isDark()?"#24455a3":"#C2E2CF");
   ctx.fillStyle=(r.i%2===0)?(GB.isDark()?"#21472F":"#CDE9D8"):(GB.isDark()?"#274F35":"#BFE3CE");
   ctx.fillRect(0,y-CELL/2,W,CELL);
   ctx.fillStyle=GB.isDark()?"rgba(255,255,255,.05)":"rgba(36,22,64,.05)";
   for(var g=0;g<4;g++)ctx.fillRect(((r.i*37+g*97)%W),y-6+g%2*10,3,8);}
  else{
   ctx.fillStyle=GB.isDark()?"#241741":"#D5C9EA";ctx.fillRect(0,y-CELL/2,W,CELL);
   ctx.fillStyle=GB.isDark()?"rgba(255,255,255,.25)":"rgba(36,22,64,.2)";
   for(var d=0;d<W;d+=36)ctx.fillRect(d+((r.i%2)*18),y-1.5,16,3);
   r.cars.forEach(function(c){
    ctx.fillStyle=c.color;
    ctx.beginPath();
    if(ctx.roundRect)ctx.roundRect(c.x-c.w/2,y-13,c.w,26,8);else ctx.rect(c.x-c.w/2,y-13,c.w,26);
    ctx.fill();
    ctx.fillStyle="rgba(255,255,255,.45)";
    var fw=r.speed>0?c.w/2-8:-c.w/2+8;
    ctx.fillRect(c.x+fw-4,y-9,8,7);});}});
 var hop=hopT>0?Math.sin((0.12-hopT)/0.12*Math.PI)*8:0;
 var px=player.px,py=player.py-hop;
 ctx.fillStyle="#4ADE80";ctx.beginPath();ctx.arc(px,py,13,0,7);ctx.fill();
 ctx.fillStyle="#BBF7D0";ctx.beginPath();ctx.arc(px,py-9,7.5,0,7);ctx.fill();
 ctx.fillStyle="#14532D";ctx.beginPath();ctx.arc(px+3,py-10,1.8,0,7);ctx.fill();}
GB.loop(step,draw);
var stage=document.querySelector(".stage");
stage.addEventListener("touchstart",function(e){hop(0,1);},{passive:true});
stage.addEventListener("mousedown",function(){hop(0,1);});
GB.swipe(stage,function(d){
 if(d==="left")hop(-1,0);else if(d==="right")hop(1,0);
 else if(d==="up")hop(0,1);else hop(0,-1);},20);
document.addEventListener("keydown",function(e){
 var m={ArrowLeft:[-1,0],ArrowRight:[1,0],ArrowUp:[0,1],ArrowDown:[0,-1]}[e.key];
 if(m){e.preventDefault();hop(m[0],m[1]);}});
GB.game.restart=start;
start();
})();
