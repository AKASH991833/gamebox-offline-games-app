(function(){
"use strict";
var SLUG="breakout",W=360,H=480;
var cv=document.getElementById("cv"),ctx=GB.ctx(cv,W,H);
GB.shell({title:"Brick Breaker",chips:[{id:"score",label:"Score"},{id:"best",label:"Best",value:GB.best(SLUG)}],
 rules:"<ul><li><b>Drag</b> anywhere on the board to move the paddle.</li><li>Clear all bricks to advance a level - the ball gets faster each level.</li><li>You have <b>3 lives</b>. Where the ball hits the paddle changes its angle.</li></ul>"});
var COLS=["#F43F5E","#F97316","#FACC15","#4ADE80","#22D3EE","#A78BFA"];
var paddle,ball,bricks,parts,score,lives,level,playing,serve=true;
function setChip(id,v){var e=document.getElementById(id);if(e)e.textContent=v;}
function buildLevel(lv){
 bricks=[];var rows=Math.min(4+lv,7);
 for(var r=0;r<rows;r++)for(var c=0;c<7;c++)
  bricks.push({x:10+c*49,y:56+r*26,w:44,h:18,color:COLS[r%COLS.length],hit:false});}
function resetBall(){
 ball={x:paddle.x+paddle.w/2,y:paddle.y-10,dx:0,dy:0,r:7,sp:250+level*22};serve=true;}
function start(){
 paddle={x:W/2-42,w:84,h:12,y:H-34};
 score=0;lives=3;level=1;playing=true;parts=[];
 buildLevel(1);resetBall();hud();}
function hud(){setChip("score",score);setChip("best",GB.best(SLUG));}
function launch(){
 if(!serve||!playing)return;serve=false;
 var a=-Math.PI/2+(Math.random()*0.5-0.25);
 ball.dx=Math.cos(a)*ball.sp;ball.dy=Math.sin(a)*ball.sp;GB.sfx.tap();}
function burst(x,y,color){
 for(var i=0;i<10;i++)parts.push({x:x,y:y,dx:(Math.random()-0.5)*220,dy:(Math.random()-0.5)*220-60,t:0.45,color:color});}
function step(dt){
 if(!playing)return;
 parts.forEach(function(p){p.t-=dt;p.x+=p.dx*dt;p.y+=p.dy*dt;p.dy+=500*dt;});
 parts=parts.filter(function(p){return p.t>0;});
 if(serve){ball.x=paddle.x+paddle.w/2;ball.y=paddle.y-10;return;}
 ball.x+=ball.dx*dt;ball.y+=ball.dy*dt;
 if(ball.x<ball.r){ball.x=ball.r;ball.dx=Math.abs(ball.dx);GB.sfx.hit();}
 if(ball.x>W-ball.r){ball.x=W-ball.r;ball.dx=-Math.abs(ball.dx);GB.sfx.hit();}
 if(ball.y<ball.r){ball.y=ball.r;ball.dy=Math.abs(ball.dy);GB.sfx.hit();}
 if(ball.dy>0&&ball.y+ball.r>=paddle.y&&ball.y-ball.r<=paddle.y+paddle.h&&ball.x>=paddle.x-4&&ball.x<=paddle.x+paddle.w+4){
  var off=(ball.x-(paddle.x+paddle.w/2))/(paddle.w/2);
  var ang=-Math.PI/2+off*1.1,sp=Math.min(560,Math.hypot(ball.dx,ball.dy)*1.015);
  ball.dx=Math.cos(ang)*sp;ball.dy=Math.sin(ang)*sp;ball.y=paddle.y-ball.r-0.5;GB.sfx.hit();GB.buzz(8);}
 if(ball.y>H+24){lives--;hud();GB.buzz(70);
  if(lives<=0){playing=false;GB.saveBest(SLUG,score);
   GB.gameOver({title:"Game Over",sub:"Score: <b>"+score+"</b> &nbsp; Level: <b>"+level+"</b>",onAgain:start});return;}
  resetBall();return;}
 for(var i=0;i<bricks.length;i++){var b=bricks[i];if(b.hit)continue;
  if(ball.x>b.x-ball.r&&ball.x<b.x+b.w+ball.r&&ball.y>b.y-ball.r&&ball.y<b.y+b.h+ball.r){
   b.hit=true;score+=10;hud();GB.sfx.point();burst(b.x+b.w/2,b.y+b.h/2,b.color);
   var ox=Math.min(ball.x-b.x+b.r,b.x+b.w-ball.x+b.r),oy=Math.min(ball.y-b.y+b.r,b.y+b.h-ball.y+b.r);
   if(ox<oy)ball.dx*=-1;else ball.dy*=-1;
   if(bricks.every(function(k){return k.hit})){
    level++;score+=50;hud();GB.sfx.win();
    GB.toast("Level "+level+"! +50 bonus");buildLevel(level);resetBall();}
   break;}}}
function rr(x,y,w,h,r){ctx.beginPath();ctx.moveTo(x+r,y);ctx.arcTo(x+w,y,x+w,y+h,r);ctx.arcTo(x+w,y+h,x,y+h,r);ctx.arcTo(x,y+h,x,y,r);ctx.arcTo(x,y,x+w,y,r);ctx.closePath();ctx.fill();}
function draw(){
 ctx.fillStyle=GB.isDark()?"#1E1338":"#EFE9FB";ctx.fillRect(0,0,W,H);
 bricks.forEach(function(b){if(!b.hit){ctx.fillStyle=b.color;rr(b.x,b.y,b.w,b.h,6);}});
 parts.forEach(function(p){ctx.globalAlpha=Math.max(0,p.t/0.45);ctx.fillStyle=p.color;
  ctx.fillRect(p.x-2,p.y-2,4,4);});ctx.globalAlpha=1;
 var g=ctx.createLinearGradient(paddle.x,0,paddle.x+paddle.w,0);
 g.addColorStop(0,"#8B5CF6");g.addColorStop(1,"#C4B5FD");
 ctx.fillStyle=g;rr(paddle.x,paddle.y,paddle.w,paddle.h,6);
 ctx.fillStyle="#FFD93D";ctx.beginPath();ctx.arc(ball.x,ball.y,ball.r,0,7);ctx.fill();
 for(var li=0;li<lives;li++){ctx.fillStyle="#F43F5E";ctx.beginPath();ctx.arc(16+li*18,H-14,5.5,0,7);ctx.fill();}
 if(serve&&playing){ctx.fillStyle=GB.isDark()?"rgba(255,255,255,.55)":"rgba(36,22,64,.55)";
  ctx.font="700 15px sans-serif";ctx.textAlign="center";ctx.fillText("Tap to launch",W/2,H/2+60);}}
GB.loop(step,draw);
GB.dragX(cv,W,function(x){paddle.x=Math.max(0,Math.min(W-paddle.w,x-paddle.w/2));});
cv.addEventListener("touchstart",function(){launch();},{passive:true});
cv.addEventListener("mousedown",function(){launch();});
document.addEventListener("keydown",function(e){if(e.key===" "){e.preventDefault();launch();}});
GB.game.restart=start;
start();
})();
