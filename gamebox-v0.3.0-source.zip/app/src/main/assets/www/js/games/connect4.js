(function(){
"use strict";
var SLUG="connect4",C=7,R=6;
GB.shell({title:"Connect Four",pausable:false,chips:[{id:"score",label:"Streak"},{id:"best",label:"Best",value:GB.best(SLUG)}],
 rules:"<ul><li>Drop discs into a column - first to make <b>4 in a row</b> wins (any direction).</li><li><b>Vs Computer</b>: you are Red. Easy plays casually, Hard thinks several moves ahead.</li><li><b>2 Players</b>: pass the phone, Red and Yellow alternate.</li><li>Your streak counts consecutive wins against the computer.</li></ul>"});
var board,over,mode="ai",diff="normal",streak=0;
var boardEl=document.getElementById("board"),statusEl=document.getElementById("status");
function setChip(id,v){var e=document.getElementById(id);if(e)e.textContent=v;}
function emptyBoard(){var b=[];for(var r=0;r<R;r++)b.push(new Array(C).fill(""));return b;}
function dropRow(b,c){for(var r=R-1;r>=0;r--)if(!b[r][c])return r;return -1;}
function winCells(b,p){
 var dirs=[[0,1],[1,0],[1,1],[1,-1]];
 for(var r=0;r<R;r++)for(var c=0;c<C;c++){
  if(b[r][c]!==p)continue;
  for(var d=0;d<4;d++){
   var cells=[[r,c]],ok=true;
   for(var k=1;k<4;k++){
    var nr=r+dirs[d][0]*k,nc=c+dirs[d][1]*k;
    if(nr<0||nr>=R||nc<0||nc>=C||b[nr][nc]!==p){ok=false;break;}
    cells.push([nr,nc]);}
   if(ok)return cells;}}
 return null;}
function full(b){for(var c=0;c<C;c++)if(!b[0][c])return false;return true;}
function scoreWindow(cells,p){
 var me=0,op=0,empty=0;
 cells.forEach(function(v){if(v===p)me++;else if(v==="")empty++;else op++;});
 if(me===4)return 10000;
 if(me===3&&empty===1)return 60;
 if(me===2&&empty===2)return 8;
 if(op===3&&empty===1)return -90;
 return 0;}
function evaluate(b,p){
 var op=p==="Y"?"R":"Y",s=0;
 for(var r=0;r<R;r++)if(b[r][3]===p)s+=4;
 var dirs=[[0,1],[1,0],[1,1],[1,-1]];
 for(r=0;r<R;r++)for(var c=0;c<C;c++){
  for(var d=0;d<4;d++){
   var cells=[],ok=true;
   for(var k=0;k<4;k++){
    var nr=r+dirs[d][0]*k,nc=c+dirs[d][1]*k;
    if(nr<0||nr>=R||nc<0||nc>=C){ok=false;break;}
    cells.push(b[nr][nc]);}
   if(ok)s+=scoreWindow(cells,p);}}
 return s;}
function minimax(b,depth,alpha,beta,maxim){
 if(winCells(b,"Y"))return 100000+depth;
 if(winCells(b,"R"))return -100000-depth;
 if(full(b)||depth===0)return evaluate(b,"Y");
 var cols=[3,2,4,1,5,0,6].filter(function(c){return !b[0][c];});
 if(maxim){var v=-1e9;
  for(var i=0;i<cols.length;i++){var r=dropRow(b,cols[i]);b[r][cols[i]]="Y";
   v=Math.max(v,minimax(b,depth-1,alpha,beta,false));b[r][cols[i]]="";
   alpha=Math.max(alpha,v);if(alpha>=beta)break;}
  return v;}
 else{var v2=1e9;
  for(var j=0;j<cols.length;j++){var r2=dropRow(b,cols[j]);b[r2][cols[j]]="R";
   v2=Math.min(v2,minimax(b,depth-1,alpha,beta,true));b[r2][cols[j]]="";
   beta=Math.min(beta,v2);if(alpha>=beta)break;}
  return v2;}}
function aiPick(){
 var valid=[0,1,2,3,4,5,6].filter(function(c){return !board[0][c];});
 if(diff==="easy"){
  if(Math.random()<0.25){var w=findTactical("Y");if(w!==null)return w;}
  return valid[(Math.random()*valid.length)|0];}
 if(diff==="normal"){
  var w2=findTactical("Y");if(w2!==null)return w2;
  var b2=findTactical("R");if(b2!==null)return b2;
  if(!board[0][3]&&Math.random()<0.75)return 3;
  return valid[(Math.random()*valid.length)|0];}
 var depth=5,best=-1e9,picks=[];
 valid.forEach(function(c){var r=dropRow(board,c);board[r][c]="Y";
  var s=minimax(board,depth,-1e9,1e9,false);board[r][c]="";
  if(s>best){best=s;picks=[c];}else if(s===best)picks.push(c);});
 return picks[(Math.random()*picks.length)|0];}
function findTactical(p){
 for(var c=0;c<C;c++){
  if(board[0][c])continue;
  var r=dropRow(board,c);board[r][c]=p;
  var w=winCells(board,p);board[r][c]="";
  if(w)return c;}
 return null;}
function render(win){
 boardEl.innerHTML="";
 for(var r=0;r<R;r++)for(var c=0;c<C;c++){
  (function(r,c){
   var h=document.createElement("div");h.className="hole";
   var v=board[r][c];
   if(v){
    var d=document.createElement("div");
    var isWin=win&&win.some(function(cell){return cell[0]===r&&cell[1]===c;});
    d.className="disc "+v.toLowerCase()+(isWin?" win":"");
    h.appendChild(d);}
   h.addEventListener("click",function(){play(c);});
   boardEl.appendChild(h);})(r,c);}}
function play(c){
 if(over||board[0][c])return;
 if(mode==="ai"&&thinking)return;
 var p=mode==="2p"?nextPlayer():"R";
 doDrop(c,p);
 if(!over&&mode==="ai"){
  thinking=true;statusEl.textContent="Computer thinking...";
  setTimeout(function(){
   if(over){thinking=false;return;}
   doDrop(aiPick(),"Y");thinking=false;
   if(!over)statusEl.textContent="Your turn (Red)";},420);}}
var thinking=false;
var moveCount=0;
function nextPlayer(){return moveCount%2===0?"R":"Y";}
function doDrop(c,p){
 var r=dropRow(board,c);board[r][c]=p;moveCount++;
 GB.sfx.flip();
 var w=winCells(board,p);
 if(w){over=true;render(w);finish(p);return;}
 if(full(board)){over=true;render(null);
  statusEl.textContent="Draw!";statusEl.style.color="var(--warn)";GB.sfx.hit();
  if(mode==="ai"){streak=0;setChip("score",0);}
  return;}
 render(null);
 if(mode==="2p")statusEl.textContent=(moveCount%2===0?"Red":"Yellow")+"'s turn";}
function finish(p){
 if(p==="R"){statusEl.textContent=mode==="ai"?"You win!":"Red wins!";
  statusEl.style.color="var(--good)";
  if(mode==="ai"){streak++;GB.saveBest(SLUG,streak);setChip("score",streak);setChip("best",GB.best(SLUG));}
  GB.sfx.win();GB.buzz(40);}
 else{statusEl.textContent=mode==="ai"?"Computer wins":"Yellow wins!";
  statusEl.style.color="var(--bad)";GB.sfx.die();
  if(mode==="ai"){streak=0;setChip("score",0);}}}
function start(){board=emptyBoard();over=false;thinking=false;moveCount=0;
 statusEl.style.color="var(--text)";
 statusEl.textContent=mode==="ai"?"Your turn (Red)":"Red's turn";render(null);}
function seg(el,attr,fn){
 el.querySelectorAll("button").forEach(function(b){
  b.addEventListener("click",function(){
   el.querySelectorAll("button").forEach(function(x){x.classList.remove("on")});
   b.classList.add("on");GB.sfx.tap();fn(b.getAttribute(attr));start();});});}
seg(document.getElementById("modeSeg"),"data-m",function(m){mode=m;
 document.getElementById("diffSeg").style.display=m==="ai"?"flex":"none";
 streak=0;document.getElementById("score").textContent=0;});
seg(document.getElementById("diffSeg"),"data-d",function(d){diff=d;});
document.getElementById("restart").addEventListener("click",function(){GB.sfx.tap();start();});
GB.game.pausable=false;
start();
})();
