(function(){
"use strict";
var SLUG="lightsout",N=5;
GB.shell({title:"Lights Out",pausable:false,chips:[{id:"moves",label:"Moves"},{id:"best",label:"Best",value:GB.best(SLUG)||"-"}],
 rules:"<ul><li>Tapping a light flips it <b>and its 4 neighbors</b>.</li><li>Goal: turn every light <b>off</b>.</li><li>Every board can be solved - find the fewest moves. Your best (lowest) count is saved.</li></ul>"});
var grid,moves,done;
var boardEl=document.getElementById("board"),statusEl=document.getElementById("status");
function setChip(id,v){var e=document.getElementById(id);if(e)e.textContent=v;}
function flip(r,c){
 if(r<0||r>=N||c<0||c>=N)return;
 grid[r][c]=!grid[r][c];}
function press(r,c,silent){
 flip(r,c);flip(r-1,c);flip(r+1,c);flip(r,c-1);flip(r,c+1);
 if(!silent){moves++;setChip("moves",moves);}}
function start(){
 grid=[];for(var r=0;r<N;r++)grid.push(new Array(N).fill(false));
 moves=0;done=false;
 var taps=6+((Math.random()*5)|0);
 for(var k=0;k<taps;k++)press((Math.random()*N)|0,(Math.random()*N)|0,true);
 var anyOn=grid.some(function(row){return row.some(function(v){return v;});});
 if(!anyOn)press(2,2,true);
 setChip("moves",0);setChip("best",GB.best(SLUG)||"-");
 statusEl.textContent="Turn every light off. Tapping one flips its neighbors too.";
 render();}
function render(){
 boardEl.innerHTML="";
 grid.forEach(function(row,r){row.forEach(function(v,c){
  var d=document.createElement("div");
  d.className="cell"+(v?" on":"");
  d.addEventListener("click",function(){play(r,c);});
  boardEl.appendChild(d);});});}
function play(r,c){
 if(done)return;
 press(r,c);GB.sfx.flip();render();
 var anyOn=grid.some(function(row){return row.some(function(v){return v;});});
 if(!anyOn){
  done=true;
  var best=GB.best(SLUG);
  if(!best||moves<best){GB.store.set("best_"+SLUG,moves);setChip("best",moves);}
  GB.sfx.win();GB.buzz(40);
  GB.gameOver({title:"All Out!",won:true,
   sub:"Moves: <b>"+moves+"</b> &nbsp; Best: <b>"+GB.best(SLUG)+"</b>",
   again:"New Board",onAgain:start});}}
document.getElementById("restart").addEventListener("click",function(){GB.sfx.tap();start();});
GB.game.pausable=false;
start();
})();
