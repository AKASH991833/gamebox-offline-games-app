(function(){
"use strict";
var SLUG="simon";
GB.shell({title:"Beat Echo",pausable:false,chips:[{id:"score",label:"Round"},{id:"best",label:"Best",value:GB.best(SLUG)}],
 rules:"<ul><li>Watch the pads light up and <b>listen to their tones</b>.</li><li>Repeat the pattern in the same order.</li><li>Each round adds one more step. Every 5 rounds it plays faster.</li><li>One wrong pad ends the run - reach the highest round you can.</li></ul>"});
var TONES=[329.6,392,493.9,659.3];
var seq=[],pos=0,playing=false,accepting=false,timers=[];
var padsEl=document.getElementById("pads"),statusEl=document.getElementById("status");
var pads=[];
function setChip(id,v){var e=document.getElementById(id);if(e)e.textContent=v;}
for(var i=0;i<4;i++){(function(i){
 var p=document.createElement("button");p.className="pad p"+i;
 p.addEventListener("click",function(){tap(i);});
 padsEl.appendChild(p);pads.push(p);})(i);}
function later(fn,ms){timers.push(setTimeout(fn,ms));}
function clearTimers(){timers.forEach(clearTimeout);timers=[];}
function light(i,ms){
 pads[i].classList.add("lit");
 GB.tone(TONES[i],ms/1000+0.12,"sine",0.14);
 later(function(){pads[i].classList.remove("lit");},ms);}
function speed(){return Math.max(230,500-(Math.floor(seq.length/5))*55);}
function playSeq(){
 accepting=false;statusEl.textContent="Watch...";var t=speed();
 seq.forEach(function(v,k){
  later(function(){light(v,t*0.6);
   if(k===seq.length-1){accepting=true;statusEl.textContent="Your turn!";}},t*(k+1)+300);});}
function tap(i){
 if(!accepting)return;
 light(i,180);GB.buzz(10);
 if(i===seq[pos]){pos++;
  if(pos===seq.length){accepting=false;
   var r=seq.length;GB.saveBest(SLUG,r);
   setChip("score",r);setChip("best",GB.best(SLUG));
   statusEl.textContent="Good! Next round...";pos=0;
   later(next,750);}}
 else{accepting=false;playing=false;clearTimers();
  GB.saveBest(SLUG,seq.length-1);setChip("best",GB.best(SLUG));
  GB.buzz(100);
  var reached=seq.length-1;
  statusEl.textContent="Wrong pad!";
  GB.gameOver({title:"Wrong Pad!",
   sub:"You reached round <b>"+reached+"</b>. Best: <b>"+GB.best(SLUG)+"</b>",
   again:"Try Again",onAgain:begin});}}
function next(){seq.push((Math.random()*4)|0);setChip("score",seq.length);playSeq();}
function begin(){clearTimers();playing=true;seq=[];pos=0;next();}
document.getElementById("startBtn").addEventListener("click",function(){
 GB.sfx.tap();if(playing)return;begin();});
GB.game.pausable=false;
document.addEventListener("visibilitychange",function(){
 if(document.hidden&&playing){clearTimers();
  statusEl.textContent="Paused - tap Start to replay the round.";
  playing=false;}});
setChip("best",GB.best(SLUG));
})();
