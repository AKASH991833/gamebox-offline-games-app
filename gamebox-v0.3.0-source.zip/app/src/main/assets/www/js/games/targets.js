(function(){
"use strict";
var SLUG="targets";
var arena=document.getElementById("arena"),msg=document.getElementById("startMsg");
GB.shell({title:"Target Tap",chips:[{id:"score",label:"Score"},{id:"best",label:"Best",value:GB.best(SLUG)},{id:"time",label:"Time"}],
 rules:"<ul><li>You have <b>30 seconds</b>.</li><li>Tap each target before it shrinks away. Fast taps on big targets score <b>3</b>, medium <b>2</b>, tiny <b>1</b>.</li><li>Tapping empty space costs <b>1 point</b>.</li><li>Targets appear faster as the round goes on.</li></ul>"});
var playing=false,score,timeLeft,tgt,life,lifeMax,spawnWait,hits,taps;
function setChip(id,v){var e=document.getElementById(id);if(e)e.textContent=v;}
function start(){
 playing=true;score=0;timeLeft=30;tgt=null;life=0;lifeMax=1.15;spawnWait=0.4;hits=0;taps=0;
 arena.classList.remove("idle");msg.style.display="none";
 setChip("score",0);setChip("best",GB.best(SLUG));setChip("time",30);draw0();}
function draw0(){var old=arena.querySelector(".tgt");if(old)old.remove();tgt=null;}
function spawn(){
 var size=64;var pad=8;
 var w=arena.clientWidth,h=arena.clientHeight;
 var x=pad+Math.random()*(w-size-pad*2),y=pad+Math.random()*(h-size-pad*2);
 var d=document.createElement("div");d.className="tgt";
 d.style.left=x+"px";d.style.top=y+"px";d.style.width=size+"px";d.style.height=size+"px";
 arena.appendChild(d);
 tgt={el:d,x:x,y:y,size:size};life=lifeMax;}
function finish(){
 playing=false;draw0();arena.classList.add("idle");
 var acc=taps?Math.round(hits/taps*100):0;
 GB.saveBest(SLUG,score);setChip("best",GB.best(SLUG));
 GB.gameOver({title:"Time Up!",sub:"Score: <b>"+score+"</b> &nbsp; Accuracy: <b>"+acc+"%</b> &nbsp; Best: <b>"+GB.best(SLUG)+"</b>",onAgain:start});}
GB.loop(function(dt){
 if(!playing)return;
 timeLeft-=dt;
 setChip("time",Math.max(0,Math.ceil(timeLeft)));
 if(timeLeft<=0){finish();return;}
 if(tgt){
  life-=dt;
  var frac=Math.max(0,life/lifeMax);
  var s=Math.max(14,tgt.size*frac);
  tgt.el.style.width=s+"px";tgt.el.style.height=s+"px";
  tgt.el.style.left=(tgt.x+(tgt.size-s)/2)+"px";
  tgt.el.style.top=(tgt.y+(tgt.size-s)/2)+"px";
  if(life<=0){draw0();spawnWait=0.25;}}
 else{
  spawnWait-=dt;
  if(spawnWait<=0){spawn();lifeMax=Math.max(0.55,1.15-(30-timeLeft)*0.018);life=lifeMax;}}});
arena.addEventListener("pointerdown",function(e){
 if(!playing){start();return;}
 taps++;
 var r=arena.getBoundingClientRect(),x=e.clientX-r.left,y=e.clientY-r.top;
 if(tgt){
  var s=parseFloat(tgt.el.style.width),cx=parseFloat(tgt.el.style.left)+s/2,cy=parseFloat(tgt.el.style.top)+s/2;
  var d=Math.hypot(x-cx,y-cy);
  if(d<=s/2+6){
   hits++;
   var frac=life/lifeMax;
   var pts=frac>0.66?3:frac>0.33?2:1;
   score+=pts;setChip("score",score);GB.sfx.point();GB.buzz(10);
   draw0();spawnWait=0.3;return;}}
 score=Math.max(0,score-1);setChip("score",score);GB.sfx.hit();});
GB.game.pausable=true;
GB.onPauseChange(function(p){if(!p&&playing){}});
GB.game.restart=start;
})();
