(function(){
"use strict";
var SLUG="snake",N=17,W=408,CELL=W/N;
var cv=document.getElementById("cv"),ctx=GB.ctx(cv,W,W);
GB.shell({title:"Snake Rush",chips:[{id:"score",label:"Score"},{id:"best",label:"Best",value:GB.best(SLUG)}],
 rules:"<ul><li><b>Swipe</b> anywhere to turn the snake.</li><li>Each apple is <b>+10</b> points and makes you faster.</li><li>Hitting a wall or your own tail ends the run.</li><li>Use the pause button any time - the game also pauses itself if you leave the app.</li></ul>"});
var snake,prev,dir,nextDir,food,score,stepT,t,alive,acc;
function place(){var free=[];for(var y=0;y<N;y++)for(var x=0;x<N;x++)if(!snake.some(function(s){return s[0]===x&&s[1]===y}))free.push([x,y]);return free.length?free[(Math.random()*free.length)|0]:null;}
function start(){snake=[[8,8],[7,8],[6,8]];prev=snake.map(function(s){return s.slice();});
 dir=[1,0];nextDir=[1,0];food=place();score=0;stepT=0.16;t=0;alive=true;
 setChip("score",0);setChip("best",GB.best(SLUG));draw(0);}
function setChip(id,v){var e=document.getElementById(id);if(e)e.textContent=v;}
function advance(){prev=snake.map(function(s){return s.slice();});
 dir=nextDir;var h=[snake[0][0]+dir[0],snake[0][1]+dir[1]];
 if(h[0]<0||h[1]<0||h[0]>=N||h[1]>=N||snake.slice(0,(h[0]===food[0]&&h[1]===food[1])?snake.length:snake.length-1).some(function(s){return s[0]===h[0]&&s[1]===h[1]})){die();return;}
 snake.unshift(h);
 if(h[0]===food[0]&&h[1]===food[1]){score+=10;setChip("score",score);GB.saveBest(SLUG,score);setChip("best",GB.best(SLUG));
  food=place();if(!food){alive=false;GB.gameOver({title:"Board filled!",won:true,sub:"Score: "+score,onAgain:start});return;}stepT=Math.max(0.085,stepT-0.0035);GB.sfx.point();GB.buzz(15);}
 else snake.pop();}
function die(){alive=false;GB.saveBest(SLUG,score);GB.buzz(80);
 GB.gameOver({title:"Game Over",sub:"Score: <b>"+score+"</b> &nbsp; Best: <b>"+GB.best(SLUG)+"</b>",onAgain:start});}
function rr(x,y,w,h,r){ctx.beginPath();ctx.moveTo(x+r,y);ctx.arcTo(x+w,y,x+w,y+h,r);ctx.arcTo(x+w,y+h,x,y+h,r);ctx.arcTo(x,y+h,x,y,r);ctx.arcTo(x,y,x+w,y,r);ctx.closePath();ctx.fill();}
function draw(alpha){
 ctx.fillStyle=GB.isDark()?"#1E1338":"#EFE9FB";ctx.fillRect(0,0,W,W);
 ctx.strokeStyle=GB.isDark()?"rgba(255,255,255,.045)":"rgba(36,22,64,.05)";ctx.lineWidth=1;
 ctx.beginPath();for(var i=1;i<N;i++){ctx.moveTo(i*CELL,0);ctx.lineTo(i*CELL,W);ctx.moveTo(0,i*CELL);ctx.lineTo(W,i*CELL);}ctx.stroke();
 if(food){var pulse=1+Math.sin(performance.now()/220)*0.12,fr=CELL*0.34*pulse;
 ctx.fillStyle="#F43F5E";ctx.beginPath();ctx.arc(food[0]*CELL+CELL/2,food[1]*CELL+CELL/2,fr,0,7);ctx.fill();
 ctx.fillStyle="rgba(244,63,94,.3)";ctx.beginPath();ctx.arc(food[0]*CELL+CELL/2,food[1]*CELL+CELL/2,fr+4,0,7);ctx.fill();}
 for(var i=snake.length-1;i>=0;i--){
  var s=snake[i],p=prev[i]||s;
  var x=(p[0]+(s[0]-p[0])*alpha)*CELL,y=(p[1]+(s[1]-p[1])*alpha)*CELL;
  var shade=i===0?"#4ADE80":(i%2?"#22C55E":"#2ED573");
  ctx.fillStyle=shade;rr(x+2,y+2,CELL-4,CELL-4,i===0?8:6);}
 if(snake.length){var hd=snake[0],hp=prev[0]||hd;
  var hx=(hp[0]+(hd[0]-hp[0])*alpha)*CELL+CELL/2,hy=(hp[1]+(hd[1]-hp[1])*alpha)*CELL+CELL/2;
  ctx.fillStyle="#08331a";
  var ex=dir[0],ey=dir[1],px2=-ey,py2=ex;
  ctx.beginPath();ctx.arc(hx+ex*4+px2*5,hy+ey*4+py2*5,2.6,0,7);ctx.arc(hx+ex*4-px2*5,hy+ey*4-py2*5,2.6,0,7);ctx.fill();}}
GB.loop(function(dt){if(!alive)return;t+=dt;while(t>=stepT&&alive){t-=stepT;advance();}},
 function(){draw(alive?Math.min(1,t/stepT):1);});
function turn(nd){if(GB.paused||!alive)return;if(nd[0]===-dir[0]&&nd[1]===-dir[1])return;nextDir=nd;}
GB.swipe(document.querySelector(".stage"),function(d){
 turn(d==="left"?[-1,0]:d==="right"?[1,0]:d==="up"?[0,-1]:[0,1]);});
document.addEventListener("keydown",function(e){
 var m={ArrowLeft:[-1,0],ArrowRight:[1,0],ArrowUp:[0,-1],ArrowDown:[0,1]}[e.key];
 if(m){e.preventDefault();turn(m);}});
GB.game.restart=start;
start();
})();
