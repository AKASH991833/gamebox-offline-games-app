(function(){
"use strict";
var SLUG="fifteen";
GB.shell({title:"Slide 15",pausable:false,chips:[{id:"moves",label:"Moves"},{id:"best",label:"Best",value:GB.best(SLUG)||"-"}],
 rules:"<ul><li>Arrange the tiles in order <b>1 to 15</b>, empty space last.</li><li>Tap any tile next to the empty space to slide it.</li><li>Solve it in as few moves as possible - your best (lowest) move count is saved.</li></ul>"});
var tiles,gap,moves,solved;
var boardEl=document.getElementById("board"),statusEl=document.getElementById("status");
function setChip(id,v){var e=document.getElementById(id);if(e)e.textContent=v;}
function start(){
 tiles=[];for(var i=1;i<16;i++)tiles.push(i);tiles.push(0);
 gap=15;moves=0;solved=false;
 for(var k=0;k<220;k++){
  var opts=[];
  var r=(gap/4)|0,c=gap%4;
  if(r>0)opts.push(gap-4);if(r<3)opts.push(gap+4);
  if(c>0)opts.push(gap-1);if(c<3)opts.push(gap+1);
  var p=opts[(Math.random()*opts.length)|0];
  tiles[gap]=tiles[p];tiles[p]=0;gap=p;}
 setChip("moves",0);setChip("best",GB.best(SLUG)||"-");
 statusEl.textContent="Tap a tile next to the empty space to slide it.";
 render();}
function render(){
 boardEl.innerHTML="";
 tiles.forEach(function(v,i){
  var d=document.createElement("div");
  d.className="tile"+(v===0?" gap":"");
  d.textContent=v||"";
  d.addEventListener("click",function(){slide(i);});
  boardEl.appendChild(d);});}
function slide(i){
 if(solved)return;
 var r=(i/4)|0,c=i%4,gr=(gap/4)|0,gc=gap%4;
 if(Math.abs(r-gr)+Math.abs(c-gc)!==1)return;
 tiles[gap]=tiles[i];tiles[i]=0;gap=i;moves++;
 setChip("moves",moves);GB.sfx.flip();render();
 if(tiles.every(function(v,idx){return v===(idx+1)%16;})){
  solved=true;
  var best=GB.best(SLUG);
  if(!best||moves<best){GB.store.set("best_"+SLUG,moves);setChip("best",moves);}
  GB.sfx.win();GB.buzz(40);
  GB.gameOver({title:"Solved!",won:true,
   sub:"Moves: <b>"+moves+"</b> &nbsp; Best: <b>"+GB.best(SLUG)+"</b>",
   again:"Shuffle Again",onAgain:start});}}
document.getElementById("restart").addEventListener("click",function(){GB.sfx.tap();start();});
GB.game.pausable=false;
start();
})();
