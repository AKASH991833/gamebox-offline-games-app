(function(){
"use strict";
var SLUG="flappy",W=360,H=480;
var cv=document.getElementById("cv"),ctx=GB.ctx(cv,W,H);
GB.shell({title:"Flappy Dot",chips:[{id:"score",label:"Score"},{id:"best",label:"Best",value:GB.best(SLUG)}],
 rules:"<ul><li><b>Tap</b> to flap upward. Gravity does the rest.</li><li>Fly through the gaps between pipes - each one is <b>+1</b>.</li><li>Touching a pipe, the floor or the ceiling ends the run.</li><li>Score 10/20/30 for bronze, silver and gold medals.</li></ul>"});
var bird,pipes,clouds,score,playing,ready,dist;
function setChip(id,v){var e=document.getElementById(id);if(e)e.textContent=v;}
function start(){
 bird={x:82,y:H/2,vy:0,r:12,rot:0};pipes=[];score=0;playing=true;ready=true;dist=0;
 clouds=[];for(var i=0;i<4;i++)clouds.push({x:Math.random()*W,y:30+Math.random()*140,s:16+Math.random()*18});
 setChip("score",0);setChip("best",GB.best(SLUG));}
function flap(){
 if(!playing)return;
 if(ready)ready=false;
 bird.vy=-255;GB.sfx.flip();}
function die(){
 playing=false;GB.saveBest(SLUG,score);GB.buzz(90);
 var medal=score>=30?"Gold":score>=20?"Silver":score>=10?"Bronze":null;
 GB.gameOver({title:"Game Over",
  sub:"Score: <b>"+score+"</b> &nbsp; Best: <b>"+GB.best(SLUG)+"</b>"+(medal?"<br>Medal: <b>"+medal+"</b>":""),
  onAgain:start});}
function step(dt){
 clouds.forEach(function(c){c.x-=12*dt;if(c.x<-40){c.x=W+40;c.y=30+Math.random()*140;}});
 if(!playing||ready)return;
 dist+=dt;
 bird.vy+=900*dt;bird.y+=bird.vy*dt;
 bird.rot=Math.max(-0.45,Math.min(1.2,bird.vy/420));
 var speed=150+Math.min(90,score*2.2);
 var spacing=1.75;
 var last=pipes[pipes.length-1];
 if(!last||last.x<W-speed*spacing){
  var gap=135-Math.min(25,score);
  var top=55+Math.random()*(H-gap-165);
  pipes.push({x:W+10,top:top,gap:gap,passed:false});}
 pipes.forEach(function(p){p.x-=speed*dt;
  if(!p.passed&&p.x+60<bird.x){p.passed=true;score++;setChip("score",score);
   GB.saveBest(SLUG,score);setChip("best",GB.best(SLUG));GB.sfx.point();}});
 pipes=pipes.filter(function(p){return p.x>-70;});
 if(bird.y>H-bird.r-2||bird.y<bird.r)return die();
 for(var i=0;i<pipes.length;i++){var p=pipes[i];
  if(bird.x+bird.r>p.x&&bird.x-bird.r<p.x+60&&(bird.y-bird.r<p.top||bird.y+bird.r>p.top+p.gap))return die();}}
function rr(x,y,w,h,r){ctx.beginPath();ctx.moveTo(x+r,y);ctx.arcTo(x+w,y,x+w,y+h,r);ctx.arcTo(x+w,y+h,x,y+h,r);ctx.arcTo(x,y+h,x,y,r);ctx.arcTo(x,y,x+w,y,r);ctx.closePath();ctx.fill();}
function draw(){
 var dark=GB.isDark();
 var g=ctx.createLinearGradient(0,0,0,H);
 if(dark){g.addColorStop(0,"#241543");g.addColorStop(1,"#150C2B");}
 else{g.addColorStop(0,"#BFDBFE");g.addColorStop(1,"#F2EEFA");}
 ctx.fillStyle=g;ctx.fillRect(0,0,W,H);
 ctx.fillStyle=dark?"rgba(255,255,255,.08)":"rgba(255,255,255,.75)";
 clouds.forEach(function(c){ctx.beginPath();ctx.arc(c.x,c.y,c.s,0,7);ctx.arc(c.x+c.s*0.9,c.y+4,c.s*0.7,0,7);ctx.arc(c.x-c.s*0.9,c.y+5,c.s*0.65,0,7);ctx.fill();});
 pipes.forEach(function(p){
  var pg=ctx.createLinearGradient(p.x,0,p.x+60,0);
  pg.addColorStop(0,"#22C55E");pg.addColorStop(1,"#15803D");
  ctx.fillStyle=pg;rr(p.x,-4,60,p.top+4,8);rr(p.x,p.top+p.gap,60,H-p.top-p.gap+4,8);
  ctx.fillStyle="rgba(0,0,0,.18)";rr(p.x,p.top-8,60,8,4);rr(p.x,p.top+p.gap,60,8,4);});
 ctx.fillStyle=dark?"#2A1B47":"#E0D5F6";ctx.fillRect(0,H-8,W,8);
 ctx.save();ctx.translate(bird.x,bird.y);ctx.rotate(bird.rot);
 ctx.fillStyle="#FFD93D";ctx.beginPath();ctx.arc(0,0,bird.r,0,7);ctx.fill();
 ctx.fillStyle="#F59E0B";ctx.beginPath();ctx.moveTo(bird.r-2,0);ctx.lineTo(bird.r+7,-3);ctx.lineTo(bird.r+7,3);ctx.closePath();ctx.fill();
 ctx.fillStyle="#3b2f04";ctx.beginPath();ctx.arc(4,-3,2.6,0,7);ctx.fill();
 ctx.fillStyle="#FBBF24";ctx.beginPath();ctx.ellipse(-3,3,6,4,-0.4,0,7);ctx.fill();
 ctx.restore();
 if(ready&&playing){ctx.fillStyle=dark?"rgba(255,255,255,.6)":"rgba(36,22,64,.6)";
  ctx.font="700 16px sans-serif";ctx.textAlign="center";ctx.fillText("Tap to start",W/2,H/2-40);}}
GB.loop(step,draw);
cv.addEventListener("touchstart",function(e){e.preventDefault();flap();},{passive:false});
cv.addEventListener("mousedown",function(){flap();});
document.addEventListener("keydown",function(e){if(e.key===" "){e.preventDefault();flap();}});
GB.game.restart=start;
start();
})();
