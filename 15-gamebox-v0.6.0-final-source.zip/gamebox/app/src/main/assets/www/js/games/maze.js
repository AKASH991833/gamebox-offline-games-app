(function(){
"use strict";
var SLUG="maze",COLS=9,ROWS=12,CELL=33,W=COLS*CELL+2,H=ROWS*CELL+2;
var cv=document.getElementById("cv"),ctx=GB.ctx(cv,W,H);
GB.shell({title:"Maze Run",chips:[{id:"level",label:"Level"},{id:"best",label:"Best",value:GB.best(SLUG)},{id:"time",label:"Time"}],
 rules:"<ul><li><b>Swipe</b> (or arrow keys) to send the dot rolling in that direction.</li><li>Reach the <b>green exit</b> to clear the level.</li><li>Every level is a fresh maze. You have <b>60 seconds</b> per level; reach the exit before the timer runs out.</li><li>Score = levels cleared. Beat your best run!</li></ul>"});
var walls,px,py,dir,want,level,score,timeLeft,alive,exitC,exitR;
function setChip(id,v){var e=document.getElementById(id);if(e)e.textContent=v;}
function genMaze(cols,rows){
 var w=[];for(var r=0;r<rows;r++){w.push([]);for(var c=0;c<cols;c++)w[r].push({t:1,r:1,v:0});}
 var stack=[[0,0]];w[0][0].v=1;
 while(stack.length){
  var cur=stack[stack.length-1],cr=cur[0],cc=cur[1];
  var opts=[];
  if(cr>0&&!w[cr-1][cc].v)opts.push([cr-1,cc,"t"]);
  if(cr<rows-1&&!w[cr+1][cc].v)opts.push([cr+1,cc,"b"]);
  if(cc>0&&!w[cr][cc-1].v)opts.push([cr,cc-1,"l"]);
  if(cc<cols-1&&!w[cr][cc+1].v)opts.push([cr,cc+1,"r"]);
  if(!opts.length){stack.pop();continue;}
  var n=opts[(Math.random()*opts.length)|0];
  if(n[2]==="t")w[cr][cc].up=1,w[cr-1][cc].down=1,w[cr-1][cc].v=1;
  if(n[2]==="b")w[cr][cc].down=1,w[cr+1][cc].up=1,w[cr+1][cc].v=1;
  if(n[2]==="l")w[cr][cc].left=1,w[cr][cc-1].right=1,w[cr][cc-1].v=1;
  if(n[2]==="r")w[cr][cc].right=1,w[cr][cc+1].left=1,w[cr][cc+1].v=1;
  stack.push([n[0],n[1]]);}
 return w;}
function canMove(r,c,d){
 if(d==="up")return r>0&&walls[r][c].up;
 if(d==="down")return r<ROWS-1&&walls[r][c].down;
 if(d==="left")return c>0&&walls[r][c].left;
 if(d==="right")return c<COLS-1&&walls[r][c].right;
 return false;}
function startLevel(){
 walls=genMaze(COLS,ROWS);
 px=0;py=0;dir=null;want=null;timeLeft=60;dot={x:FX+CELL/2,y:FY+CELL/2};
 exitC=COLS-1;exitR=ROWS-1;
 setChip("level",level);setChip("best",GB.best(SLUG));setChip("time",60);draw();}
function start(){level=1;score=0;alive=true;startLevel();}
var FX=1,FY=1;
function cellCenter(c,r){return{x:FX+c*CELL+CELL/2,y:FY+r*CELL+CELL/2};}
var dot=null;
function step(dt){
 if(!alive)return;
 timeLeft-=dt;setChip("time",Math.max(0,Math.ceil(timeLeft)));
 if(timeLeft<=0){alive=false;GB.saveBest(SLUG,score);GB.sfx.die();
  GB.gameOver({title:"Time Up!",sub:"Levels cleared: <b>"+score+"</b> &nbsp; Best: <b>"+GB.best(SLUG)+"</b>",onAgain:start});return;}
 var remaining=6.5*dt*CELL;
 while(remaining>0){
  var current=cellCenter(px,py);if(want&&Math.hypot(dot.x-current.x,dot.y-current.y)<.0001&&canMove(py,px,want)){dir=want;want=null;}
  if(!dir){if(want&&canMove(py,px,want)){dir=want;want=null}else break;}
  if(!canMove(py,px,dir)){dir=null;break;}
  var nc=px+(dir==="right"?1:dir==="left"?-1:0),nr=py+(dir==="down"?1:dir==="up"?-1:0),target=cellCenter(nc,nr),distance=Math.hypot(target.x-dot.x,target.y-dot.y);
  if(remaining+1e-7<distance){dot.x+=(target.x-dot.x)/distance*remaining;dot.y+=(target.y-dot.y)/distance*remaining;break;}
  remaining-=distance;dot=target;px=nc;py=nr;
  if(px===exitC&&py===exitR){score++;GB.saveBest(SLUG,score);GB.sfx.win();GB.buzz(30);level++;GB.toast("Level "+level);startLevel();return;}
  if(want&&canMove(py,px,want)){dir=want;want=null;}else if(!canMove(py,px,dir))dir=null;
 }
}

function draw(){
 ctx.fillStyle=GB.isDark()?"#1E1338":"#EFE9FB";ctx.fillRect(0,0,W,H);
 var ec=cellCenter(exitC,exitR);
 var pulse=1+Math.sin(performance.now()/300)*0.15;
 ctx.fillStyle="#4ADE80";ctx.beginPath();ctx.arc(ec.x,ec.y,CELL*0.34*pulse,0,7);ctx.fill();
 ctx.strokeStyle=GB.isDark()?"#8B5CF6":"#6C4DF6";ctx.lineWidth=3;ctx.lineCap="round";
 ctx.beginPath();
 for(var r=0;r<ROWS;r++)for(var c=0;c<COLS;c++){
  var x=FX+c*CELL,y=FY+r*CELL;
  if(!walls[r][c].up&&r===0){ctx.moveTo(x,y);ctx.lineTo(x+CELL,y);}
  if(!walls[r][c].left&&c===0){ctx.moveTo(x,y);ctx.lineTo(x,y+CELL);}
  if(r<ROWS-1&&!walls[r][c].down){ctx.moveTo(x,y+CELL);ctx.lineTo(x+CELL,y+CELL);}
  if(c<COLS-1&&!walls[r][c].right){ctx.moveTo(x+CELL,y);ctx.lineTo(x+CELL,y+CELL);}
  if(r===ROWS-1){ctx.moveTo(x,y+CELL);ctx.lineTo(x+CELL,y+CELL);}
  if(c===COLS-1){ctx.moveTo(x+CELL,y);ctx.lineTo(x+CELL,y+CELL);}}
 ctx.stroke();
 var d=dot||cellCenter(px,py);
 ctx.fillStyle="#FACC15";ctx.beginPath();ctx.arc(d.x,d.y,CELL*0.3,0,7);ctx.fill();
 ctx.fillStyle="rgba(0,0,0,.25)";ctx.beginPath();ctx.arc(d.x+3,d.y-2,2.4,0,7);ctx.fill();}
GB.loop(step,draw);
function steer(d){if(GB.paused||!alive)return;want=d;GB.sfx.flip();}
GB.swipe(document.querySelector(".stage"),steer,16);
document.addEventListener("keydown",function(e){
 var m={ArrowLeft:"left",ArrowRight:"right",ArrowUp:"up",ArrowDown:"down"}[e.key];
 if(m){e.preventDefault();steer(m);}});
GB.game.restart=start;
start();
})();
