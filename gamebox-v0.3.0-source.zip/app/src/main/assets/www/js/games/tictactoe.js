(function(){
"use strict";
var SLUG="tictactoe";
GB.shell({title:"Tic Tac Toe",pausable:false,chips:[{id:"score",label:"Streak"},{id:"best",label:"Best",value:GB.best(SLUG)}],
 rules:"<ul><li>Get <b>3 in a row</b> - horizontal, vertical or diagonal.</li><li><b>Vs Computer</b>: you are X. Easy makes mistakes, Hard never loses.</li><li><b>2 Players</b>: pass the phone, X and O alternate.</li><li>Your streak counts consecutive wins against the computer.</li></ul>"});
var board,over=false,mode="ai",diff="normal",streak=0,xw=0,ow=0,dr=0;
var boardEl=document.getElementById("board"),statusEl=document.getElementById("status");
var L=[[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
function winner(b){for(var i=0;i<L.length;i++){var a=L[i];
 if(b[a[0]]&&b[a[0]]===b[a[1]]&&b[a[1]]===b[a[2]])return{w:b[a[0]],line:a};}
 if(b.every(function(v){return v}))return{w:"draw"};return null;}
function minimax(b,isMax,depth){
 var r=winner(b);
 if(r){if(r.w==="O")return 10-depth;if(r.w==="X")return depth-10;return 0;}
 var best=isMax?-99:99;
 for(var i=0;i<9;i++){if(b[i])continue;
  b[i]=isMax?"O":"X";var s=minimax(b,!isMax,depth+1);b[i]="";
  best=isMax?Math.max(best,s):Math.min(best,s);}
 return best;}
function aiPick(){
 var empty=board.map(function(v,i){return v?null:i}).filter(function(v){return v!==null});
 if(diff==="easy"){
  if(Math.random()<0.3){var b=blockOrWin("X");if(b!==null)return b;}
  return empty[(Math.random()*empty.length)|0];}
 if(diff==="normal"){
  var w=blockOrWin("O");if(w!==null)return w;
  var b2=blockOrWin("X");if(b2!==null)return b2;
  if(!board[4]&&Math.random()<0.7)return 4;
  var cs=[0,2,6,8].filter(function(k){return !board[k]});
  if(cs.length&&Math.random()<0.7)return cs[(Math.random()*cs.length)|0];
  return empty[(Math.random()*empty.length)|0];}
 var best=-99,pick=empty[0];
 empty.forEach(function(i){board[i]="O";var s=minimax(board,false,0);board[i]="";
  if(s>best){best=s;pick=i;}});
 return pick;}
function blockOrWin(mark){
 for(var j=0;j<L.length;j++){var a=L[j],vals=a.map(function(k){return board[k]});
  if(vals.filter(function(v){return v===mark}).length===2&&vals.indexOf("")>=0)return a[vals.indexOf("")];}
 return null;}
function render(){
 boardEl.innerHTML="";
 board.forEach(function(v,i){var c=document.createElement("button");
  c.className="cell"+(v?" "+v.toLowerCase():"");c.textContent=v||"";
  c.addEventListener("click",function(){play(i);});boardEl.appendChild(c);});
 document.getElementById("xw").textContent=xw;document.getElementById("ow").textContent=ow;document.getElementById("dr").textContent=dr;}
function strike(line){
 var rect=boardEl.getBoundingClientRect(),g=rect.width/3;
 function cen(i){return{x:(i%3)*g+g/2,y:((i/3)|0)*g+g/2};}
 var a=cen(line[0]),b=cen(line[2]);
 var len=Math.hypot(b.x-a.x,b.y-a.y),ang=Math.atan2(b.y-a.y,b.x-a.x)*180/Math.PI;
 var s=document.createElement("div");s.className="strike";
 s.style.left=a.x+"px";s.style.top=(a.y-3)+"px";s.style.setProperty("--w",len+"px");
 s.style.width=len+"px";s.style.transform="rotate("+ang+"deg)";
 boardEl.appendChild(s);}
function play(i){
 if(over||board[i])return;
 var mark=mode==="2p"?(board.filter(function(v){return v;}).length%2===0?"X":"O"):"X";
 board[i]=mark;GB.sfx.flip();render();
 var r=winner(board);if(r)return finish(r);
 if(mode==="ai"){statusEl.textContent="Computer thinking...";setTimeout(function(){
  if(over)return;board[aiPick()]="O";GB.sfx.flip();render();
  var r2=winner(board);if(r2)finish(r2);else statusEl.textContent="Your turn (X)";},380);}
 else statusEl.textContent=(mark==="X"?"O":"X")+"'s turn";}
function finish(r){
 over=true;
 if(r.w==="draw"){dr++;statusEl.textContent="Draw!";statusEl.style.color="var(--warn)";GB.sfx.hit();if(mode==="ai")streak=0;}
 else{strike(r.line);
  if(r.w==="X"){xw++;statusEl.textContent=mode==="ai"?"You win!":"X wins!";statusEl.style.color="var(--good)";
   if(mode==="ai"){streak++;GB.saveBest(SLUG,streak);GB.sfx.win();GB.buzz(40);}}
  else{ow++;statusEl.textContent=mode==="ai"?"Computer wins":"O wins!";statusEl.style.color="var(--bad)";
   if(mode==="ai"){streak=0;GB.sfx.die();}}}
 if(mode==="ai"){document.getElementById("score").textContent=streak;document.getElementById("best").textContent=GB.best(SLUG);}
 render();}
function start(){board=Array(9).fill("");over=false;
 statusEl.style.color="var(--text)";
 statusEl.textContent=mode==="ai"?"Your turn (X)":"X's turn";render();}
function seg(el,attr,fn){
 el.querySelectorAll("button").forEach(function(b){
  b.addEventListener("click",function(){
   el.querySelectorAll("button").forEach(function(x){x.classList.remove("on")});
   b.classList.add("on");GB.sfx.tap();fn(b.getAttribute(attr));start();});});}
seg(document.getElementById("modeSeg"),"data-m",function(m){mode=m;
 document.getElementById("diffSeg").style.display=m==="ai"?"flex":"none";
 streak=0;document.getElementById("score").textContent=0;});
seg(document.getElementById("diffSeg"),"data-d",function(d){diff=d;});
document.getElementById("restart").addEventListener("click",function(){GB.sfx.tap();start();});
GB.game.pausable=false;
start();
})();
