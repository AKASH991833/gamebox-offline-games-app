(function(){
"use strict";
var SLUG="2048",N=4;
GB.shell({title:"2048",pausable:false,chips:[{id:"score",label:"Score"},{id:"best",label:"Best",value:GB.best(SLUG)}],
 rules:"<ul><li><b>Swipe</b> to slide every tile in that direction.</li><li>Two equal tiles merge into their sum and add to your score.</li><li>Reach <b>2048</b> to win - you can keep playing after that.</li><li>Stuck with no moves left ends the game. <b>Undo</b> takes back your last move.</li></ul>"});
var board=document.getElementById("board");
var tiles=[],nextId=1,score=0,won=false,gameOver=false,lock=false,snap=null;
var PAD=0,STEP=0,TS=0;
function metrics(){var w=board.clientWidth;PAD=w*0.03;STEP=(w-2*PAD)/N;TS=STEP*0.9;}
function setChip(id,v){var e=document.getElementById(id);if(e)e.textContent=v;}
function bg(){board.innerHTML="";metrics();
 for(var r=0;r<N;r++)for(var c=0;c<N;c++){var d=document.createElement("div");d.className="cellbg";
  d.style.width=d.style.height=TS+"px";d.style.left=(PAD+c*STEP+(STEP-TS)/2)+"px";d.style.top=(PAD+r*STEP+(STEP-TS)/2)+"px";board.appendChild(d);}}
function place(el,t){var x=PAD+t.c*STEP+(STEP-TS)/2,y=PAD+t.r*STEP+(STEP-TS)/2;
 var tf="translate("+x+"px,"+y+"px)";el.style.setProperty("--tf",tf);el.style.transform=tf;
 el.style.width=el.style.height=TS+"px";el.style.fontSize=(t.val<100?TS*0.42:t.val<1000?TS*0.34:TS*0.27)+"px";}
function render(){metrics();
 var seen={};
 tiles.forEach(function(t){
  if(!t.el){t.el=document.createElement("div");t.el.className="tile new";t.el.setAttribute("data-v",t.val<=2048?t.val:2048);if(t.val>2048)t.el.classList.add("big");t.el.textContent=t.val;board.appendChild(t.el);place(t.el,t);}
  else{place(t.el,t);t.el.setAttribute("data-v",t.val<=2048?t.val:2048);if(t.val>2048)t.el.classList.add("big");t.el.textContent=t.val;}
  seen[t.id]=true;});
 tiles.forEach(function(t){t.el.setAttribute("data-id",t.id);});
 Array.prototype.slice.call(board.querySelectorAll(".tile")).forEach(function(el){
  if(!seen[+el.getAttribute("data-id")])el.remove();});
 setChip("score",score);setChip("best",GB.best(SLUG));}
function spawn(){var free=[];for(var r=0;r<N;r++)for(var c=0;c<N;c++)
 if(!tiles.some(function(t){return t.r===r&&t.c===c}))free.push([r,c]);
 if(!free.length)return;var p=free[(Math.random()*free.length)|0];
 tiles.push({id:nextId++,r:p[0],c:p[1],val:Math.random()<0.9?2:4,el:null});}
function snapshot(){snap={score:score,tiles:tiles.map(function(t){return{id:t.id,r:t.r,c:t.c,val:t.val};})};}
function restore(){if(!snap)return;score=snap.score;
 tiles.forEach(function(t){if(t.el)t.el.remove();});
 tiles=snap.tiles.map(function(t){return{id:t.id,r:t.r,c:t.c,val:t.val,el:null};});
 nextId=tiles.reduce(function(m,t){return Math.max(m,t.id);},0)+1;
 snap=null;gameOver=false;render();}
function at(r,c){for(var i=0;i<tiles.length;i++)if(tiles[i].r===r&&tiles[i].c===c)return tiles[i];return null;}
function move(dir){
 if(lock||gameOver)return;
 snapshot();
 var moved=false,mergedIds={};
 function line(coords){
  var ts=coords.map(function(p){return at(p[0],p[1]);}).filter(function(t){return t;});
  var write=0;
  for(var i=0;i<ts.length;i++){
   var t=ts[i],target=coords[write];
   if(i+1<ts.length&&ts[i+1].val===t.val&&!mergedIds[t.id]&&!mergedIds[ts[i+1].id]){
    var other=ts[i+1];
    t.r=target[0];t.c=target[1];other.r=target[0];other.c=target[1];
    t.val*=2;t.merged=true;mergedIds[t.id]=true;
    other.dead=true;score+=t.val;GB.sfx.point();
    if(t.val===2048&&!won){won=true;setTimeout(showWin,220);}
    moved=true;i++;}
   else{t.r=target[0];t.c=target[1];}
   write++;}
 }
 var r,c;
 if(dir==="left")for(r=0;r<N;r++)line([[r,0],[r,1],[r,2],[r,3]]);
 if(dir==="right")for(r=0;r<N;r++)line([[r,3],[r,2],[r,1],[r,0]]);
 if(dir==="up")for(c=0;c<N;c++)line([[0,c],[1,c],[2,c],[3,c]]);
 if(dir==="down")for(c=0;c<N;c++)line([[3,c],[2,c],[1,c],[0,c]]);
 // movement detection: compare against snapshot
 var before=snap.tiles;moved=false;
 for(var i=0;i<tiles.length;i++){var t=tiles[i];var b=before.filter(function(x){return x.id===t.id;})[0];
  if(!b||b.r!==t.r||b.c!==t.c||b.val!==t.val){moved=true;break;}}
 if(!moved){snap=null;return;}
 GB.sfx.tap();lock=true;
 render();
 setTimeout(function(){
  tiles=tiles.filter(function(t){return !t.dead;});
  tiles.forEach(function(t){if(t.merged){t.merged=false;
   if(t.el){t.el.classList.remove("merged");void t.el.offsetWidth;t.el.classList.add("merged");}}});
  spawn();render();lock=false;
  GB.saveBest(SLUG,score);setChip("best",GB.best(SLUG));
  if(!canMove()){gameOver=true;GB.saveBest(SLUG,score);GB.buzz(80);
   GB.gameOver({title:"Game Over",sub:"Score: <b>"+score+"</b> &nbsp; Best: <b>"+GB.best(SLUG)+"</b>",again:"New Game",onAgain:start});}
 },130);}
function canMove(){
 for(var r=0;r<N;r++)for(var c=0;c<N;c++){
  if(!at(r,c))return true;
  var v=at(r,c).val;
  if(c<N-1&&at(r,c+1)&&at(r,c+1).val===v)return true;
  if(r<N-1&&at(r+1,c)&&at(r+1,c).val===v)return true;}
 return false;}
function showWin(){GB.sfx.win();
 GB.gameOver({title:"You made 2048!",sub:"Score: <b>"+score+"</b>. Keep going for a higher score.",again:"Keep Playing",won:true,onAgain:function(){}});}
function start(){tiles.forEach(function(t){if(t.el)t.el.remove();});
 tiles=[];nextId=1;score=0;won=false;gameOver=false;snap=null;lock=false;
 spawn();spawn();render();}
GB.swipe(board,function(d){move(d);});
document.addEventListener("keydown",function(e){
 var m={ArrowLeft:"left",ArrowRight:"right",ArrowUp:"up",ArrowDown:"down"}[e.key];
 if(m){e.preventDefault();move(m);}});
document.getElementById("restart").addEventListener("click",function(){GB.sfx.tap();start();});
document.getElementById("undo").addEventListener("click",function(){GB.sfx.tap();restore();});
window.addEventListener("resize",function(){render();});
GB.game.pausable=false;
bg();start();
})();
