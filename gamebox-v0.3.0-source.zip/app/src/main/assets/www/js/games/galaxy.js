(function(){
"use strict";
var SLUG="galaxy",W=360,H=560;
var cv=document.getElementById("cv"),ctx=GB.ctx(cv,W,H);
GB.shell({title:"Galaxy Guard",chips:[{id:"score",label:"Score"},{id:"best",label:"Best",value:GB.best(SLUG)},{id:"lives",label:"Lives"}],
 rules:"<ul><li><b>Drag</b> anywhere to slide your ship. It fires automatically.</li><li>Aliens drift down and shoot back. Each kill is <b>10-50</b> points by row.</li><li>You have <b>3 lives</b>. A shielded bottom edge is not part of the deal - dodge!</li><li>Clear a wave for a faster next wave. The run ends when lives run out or aliens land.</li></ul>"});
var shipX,bullets,enemyBullets,aliens,dirX,alienSpeed,fireT,score,lives,wave,alive,invuln,stars;
function setChip(id,v){var e=document.getElementById(id);if(e)e.textContent=v;}
function makeStars(){stars=[];for(var i=0;i<40;i++)stars.push({x:Math.random()*W,y:Math.random()*H,s:Math.random()*1.6+0.4,v:Math.random()*14+6});}
function makeWave(){
 aliens=[];var cols=8,rows=4+Math.min(1,wave-1);
 for(var r=0;r<rows;r++)for(var c=0;c<cols;c++)
  aliens.push({x:36+c*38,y:54+r*34,row:r,alive:true,wob:Math.random()*6});
 dirX=1;alienSpeed=22+wave*7;}
function start(){
 shipX=W/2;bullets=[];enemyBullets=[];score=0;lives=3;wave=1;fireT=0;alive=true;invuln=1.2;
 setChip("score",0);setChip("best",GB.best(SLUG));setChip("lives",lives);
 makeStars();makeWave();draw();}
function addScore(p){score+=p;setChip("score",score);GB.saveBest(SLUG,score);setChip("best",GB.best(SLUG));}
function boom(){lives--;setChip("lives",lives);GB.sfx.die();GB.buzz(70);invuln=1.6;
 if(lives<=0){alive=false;GB.saveBest(SLUG,score);
  GB.gameOver({title:"Game Over",sub:"Score: <b>"+score+"</b> &nbsp; Best: <b>"+GB.best(SLUG)+"</b>",onAgain:start});}}
function step(dt){
 stars.forEach(function(s){s.y+=s.v*dt;if(s.y>H){s.y=-4;s.x=Math.random()*W;}});
 if(!alive)return;
 if(invuln>0)invuln-=dt;
 fireT-=dt;
 if(fireT<=0){bullets.push({x:shipX,y:H-64});fireT=0.34;GB.sfx.flip();}
 bullets.forEach(function(b){b.y-=420*dt;});
 bullets=bullets.filter(function(b){return b.y>-10;});
 enemyBullets.forEach(function(b){b.y+=(150+wave*18)*dt;});
 enemyBullets=enemyBullets.filter(function(b){return b.y<H+10;});
 var minX=999,maxX=-999,any=false;
 aliens.forEach(function(a){if(a.alive){any=true;a.wob+=dt;
  if(a.x<minX)minX=a.x;if(a.x>maxX)maxX=a.x;}});
 if(any){
  var edge=false;
  if((dirX>0&&maxX>W-26)||(dirX<0&&minX<26))edge=true;
  aliens.forEach(function(a){if(!a.alive)return;
   if(edge){a.y+=18;}else{a.x+=dirX*alienSpeed*dt;}});
  if(edge)dirX*=-1;
  aliens.forEach(function(a){
   if(a.alive&&a.y>H-90){alive=false;GB.saveBest(SLUG,score);GB.sfx.die();
    GB.gameOver({title:"They Landed!",sub:"Score: <b>"+score+"</b> &nbsp; Best: <b>"+GB.best(SLUG)+"</b>",onAgain:start});}});
  if(Math.random()<dt*(0.5+wave*0.14)){
   var shooters=aliens.filter(function(a){return a.alive;});
   if(shooters.length){var s=shooters[(Math.random()*shooters.length)|0];
    enemyBullets.push({x:s.x,y:s.y+14});}}}
 bullets.forEach(function(b){
  aliens.forEach(function(a){
   if(a.alive&&Math.abs(b.x-a.x)<15&&Math.abs(b.y-a.y)<13){
    a.alive=false;b.y=-99;addScore((4-a.row+1)*10+ (a.row===0?10:0));
    GB.sfx.hit();GB.buzz(12);}});});
 enemyBullets.forEach(function(b){
  if(invuln<=0&&Math.abs(b.x-shipX)<15&&Math.abs(b.y-(H-44))<14){b.y=H+99;boom();}});
 if(aliens.every(function(a){return !a.alive;})){
  wave++;makeWave();addScore(100);GB.sfx.win();GB.toast("Wave "+wave);}}
function drawShip(){
 var y=H-44;
 if(invuln>0&&((invuln*8)|0)%2===0)ctx.globalAlpha=0.35;
 ctx.fillStyle="#8B5CF6";
 ctx.beginPath();ctx.moveTo(shipX,y-14);ctx.lineTo(shipX-14,y+12);ctx.lineTo(shipX,y+6);ctx.lineTo(shipX+14,y+12);ctx.closePath();ctx.fill();
 ctx.fillStyle="#22D3EE";ctx.beginPath();ctx.arc(shipX,y-2,4.5,0,7);ctx.fill();
 ctx.fillStyle="#FB923C";
 ctx.beginPath();ctx.moveTo(shipX-5,y+12);ctx.lineTo(shipX,y+20+Math.random()*6);ctx.lineTo(shipX+5,y+12);ctx.closePath();ctx.fill();
 ctx.globalAlpha=1;}
function draw(){
 ctx.fillStyle=GB.isDark()?"#150B2E":"#EFE9FB";ctx.fillRect(0,0,W,H);
 ctx.fillStyle=GB.isDark()?"rgba(255,255,255,.5)":"rgba(36,22,64,.3)";
 stars.forEach(function(s){ctx.fillRect(s.x,s.y,s.s,s.s);});
 var cols=["#F43F5E","#FB923C","#FACC15","#4ADE80","#22D3EE"];
 aliens.forEach(function(a){if(!a.alive)return;
  var wob=Math.sin(a.wob*4)*3;
  ctx.fillStyle=cols[a.row%cols.length];
  ctx.beginPath();ctx.arc(a.x,a.y+wob,11,0,7);ctx.fill();
  ctx.fillStyle="rgba(0,0,0,.28)";
  ctx.beginPath();ctx.arc(a.x-4,a.y-2+wob,2.6,0,7);ctx.arc(a.x+4,a.y-2+wob,2.6,0,7);ctx.fill();
  ctx.strokeStyle=cols[a.row%cols.length];ctx.lineWidth=2;
  ctx.beginPath();ctx.moveTo(a.x-8,a.y+8+wob);ctx.lineTo(a.x-12,a.y+14+wob);
  ctx.moveTo(a.x+8,a.y+8+wob);ctx.lineTo(a.x+12,a.y+14+wob);ctx.stroke();});
 ctx.fillStyle="#A5F3FC";
 bullets.forEach(function(b){ctx.fillRect(b.x-1.6,b.y-8,3.2,10);});
 ctx.fillStyle="#FDA4AF";
 enemyBullets.forEach(function(b){ctx.beginPath();ctx.arc(b.x,b.y,3.4,0,7);ctx.fill();});
 if(alive)drawShip();
 ctx.fillStyle=GB.isDark()?"rgba(255,255,255,.6)":"rgba(36,22,64,.6)";
 ctx.font="bold 13px sans-serif";ctx.fillText("Wave "+wave,10,H-14);}
GB.loop(step,draw);
GB.dragX(document.querySelector(".gm-wrap"),W,function(x){shipX=Math.max(16,Math.min(W-16,x));});
document.addEventListener("keydown",function(e){
 if(e.key==="ArrowLeft"){e.preventDefault();shipX=Math.max(16,shipX-16);}
 else if(e.key==="ArrowRight"){e.preventDefault();shipX=Math.min(W-16,shipX+16);}});
GB.game.restart=start;
start();
})();
