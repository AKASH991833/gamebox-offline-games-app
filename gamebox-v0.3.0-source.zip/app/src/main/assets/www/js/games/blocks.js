(function(){
"use strict";
var SLUG="blocks",COLS=10,ROWS=20,CELL=30,W=COLS*CELL,H=ROWS*CELL;
var cv=document.getElementById("cv"),ctx=GB.ctx(cv,W,H);
GB.shell({title:"Block Drop",chips:[{id:"score",label:"Score"},{id:"best",label:"Best",value:GB.best(SLUG)}],
 rules:"<ul><li>Move pieces with <b>swipe</b> or the buttons. Tap the board to <b>rotate</b>.</li><li>Complete a full row to clear it: 1 row 100, 2 rows 300, 3 rows 500, 4 rows 800 points, times your level.</li><li>Every 10 cleared rows the speed and level go up.</li><li>The run ends when blocks reach the top.</li></ul>"});
var SHAPES={I:[[1,1,1,1]],J:[[1,0,0],[1,1,1]],L:[[0,0,1],[1,1,1]],O:[[1,1],[1,1]],S:[[0,1,1],[1,1,0]],T:[[0,1,0],[1,1,1]],Z:[[1,1,0],[0,1,1]]};
var COLORS={I:"#22D3EE",J:"#60A5FA",L:"#FB923C",O:"#FACC15",S:"#4ADE80",T:"#C084FC",Z:"#F43F5E"};
var KEYS=Object.keys(SHAPES);
var grid,piece,px,py,ptype,nextType,score,lines,level,fallT,acc,alive;
function setChip(id,v){var e=document.getElementById(id);if(e)e.textContent=v;}
function rotate(m){var r=m[0].map(function(_,i){return m.map(function(row){return row[i];}).reverse();});return r;}
function collides(m,ox,oy){
 for(var y=0;y<m.length;y++)for(var x=0;x<m[y].length;x++){
  if(!m[y][x])continue;var gx=ox+x,gy=oy+y;
  if(gx<0||gx>=COLS||gy>=ROWS)return true;
  if(gy>=0&&grid[gy][gx])return true;}
 return false;}
function spawn(){
 ptype=nextType;nextType=KEYS[(Math.random()*KEYS.length)|0];
 piece=SHAPES[ptype];px=((COLS-piece[0].length)/2)|0;py=0;
 if(collides(piece,px,py)){alive=false;GB.saveBest(SLUG,score);GB.buzz(80);
  GB.gameOver({title:"Game Over",sub:"Score: <b>"+score+"</b> &nbsp; Best: <b>"+GB.best(SLUG)+"</b>",onAgain:start});}}
function merge(){
 piece.forEach(function(row,y){row.forEach(function(v,x){
  if(v&&py+y>=0)grid[py+y][px+x]=ptype;});});
 var cleared=0;
 for(var y=ROWS-1;y>=0;y--){
  if(grid[y].every(function(c){return c;})){grid.splice(y,1);grid.unshift(new Array(COLS).fill(null));cleared++;y++;}}
 if(cleared){var pts=[0,100,300,500,800][cleared]*level;score+=pts;lines+=cleared;
  level=((lines/10)|0)+1;fallT=Math.max(0.08,0.7-(level-1)*0.06);
  setChip("score",score);GB.saveBest(SLUG,score);setChip("best",GB.best(SLUG));
  GB.sfx.point();GB.buzz(20);}
 spawn();}
function move(dx){if(!alive)return;if(!collides(piece,px+dx,py)){px+=dx;GB.sfx.flip();}}
function rot(){if(!alive)return;var r=rotate(piece);
 var kick=[0,-1,1,-2,2];
 for(var i=0;i<kick.length;i++){if(!collides(r,px+kick[i],py)){piece=r;px+=kick[i];GB.sfx.flip();return;}}}
function step(){if(!collides(piece,px,py+1)){py++;}
 else{merge();}}
function hardDrop(){if(!alive)return;var d=0;while(!collides(piece,px,py+1)){py++;d++;}
 score+=d;setChip("score",score);GB.sfx.hit();merge();}
function start(){grid=[];for(var y=0;y<ROWS;y++)grid.push(new Array(COLS).fill(null));
 score=0;lines=0;level=1;fallT=0.7;acc=0;alive=true;
 nextType=KEYS[(Math.random()*KEYS.length)|0];
 setChip("score",0);setChip("best",GB.best(SLUG));spawn();draw();}
function rr(x,y,w,h,r){ctx.beginPath();ctx.moveTo(x+r,y);ctx.arcTo(x+w,y,x+w,y+h,r);ctx.arcTo(x+w,y+h,x,y+h,r);ctx.arcTo(x,y+h,x,y,r);ctx.arcTo(x,y,x+w,y,r);ctx.closePath();ctx.fill();}
function cell(gx,gy,type){
 ctx.fillStyle=COLORS[type];rr(gx*CELL+1.5,gy*CELL+1.5,CELL-3,CELL-3,6);
 ctx.fillStyle="rgba(255,255,255,.22)";rr(gx*CELL+4,gy*CELL+4,CELL-8,7,3);}
function draw(){
 ctx.fillStyle=GB.isDark()?"#1E1338":"#EFE9FB";ctx.fillRect(0,0,W,H);
 ctx.strokeStyle=GB.isDark()?"rgba(255,255,255,.045)":"rgba(36,22,64,.05)";ctx.lineWidth=1;
 ctx.beginPath();for(var i=1;i<COLS;i++){ctx.moveTo(i*CELL,0);ctx.lineTo(i*CELL,H);}
 for(var j=1;j<ROWS;j++){ctx.moveTo(0,j*CELL);ctx.lineTo(W,j*CELL);}ctx.stroke();
 for(var y=0;y<ROWS;y++)for(var x=0;x<COLS;x++)if(grid[y][x])cell(x,y,grid[y][x]);
 if(alive){
  var gy=py;while(!collides(piece,px,gy+1))gy++;
  ctx.globalAlpha=0.22;
  piece.forEach(function(row,yy){row.forEach(function(v,xx){if(v)cell(px+xx,gy+yy,ptype);});});
  ctx.globalAlpha=1;
  piece.forEach(function(row,yy){row.forEach(function(v,xx){if(v)cell(px+xx,py+yy,ptype);});});}
 ctx.fillStyle=GB.isDark()?"rgba(255,255,255,.75)":"rgba(36,22,64,.75)";
 ctx.font="bold 15px sans-serif";ctx.fillText("Next:",8,20);
 SHAPES[nextType].forEach(function(row,yy){row.forEach(function(v,xx){
  if(v){ctx.fillStyle=COLORS[nextType];rr(64+xx*13,8+yy*13,11,11,3);}});});
 ctx.fillText("Lv "+level,W-52,20);}
GB.loop(function(dt){if(!alive)return;acc+=dt;while(acc>=fallT&&alive){acc-=fallT;step();}},draw);
GB.swipe(document.querySelector(".stage"),function(d){
 if(d==="left")move(-1);else if(d==="right")move(1);else if(d==="down"){step();acc=0;}});
cv.addEventListener("click",rot);
document.getElementById("bL").addEventListener("click",function(){move(-1);});
document.getElementById("bRt").addEventListener("click",function(){move(1);});
document.getElementById("bR").addEventListener("click",rot);
document.getElementById("bD").addEventListener("click",hardDrop);
document.addEventListener("keydown",function(e){
 var k=e.key;
 if(k==="ArrowLeft"){e.preventDefault();move(-1);}
 else if(k==="ArrowRight"){e.preventDefault();move(1);}
 else if(k==="ArrowDown"){e.preventDefault();step();}
 else if(k==="ArrowUp"||k===" "){e.preventDefault();rot();}});
GB.game.restart=start;
start();
})();
