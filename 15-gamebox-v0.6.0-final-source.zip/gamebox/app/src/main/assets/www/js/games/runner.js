(function(){
"use strict";
var SLUG="runner",W=360,H=520,GROUND=H-70;
var cv=document.getElementById("cv"),ctx=GB.ctx(cv,W,H);
GB.shell({title:"Dash Runner",chips:[{id:"score",label:"Score"},{id:"best",label:"Best",value:GB.best(SLUG)}],
 rules:"<ul><li><b>Tap</b> to jump. Tap again in the air for a <b>double jump</b>.</li><li><b>Swipe down</b> to duck under flying drones.</li><li>Blocks must be jumped, drones must be ducked (or jumped early).</li><li>Speed keeps rising. Score is distance in meters.</li></ul>"});
var py,vy,jumps,ducking,obstacles,speed,dist,alive,clouds,spawnT,runT;
function setChip(id,v){var e=document.getElementById(id);if(e)e.textContent=v;}
function start(){
 py=GROUND;vy=0;jumps=0;ducking=false;obstacles=[];speed=230;dist=0;alive=true;spawnT=1.1;runT=0;
 clouds=[];for(var i=0;i<5;i++)clouds.push({x:Math.random()*W,y:30+Math.random()*90,s:14+Math.random()*16,v:8+Math.random()*10});
 setChip("score",0);setChip("best",GB.best(SLUG));draw();}
function jump(){if(!alive||GB.paused)return;
 if(jumps<2){vy=-560;if(jumps===1)vy=-500;jumps++;ducking=false;GB.sfx.flip();}}
function duck(){if(!alive||GB.paused)return;
 if(py<GROUND){vy=Math.max(vy,500);}
 ducking=true;setTimeout(function(){ducking=false;},450);}
function spawn(){
 var flying=Math.random()<0.35&&dist>80;
 if(flying)obstacles.push({x:W+30,y:GROUND-88,w:34,h:22,fly:true});
 else{var w=18+Math.random()*22;obstacles.push({x:W+30,y:GROUND,w:w,h:34+Math.random()*30,fly:false});}}
function step(dt){
 clouds.forEach(function(c){c.x-=(c.v+speed*0.05)*dt;if(c.x<-40){c.x=W+40;c.y=30+Math.random()*90;}});
 if(!alive)return;
 runT+=dt;speed=230+Math.min(340,runT*9);
 dist+=speed*dt*0.06;
 var s=Math.floor(dist);setChip("score",s);
 if(s>GB.best(SLUG)){GB.saveBest(SLUG,s);setChip("best",s);}
 vy+=1650*dt;py+=vy*dt;
 if(py>=GROUND){py=GROUND;vy=0;jumps=0;}
 spawnT-=dt;
 if(spawnT<=0){spawn();spawnT=Math.max(0.55,1.15-speed*0.0009)+Math.random()*0.5;}
 obstacles.forEach(function(o){o.x-=speed*dt;});
 obstacles=obstacles.filter(function(o){return o.x>-60;});
 var ph=ducking?26:46,pw=26,px=62;
 for(var i=0;i<obstacles.length;i++){var o=obstacles[i];
  var oTop=o.fly?o.y:o.y-o.h,oBot=o.fly?o.y+o.h:o.y;
  if(px+pw>o.x+4&&px-pw<o.x+o.w-4&&py>oTop+4&&py-ph<oBot-4){
   alive=false;GB.saveBest(SLUG,Math.floor(dist));GB.sfx.die();GB.buzz(80);
   GB.gameOver({title:"Game Over",sub:"Distance: <b>"+Math.floor(dist)+"m</b> &nbsp; Best: <b>"+GB.best(SLUG)+"m</b>",onAgain:start});
   return;}}}
function rounded(x,y,w,h,r,c){ctx.fillStyle=c;ctx.beginPath();ctx.roundRect(x,y,w,h,r);ctx.fill()}
function draw(){
 var sky=ctx.createLinearGradient(0,0,0,GROUND);sky.addColorStop(0,"#1a204d");sky.addColorStop(.6,"#8b5f91");sky.addColorStop(1,"#e9b27f");ctx.fillStyle=sky;ctx.fillRect(0,0,W,H);ctx.fillStyle="#ffd9a6";ctx.beginPath();ctx.arc(278,130,40,0,7);ctx.fill();
 for(var layer=0;layer<3;layer++){var par=[.1,.22,.4][layer],bw=[52,42,35][layer];ctx.fillStyle=["#63547d","#443d68","#2e3159"][layer];for(var k=-1;k<12;k++){var x=k*bw-(dist*par*6%bw),bh=50+(k*29+layer*51+1000)%110,y=GROUND-60-bh-layer*8;ctx.fillRect(x,y,bw-3,bh+90);if(layer===1)for(var wy=y+12;wy<GROUND-55;wy+=16)for(var wx=x+7;wx<x+bw-7;wx+=11){ctx.fillStyle="#f3d29b55";ctx.fillRect(wx,wy,4,6);ctx.fillStyle="#443d68"}}}
 ctx.fillStyle="#ffffff22";clouds.forEach(function(c){ctx.beginPath();ctx.ellipse(c.x,c.y,c.s*1.8,c.s*.4,0,0,7);ctx.fill()});
 ctx.fillStyle="#191f38";ctx.fillRect(0,GROUND,W,H-GROUND);ctx.fillStyle="#e3ba75";ctx.fillRect(0,GROUND,W,5);ctx.fillStyle="#35415a";for(var gx=-((dist*40)%46);gx<W;gx+=46){ctx.fillRect(gx,GROUND+20,34,2);ctx.fillRect(gx+10,GROUND+46,34,2)}
 for(var j=0;j<4;j++){var pole=j*120-((dist*22)%120);ctx.strokeStyle="#24334e";ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(pole,GROUND);ctx.lineTo(pole,GROUND-92);ctx.lineTo(pole+20,GROUND-92);ctx.stroke();ctx.fillStyle="#ffdf9a";ctx.fillRect(pole+12,GROUND-93,15,4)}
 obstacles.forEach(function(o){if(o.fly){ctx.save();ctx.translate(o.x+o.w/2,o.y+o.h/2);rounded(-17,-9,34,18,9,"#aa476b");rounded(-10,-5,20,7,3,"#283251");ctx.fillStyle="#91e5ef";ctx.beginPath();ctx.arc(7,-2,3,0,7);ctx.fill();ctx.strokeStyle="#373750";ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(-13,-5);ctx.lineTo(-24,-12);ctx.moveTo(13,-5);ctx.lineTo(24,-12);ctx.stroke();ctx.fillStyle="#c2e6ed99";ctx.fillRect(-33,-15,22,2);ctx.fillRect(12,-15,22,2);ctx.restore()}else{rounded(o.x,o.y-o.h,o.w,o.h,3,"#ac694b");rounded(o.x+3,o.y-o.h+3,o.w-6,o.h-6,2,"#cf8e5a");ctx.strokeStyle="#744836";ctx.lineWidth=2;ctx.strokeRect(o.x+4,o.y-o.h+4,o.w-8,o.h-8);ctx.beginPath();ctx.moveTo(o.x+4,o.y-4);ctx.lineTo(o.x+o.w-4,o.y-o.h+4);ctx.moveTo(o.x+4,o.y-o.h+4);ctx.lineTo(o.x+o.w-4,o.y-4);ctx.stroke()}});
 var px=62,ph=ducking?26:46;ctx.save();ctx.translate(px,py);if(ducking)ctx.rotate(-.7);var stride=py===GROUND?Math.sin(runT*20)*10:5;ctx.strokeStyle="#1a2343";ctx.lineWidth=6;ctx.lineCap="round";ctx.beginPath();ctx.moveTo(-2,-17);ctx.lineTo(-9+stride,-2);ctx.moveTo(3,-17);ctx.lineTo(10-stride,-2);ctx.stroke();ctx.strokeStyle="#c0edf0";ctx.lineWidth=4;ctx.beginPath();ctx.moveTo(-9+stride,-1);ctx.lineTo(-3+stride,-1);ctx.moveTo(10-stride,-1);ctx.lineTo(16-stride,-1);ctx.stroke();rounded(-9,-39,20,25,6,"#31b5c1");rounded(-13,-37,6,15,3,"#22718e");ctx.strokeStyle="#e9b18c";ctx.lineWidth=5;ctx.beginPath();ctx.moveTo(7,-33);ctx.lineTo(17,-24-stride*.35);ctx.stroke();ctx.fillStyle="#e9b18c";ctx.beginPath();ctx.arc(3,-45,8,0,7);ctx.fill();ctx.fillStyle="#282941";ctx.beginPath();ctx.arc(2,-48,8,Math.PI,Math.PI*2);ctx.fill();ctx.fillStyle="#eefbfb";ctx.beginPath();ctx.arc(7,-46,2.5,0,7);ctx.fill();ctx.restore();
 ctx.fillStyle="#ffffff99";ctx.font="bold 10px sans-serif";ctx.textAlign="center";ctx.fillText("ROOFTOP RUN",W/2,24);
}
GB.loop(step,draw);
var stage=document.querySelector(".stage");
var touchY=0;stage.addEventListener("pointerdown",function(e){if(e.target.closest("button"))return;touchY=e.clientY;jump();});stage.addEventListener("pointerup",function(e){if(e.clientY-touchY>25)duck();});
document.addEventListener("keydown",function(e){
 if(e.key===" "||e.key==="ArrowUp"){e.preventDefault();jump();}
 else if(e.key==="ArrowDown"){e.preventDefault();duck();}});
GB.game.restart=start;
start();
})();
