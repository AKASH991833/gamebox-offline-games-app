(function(){
"use strict";
var SLUG="galaxy",W=360,H=560;
var cv=document.getElementById("cv"),ctx=GB.ctx(cv,W,H);
GB.shell({title:"Galaxy Guard",chips:[{id:"score",label:"Score"},{id:"best",label:"Best",value:GB.best(SLUG)},{id:"lives",label:"Lives"}],
 rules:"<ul><li><b>Drag</b> anywhere to slide your ship. It fires automatically.</li><li>Aliens drift down and shoot back. Each kill is <b>10-60</b> points by row.</li><li>You have <b>3 lives</b>. A shielded bottom edge is not part of the deal - dodge!</li><li>Clear a wave for a faster next wave. The run ends when lives run out or aliens land.</li></ul>"});
var shipX,bullets,enemyBullets,aliens,dirX,alienSpeed,fireT,score,lives,wave,alive,invuln,stars;
function setChip(id,v){var e=document.getElementById(id);if(e)e.textContent=v;}
function makeStars(){stars=[];for(var i=0;i<40;i++)stars.push({x:Math.random()*W,y:Math.random()*H,s:Math.random()*1.6+0.4,v:Math.random()*14+6});}
function makeWave(){
 aliens=[];var cols=8,rows=4+Math.min(1,wave-1);
 for(var r=0;r<rows;r++)for(var c=0;c<cols;c++)
  aliens.push({x:36+c*38,y:54+r*34,row:r,alive:true,wob:Math.random()*6});
 dirX=1;alienSpeed=22+wave*7;}
function start(){
 shipX=W/2;bullets=[];enemyBullets=[];score=0;lives=3;wave=1;fireT=0;alive=true;invuln=1.2;
 setChip("score",0);setChip("best",GB.best(SLUG));setChip("lives",lives);
 makeStars();makeWave();draw();}
function addScore(p){score+=p;setChip("score",score);GB.saveBest(SLUG,score);setChip("best",GB.best(SLUG));}
function boom(){lives--;setChip("lives",lives);GB.sfx.die();GB.buzz(70);invuln=1.6;
 if(lives<=0){alive=false;GB.saveBest(SLUG,score);
  GB.gameOver({title:"Game Over",sub:"Score: <b>"+score+"</b> &nbsp; Best: <b>"+GB.best(SLUG)+"</b>",onAgain:start});}}
function step(dt){
 stars.forEach(function(s){s.y+=s.v*dt;if(s.y>H){s.y=-4;s.x=Math.random()*W;}});
 if(!alive)return;
 if(invuln>0)invuln-=dt;
 fireT-=dt;
 if(fireT<=0){bullets.push({x:shipX,y:H-64});fireT=0.34;GB.sfx.flip();}
 bullets.forEach(function(b){b.y-=420*dt;});
 bullets=bullets.filter(function(b){return b.y>-10;});
 enemyBullets.forEach(function(b){b.y+=(150+wave*18)*dt;});
 enemyBullets=enemyBullets.filter(function(b){return b.y<H+10;});
 var minX=999,maxX=-999,any=false;
 aliens.forEach(function(a){if(a.alive){any=true;a.wob+=dt;
  if(a.x<minX)minX=a.x;if(a.x>maxX)maxX=a.x;}});
 if(any){
  var edge=false;
  if((dirX>0&&maxX>W-26)||(dirX<0&&minX<26))edge=true;
  aliens.forEach(function(a){if(!a.alive)return;
   if(edge){a.y+=18;}else{a.x+=dirX*alienSpeed*dt;}});
  if(edge)dirX*=-1;
  if(aliens.some(function(a){return a.alive&&a.y>H-90;})){alive=false;GB.saveBest(SLUG,score);GB.sfx.die();
   GB.gameOver({title:"They Landed!",sub:"Score: <b>"+score+"</b> &nbsp; Best: <b>"+GB.best(SLUG)+"</b>",onAgain:start});return;}
  if(Math.random()<dt*(0.5+wave*0.14)){
   var shooters=aliens.filter(function(a){return a.alive;});
   if(shooters.length){var s=shooters[(Math.random()*shooters.length)|0];
    enemyBullets.push({x:s.x,y:s.y+14});}}}
 bullets.forEach(function(b){
  aliens.forEach(function(a){
   if(a.alive&&Math.abs(b.x-a.x)<15&&Math.abs(b.y-a.y)<13){
    a.alive=false;b.y=-99;addScore((4-a.row+1)*10+ (a.row===0?10:0));
    GB.sfx.hit();GB.buzz(12);}});});
 enemyBullets.forEach(function(b){
  if(invuln<=0&&Math.abs(b.x-shipX)<15&&Math.abs(b.y-(H-44))<14){b.y=H+99;boom();}});
 if(aliens.every(function(a){return !a.alive;})){
  wave++;makeWave();addScore(100);GB.sfx.win();GB.toast("Wave "+wave);}}
function drawShip(){
 var y=H-44;ctx.save();ctx.translate(shipX,y);if(invuln>0)ctx.globalAlpha=.6+Math.sin(invuln*35)*.3;
 var engine=ctx.createLinearGradient(0,7,0,30);engine.addColorStop(0,"#adfaff");engine.addColorStop(.4,"#46b8f0");engine.addColorStop(1,"#4579ff00");ctx.fillStyle=engine;ctx.beginPath();ctx.moveTo(-6,8);ctx.lineTo(0,31+Math.sin(performance.now()/35)*5);ctx.lineTo(6,8);ctx.fill();
 var body=ctx.createLinearGradient(-19,0,19,0);body.addColorStop(0,"#4866aa");body.addColorStop(.4,"#d8e4f5");body.addColorStop(1,"#51648e");ctx.fillStyle=body;ctx.beginPath();ctx.moveTo(0,-21);ctx.lineTo(8,-4);ctx.lineTo(21,11);ctx.lineTo(10,8);ctx.lineTo(0,12);ctx.lineTo(-10,8);ctx.lineTo(-21,11);ctx.lineTo(-8,-4);ctx.closePath();ctx.fill();ctx.strokeStyle="#c4e5fa";ctx.lineWidth=1;ctx.stroke();ctx.fillStyle="#5ce5ed";ctx.beginPath();ctx.ellipse(0,-6,4,9,0,0,7);ctx.fill();ctx.fillStyle="#ac7fe5";ctx.fillRect(-15,4,5,3);ctx.fillRect(10,4,5,3);ctx.restore();}
function draw(){
 var bg=ctx.createLinearGradient(0,0,W,H);bg.addColorStop(0,"#0c1731");bg.addColorStop(.6,"#242348");bg.addColorStop(1,"#101d36");ctx.fillStyle=bg;ctx.fillRect(0,0,W,H);
 var neb=ctx.createRadialGradient(270,220,10,250,270,200);neb.addColorStop(0,"#8d4eb222");neb.addColorStop(1,"#6c6af000");ctx.fillStyle=neb;ctx.fillRect(0,0,W,H);ctx.fillStyle="#ffffff88";stars.forEach(function(s){ctx.fillRect(s.x,s.y,s.s,s.s)});
 ctx.save();ctx.translate(290,370);ctx.rotate(-.4);ctx.strokeStyle="#7da8c327";ctx.lineWidth=8;ctx.beginPath();ctx.ellipse(0,0,58,12,0,0,7);ctx.stroke();var planet=ctx.createRadialGradient(-10,-10,3,0,0,30);planet.addColorStop(0,"#34536c");planet.addColorStop(1,"#142842");ctx.fillStyle=planet;ctx.beginPath();ctx.arc(0,0,30,0,7);ctx.fill();ctx.restore();
 var cols=["#df7297","#e6a76a","#ded278","#6cd6b7","#72b5e8"];
 aliens.forEach(function(a){if(!a.alive)return;var wob=Math.sin(a.wob*4)*2;ctx.save();ctx.translate(a.x,a.y+wob);ctx.shadowColor=cols[a.row%5];ctx.shadowBlur=5;ctx.fillStyle="#28334e";ctx.beginPath();ctx.moveTo(-13,-3);ctx.lineTo(-7,-10);ctx.lineTo(7,-10);ctx.lineTo(13,-3);ctx.lineTo(10,9);ctx.lineTo(-10,9);ctx.closePath();ctx.fill();ctx.strokeStyle=cols[a.row%5];ctx.lineWidth=2;ctx.stroke();ctx.shadowBlur=0;ctx.fillStyle=cols[a.row%5];ctx.beginPath();ctx.ellipse(0,-2,9,5,0,0,7);ctx.fill();ctx.fillStyle="#15243c";ctx.fillRect(-6,-3,12,2);ctx.fillStyle="#c2fbfd";ctx.fillRect(-4,-3,2,2);ctx.fillRect(2,-3,2,2);ctx.strokeStyle=cols[a.row%5];ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(-10,6);ctx.lineTo(-15,12);ctx.moveTo(10,6);ctx.lineTo(15,12);ctx.stroke();ctx.restore()});
 ctx.shadowBlur=7;ctx.shadowColor="#a9fdff";ctx.fillStyle="#b7faff";bullets.forEach(function(b){ctx.fillRect(b.x-1.5,b.y-10,3,12)});ctx.shadowColor="#fa75b9";ctx.fillStyle="#f78ba6";enemyBullets.forEach(function(b){ctx.beginPath();ctx.ellipse(b.x,b.y,3,5,0,0,7);ctx.fill()});ctx.shadowBlur=0;if(alive)drawShip();ctx.fillStyle="#b8c9e2";ctx.font="bold 12px sans-serif";ctx.fillText("WAVE "+wave,12,H-14);
}
GB.loop(step,draw);
GB.dragX(document.querySelector(".gm-wrap"),W,function(x){shipX=Math.max(16,Math.min(W-16,x));});
document.addEventListener("keydown",function(e){
 if(GB.paused||!alive)return;
 if(e.key==="ArrowLeft"){e.preventDefault();shipX=Math.max(16,shipX-16);}
 else if(e.key==="ArrowRight"){e.preventDefault();shipX=Math.min(W-16,shipX+16);}});
GB.game.restart=start;
start();
})();
