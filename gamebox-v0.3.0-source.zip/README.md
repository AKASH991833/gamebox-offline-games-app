# GameBox - Offline Games App

12 classic games in one tiny (~64 KB) Android app. 100% offline, no ads, no accounts, no internet permission.

## v0.2.0 (24 Oct 2026)

Quality upgrade across all 12 games:

- **Proper navigation**: every game has a header with Home, Pause, Sound and How-to-Play. Pause menu offers Resume / Restart / Home. Games auto-pause when you leave the app.
- **Performance**: all action games run on a delta-time game loop (smooth at any refresh rate) with devicePixelRatio-crisp canvas rendering. Screen stays awake while playing.
- **Better games**:
  - Snake Rush - smooth interpolated movement, speeds up as you eat
  - 2048 - sliding tile animations, merge effects, Undo
  - Tic Tac Toe - Vs Computer (Easy/Normal/Hard with minimax) or 2 Players, win streaks
  - Memory Match - 3D flip cards, memorize preview, timer + move scoring
  - Mine Sweeper - first tap always safe, long-press to flag
  - Brick Breaker - levels, particle effects, angle control off the paddle
  - Flappy Dot - parallax clouds, medals at 10/20/30
  - Sudoku - Easy/Medium/Hard with unique-solution generator, smart highlighting
  - Tower Stack - perfect-drop bonuses, sliced overhangs
  - Mole Smash - 30s timer bar, golden moles, combo multiplier
  - Beat Echo - real tones per pad, faster every 5 rounds
  - Paddle Clash - first to 7, rally speed-up
- Sound effects (tiny synthesized WebAudio, mutable) and haptics on supported devices.
- Dark and light themes. All best scores saved locally on-device.

## Games
2048, Snake Rush, Tic Tac Toe, Memory Match, Mine Sweeper, Brick Breaker, Flappy Dot, Sudoku, Tower Stack, Mole Smash, Beat Echo, Paddle Clash

## Tech
Native Android (minSdk 24 / Android 7.0+) shell hosting a hardware-accelerated WebView. Games are vanilla HTML/CSS/JS in `app/src/main/assets/www` - no frameworks, no bundler.

Build: `gradle assembleRelease` (AGP 7.4.2, Gradle 7.6.4). v0.2.0 is signed with the same key as v0.1.0, so it installs as an upgrade and keeps saved scores.
