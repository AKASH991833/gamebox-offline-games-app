(function(){
"use strict";
var SLUG="mole";
GB.shell({title:"Mole Smash",chips:[{id:"score",label:"Score"},{id:"best",label:"Best",value:GB.best(SLUG)}],
 rules:"<ul><li>You have <b>30 seconds</b> - tap every mole that pops up.</li><li>Normal mole: <b>+1</b>. Golden mole: <b>+5</b>.</li><li>Hit 5 in a row without a miss to start a <b>2x combo</b>.</li><li>The pace quickens as your score grows.</li></ul>"});
var holesEl=document.getElementById("holes"),statusEl=document.getElementById("status");
var score,combo,playing=false,secs,popWait,timeLeft,goldFlags,remaining=[];
var cells=[];
function setChip(id,v){var e=document.getElementById(id);if(e)e.textContent=v;}
for(var i=0;i<9;i++){(function(i){
 var h=document.createElement("div");h.className="hole";
 h.innerHTML='<div class="mole">'+GB.icon("face")+"</div>";
 h.addEventListener("pointerdown",function(){whack(i);});
 holesEl.appendChild(h);cells.push(h);})(i);}
function whack(i){
 if(GB.paused)return;
 if(!playing||!cells[i].classList.contains("up"))return;
 var gold=goldFlags[i];
 cells[i].classList.remove("up");cells[i].classList.add("hit");
 cells[i].querySelector(".mole").innerHTML=GB.icon(gold?"star":"burst");
 setTimeout(function(){cells[i].classList.remove("hit");
  cells[i].querySelector(".mole").innerHTML=GB.icon("face");},220);
 combo++;var mult=combo>=5?2:1,pts=(gold?5:1)*mult;
 score+=pts;setChip("score",score);
 GB.sfx.point();GB.buzz(gold?30:12);
 if(combo===5)GB.toast("Combo x2!");}
function pop(){
 if(!playing)return;
 var i=(Math.random()*9)|0;
 if(cells[i].classList.contains("up")){popWait=.15;return;}
 goldFlags[i]=Math.random()<0.12;
 cells[i].classList.toggle("gold",goldFlags[i]);
 cells[i].querySelector(".mole").innerHTML=GB.icon("face");
 cells[i].classList.add("up");remaining[i]=Math.max(.42,.82-score*.006);
 popWait=Math.max(.28,.64-score*.004);}
function start(){
 document.getElementById("startBtn").textContent="Round running";document.getElementById("startBtn").disabled=true;
 score=0;combo=0;secs=30;timeLeft=30;popWait=0;playing=true;goldFlags={};remaining=new Array(9).fill(0);
 cells.forEach(function(c){c.classList.remove("up","hit","gold")});
 setChip("score",0);document.getElementById("tfill").style.width="100%";
 statusEl.textContent="Go! 30s left";}
GB.loop(function(dt){if(!playing)return;timeLeft-=dt;secs=Math.max(0,Math.ceil(timeLeft));document.getElementById("tfill").style.width=(Math.max(0,timeLeft)/30*100)+"%";statusEl.textContent="Go! "+secs+"s left";
 if(timeLeft<=0){end();return}for(var i=0;i<9;i++){if(remaining[i]>0){remaining[i]-=dt;if(remaining[i]<=0){if(cells[i].classList.contains("up"))combo=0;cells[i].classList.remove("up")}}}popWait-=dt;if(popWait<=0)pop();});
function end(){
 playing=false;
 document.getElementById("startBtn").textContent="Start";document.getElementById("startBtn").disabled=false;
 cells.forEach(function(c){c.classList.remove("up")});
 GB.saveBest(SLUG,score);setChip("best",GB.best(SLUG));GB.buzz(70);
 statusEl.textContent="Tap Start to play again!";
 GB.gameOver({title:"Time Up!",won:score>0&&score>=GB.best(SLUG),
  sub:"Score: <b>"+score+"</b> &nbsp; Best: <b>"+GB.best(SLUG)+"</b>",onAgain:start});}
document.getElementById("startBtn").addEventListener("click",function(){GB.sfx.tap();if(!playing)start();});
GB.game.restart=start;
setChip("best",GB.best(SLUG));
})();
