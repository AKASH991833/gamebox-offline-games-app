(function(){
"use strict";
var GAMES=[
{slug:"defense",name:"Circuit Keep",cat:"Action"},
{slug:"golf",name:"Pocket Greens",cat:"Sports"},
{slug:"pinball",name:"Orbit Pinball",cat:"Arcade"},
{slug:"lander",name:"Moon Dock",cat:"Action"},
{slug:"arena",name:"Neon Outpost",cat:"Action"},
{slug:"carrom",name:"Carrom Studio",cat:"Board"},
{slug:"cricket",name:"Boundary Nights",cat:"Sports"},
{slug:"classic-ludo",name:"Ludo",cat:"Board",url:"classics/ludo.html?lang=en"},
{slug:"classic-chess",name:"Chess",cat:"Board",url:"classics/chess.html?lang=en"},
{slug:"classic-snakesladders",name:"Snakes and Ladders",cat:"Board",url:"classics/snakesladders.html?lang=en"},
{slug:"classic-domino",name:"Dominoes",cat:"Board",url:"classics/domino.html?lang=en"},
{slug:"classic-checkers",name:"Checkers",cat:"Board",url:"classics/checkers.html?lang=en"},
{slug:"classic-reversi",name:"Reversi",cat:"Board",url:"classics/reversi.html?lang=en"},
{slug:"classic-backgammon",name:"Backgammon",cat:"Board",url:"classics/backgammon.html?lang=en"},
{slug:"classic-mancala",name:"Mancala",cat:"Board",url:"classics/mancala.html?lang=en"},
{slug:"classic-baghchal",name:"Tigers and Goats",cat:"Board",url:"classics/baghchal.html?lang=en"},
{slug:"classic-morris",name:"Nine Men's Morris",cat:"Board",url:"classics/morris.html?lang=en"},
{slug:"classic-go",name:"Go",cat:"Board",url:"classics/go.html?lang=en"},
{slug:"classic-gomoku",name:"Five in a Row",cat:"Board",url:"classics/gomoku.html?lang=en"},
{slug:"classic-hex",name:"Hex",cat:"Board",url:"classics/hex.html?lang=en"},
{slug:"classic-dotsandboxes",name:"Dots and Boxes",cat:"Board",url:"classics/dotsandboxes.html?lang=en"},
{slug:"classic-sternhalma",name:"Chinese Checkers",cat:"Board",url:"classics/sternhalma.html?lang=en"},
{slug:"classic-ur",name:"Royal Game of Ur",cat:"Board",url:"classics/ur.html?lang=en"},
{slug:"classic-klondike",name:"Klondike Solitaire",cat:"Cards",url:"classics/klondike.html?lang=en"},
{slug:"classic-spidersolitaire",name:"Spider Solitaire",cat:"Cards",url:"classics/spidersolitaire.html?lang=en"},
{slug:"classic-freecell",name:"FreeCell",cat:"Cards",url:"classics/freecell.html?lang=en"},
{slug:"classic-pyramidsolitaire",name:"Pyramid Solitaire",cat:"Cards",url:"classics/pyramidsolitaire.html?lang=en"},
{slug:"classic-maumau",name:"Crazy Eights",cat:"Cards",url:"classics/maumau.html?lang=en"},
{slug:"classic-oldmaid",name:"Old Maid",cat:"Cards",url:"classics/oldmaid.html?lang=en"},
{slug:"classic-war",name:"Card War",cat:"Cards",url:"classics/war.html?lang=en"},
{slug:"classic-nonogram",name:"Nonogram",cat:"Puzzle",url:"classics/nonogram.html?lang=en"},
{slug:"classic-mahjong",name:"Mahjong Solitaire",cat:"Puzzle",url:"classics/mahjong.html?lang=en"},
{slug:"classic-kakuro",name:"Kakuro",cat:"Puzzle",url:"classics/kakuro.html?lang=en"},
{slug:"classic-calcudoku",name:"Calcudoku",cat:"Puzzle",url:"classics/calcudoku.html?lang=en"},
{slug:"classic-futoshiki",name:"Futoshiki",cat:"Puzzle",url:"classics/futoshiki.html?lang=en"},
{slug:"classic-pegsolitaire",name:"Peg Solitaire",cat:"Puzzle",url:"classics/pegsolitaire.html?lang=en"},
{slug:"classic-cratepusher",name:"Crate Pusher",cat:"Puzzle",url:"classics/cratepusher.html?lang=en"},
{slug:"classic-hashi",name:"Bridges",cat:"Puzzle",url:"classics/hashi.html?lang=en"},
{slug:"classic-slitherlink",name:"Loop Puzzle",cat:"Puzzle",url:"classics/slitherlink.html?lang=en"},
{slug:"classic-skyscrapers",name:"Skyscrapers",cat:"Puzzle",url:"classics/skyscrapers.html?lang=en"},
{slug:"classic-tangram",name:"Tangram",cat:"Puzzle",url:"classics/tangram.html?lang=en"},
{slug:"classic-linkpairs",name:"Link Pairs",cat:"Puzzle",url:"classics/linkpairs.html?lang=en"},
{slug:"classic-bullsandcows",name:"Bulls and Cows",cat:"Puzzle",url:"classics/bullsandcows.html?lang=en"},
{slug:"classic-fleetbattle",name:"Fleet Battle",cat:"Board",url:"classics/fleetbattle.html?lang=en"},
{slug:"classic-fanorona",name:"Fanorona",cat:"Board",url:"classics/fanorona.html?lang=en"},
{slug:"classic-halma",name:"Halma",cat:"Board",url:"classics/halma.html?lang=en"},
{slug:"classic-hnefatafl",name:"Viking Tafl",cat:"Board",url:"classics/hnefatafl.html?lang=en"},
{slug:"classic-konane",name:"Konane",cat:"Board",url:"classics/konane.html?lang=en"},
{slug:"classic-surakarta",name:"Surakarta",cat:"Board",url:"classics/surakarta.html?lang=en"},
{slug:"classic-tablut",name:"Tablut",cat:"Board",url:"classics/tablut.html?lang=en"},
{slug:"classic-seega",name:"Seega",cat:"Board",url:"classics/seega.html?lang=en"},
{slug:"classic-alquerque",name:"Alquerque",cat:"Board",url:"classics/alquerque.html?lang=en"},
{slug:"classic-foxandgeese",name:"Fox and Geese",cat:"Board",url:"classics/foxandgeese.html?lang=en"},
{slug:"classic-pentomino",name:"Pentomino",cat:"Puzzle",url:"classics/pentomino.html?lang=en"},
{slug:"classic-mathcross",name:"Math Cross",cat:"Puzzle",url:"classics/mathcross.html?lang=en"},
{slug:"classic-matches",name:"Matchstick Puzzles",cat:"Puzzle",url:"classics/matches.html?lang=en"},
{slug:"classic-noneighbors",name:"No Neighbors",cat:"Puzzle",url:"classics/noneighbors.html?lang=en"},
{slug:"classic-tenpairs",name:"Number Pairs",cat:"Puzzle",url:"classics/tenpairs.html?lang=en"},
{slug:"classic-arrows",name:"Arrow Paths",cat:"Puzzle",url:"classics/arrows.html?lang=en"},
{slug:"classic-rings",name:"Ring Puzzle",cat:"Puzzle",url:"classics/rings.html?lang=en"},
{slug:"classic-shapesort",name:"Shape Sort",cat:"Puzzle",url:"classics/shapesort.html?lang=en"},
{slug:"classic-shadowmatch",name:"Shadow Match",cat:"Puzzle",url:"classics/shadowmatch.html?lang=en"},
{slug:"classic-oddone",name:"Odd One Out",cat:"Puzzle",url:"classics/oddone.html?lang=en"},
 {slug:"2048",    name:"2048",         cat:"Puzzle"},
 {slug:"snake",   name:"Snake Rush",   cat:"Arcade"},
 {slug:"tictactoe",name:"Tic Tac Toe", cat:"Puzzle"},
 {slug:"memory",  name:"Memory Match", cat:"Puzzle"},
 {slug:"mines",   name:"Mine Sweeper", cat:"Puzzle"},
 {slug:"breakout",name:"Brick Breaker",cat:"Arcade"},
 {slug:"flappy",  name:"Flappy Dot",   cat:"Arcade"},
 {slug:"sudoku",  name:"Sudoku",       cat:"Puzzle"},
 {slug:"stack",   name:"Tower Stack",  cat:"Arcade"},
 {slug:"mole",    name:"Mole Smash",   cat:"Action"},
 {slug:"simon",   name:"Beat Echo",    cat:"Action"},
 {slug:"pong",    name:"Paddle Clash", cat:"Action"},
 {slug:"blocks",  name:"Block Drop",   cat:"Puzzle"},
 {slug:"galaxy",  name:"Galaxy Guard", cat:"Arcade"},
 {slug:"runner",  name:"Dash Runner",  cat:"Arcade"},
 {slug:"racer",   name:"Road Rush",    cat:"Arcade"},
 {slug:"crossy",  name:"Crossy Dash",  cat:"Arcade"},
 {slug:"bubbles", name:"Bubble Pop",   cat:"Arcade"},
 {slug:"targets", name:"Target Tap",   cat:"Action"},
 {slug:"maze",    name:"Maze Run",     cat:"Puzzle"},
 {slug:"connect4",name:"Connect Four", cat:"Puzzle"},
 {slug:"fifteen", name:"Slide 15",     cat:"Puzzle"},
 {slug:"lightsout",name:"Lights Out",  cat:"Puzzle"},
 {slug:"wordguess",name:"Word Guess",  cat:"Puzzle"}
];
var $=function(s){return document.querySelector(s)};
var store={
  get:function(k,d){try{var v=localStorage.getItem("gb_"+k);return v===null?d:JSON.parse(v)}catch(e){return d}},
  set:function(k,v){try{localStorage.setItem("gb_"+k,JSON.stringify(v))}catch(e){}}
};
/* theme */
function applyTheme(){var qp=new URLSearchParams(location.search).get("theme");if(qp==="light"||qp==="dark")store.set("theme",qp);document.documentElement.setAttribute("data-theme",store.get("theme","dark"));}
applyTheme();
$("#themeBtn").addEventListener("click",function(){
  store.set("theme",store.get("theme","dark")==="dark"?"light":"dark");applyTheme();
});
/* favorites */
var favs=store.get("favs",{});
function saveFavs(){store.set("favs",favs);}
var tab="all",search="",category="";
$("#searchInput").addEventListener("input",function(){search=this.value.trim().toLowerCase();render();});
$("#categorySelect").addEventListener("change",function(){category=this.value;render();});
function heartSvg(on){return '<svg viewBox="0 0 24 24" class="ic"><path d="M12 21C7 16.5 3 13.1 3 9.3 3 6.4 5.2 4.5 7.7 4.5c1.7 0 3.3.9 4.3 2.4 1-1.5 2.6-2.4 4.3-2.4 2.5 0 4.7 1.9 4.7 4.8 0 3.8-4 7.2-9 11.7z" fill="'+(on?'currentColor':'none')+'" stroke="currentColor" stroke-width="2"/></svg>';}
function render(){
  var grid=$("#grid");grid.innerHTML="";
  var list=GAMES.filter(function(g){return (tab==="all"||favs[g.slug]) && (!search || g.name.toLowerCase().indexOf(search)>=0) && (!category || g.cat===category);});
  $("#emptyFav").classList.toggle("hidden",!(tab==="fav"&&list.length===0));
  list.forEach(function(g){
    var card=document.createElement("div");card.className="card";card.tabIndex=0;card.setAttribute("role","link");card.setAttribute("aria-label","Play "+g.name);card.addEventListener("keydown",function(e){if(e.target===card&&(e.key==="Enter"||e.key===" ")){e.preventDefault();location.href=g.url||("games/"+g.slug+".html");}});card.style.animationDelay=(Math.min(list.indexOf(g),8)*0.015)+"s";
    var img=document.createElement("img");img.className="cover";img.alt=g.name;img.loading="lazy";img.decoding="async";img.src="icons/"+g.slug+".svg";
    var fav=document.createElement("button");fav.className="fav-btn"+(favs[g.slug]?" on":"");fav.innerHTML=heartSvg(!!favs[g.slug]);fav.setAttribute("aria-label",(favs[g.slug]?"Remove favorite ":"Favorite ")+g.name);
    fav.addEventListener("click",function(e){e.stopPropagation();favs[g.slug]=!favs[g.slug];if(!favs[g.slug])delete favs[g.slug];saveFavs();render();});
    var nm=document.createElement("div");nm.className="name";nm.textContent=g.name;
    var ct=document.createElement("div");ct.className="cat";ct.textContent=g.cat;
    card.appendChild(img);card.appendChild(fav);card.appendChild(nm);card.appendChild(ct);
    card.addEventListener("click",function(){location.href=g.url||("games/"+g.slug+".html");});
    grid.appendChild(card);
  });
}
$("#tabAll").addEventListener("click",function(){tab="all";$("#tabAll").classList.add("active");$("#tabFav").classList.remove("active");render();});
$("#tabFav").addEventListener("click",function(){tab="fav";$("#tabFav").classList.add("active");$("#tabAll").classList.remove("active");render();});
/* share + no ads */
$("#shareBtn").addEventListener("click",function(){
  var text="GameBox - 87 offline games in one tiny app. No internet needed, no ads!";
  if(window.AndroidBridge&&AndroidBridge.share){AndroidBridge.share(text);}
  else if(navigator.clipboard){navigator.clipboard.writeText(text);note("Share text copied");}
  else{note(text);}
});
$("#noadsBtn").addEventListener("click",function(){note("100% free. No ads, no internet needed.");});
function note(msg){
  if(window.AndroidBridge&&AndroidBridge.toast){AndroidBridge.toast(msg);return;}
  var t=document.createElement("div");t.textContent=msg;
  t.style.cssText="position:fixed;left:50%;bottom:100px;transform:translateX(-50%);background:var(--pill);color:var(--text);padding:10px 18px;border-radius:999px;font-size:13px;z-index:99;border:1px solid var(--pill-border)";
  document.body.appendChild(t);setTimeout(function(){t.remove()},2000);
}
/* scores */
$("#trophyBtn").addEventListener("click",function(){
  var list=$("#scoresList");list.innerHTML="";
  GAMES.forEach(function(g){
    var v=store.get("best_"+g.slug,null);
    var row=document.createElement("div");row.className="score-row";
    row.innerHTML='<img src="icons/'+g.slug+'.svg" alt=""><div class="sn">'+g.name+'</div><div class="sv'+(v===null?" none":"")+'">'+(v===null?"Not played":v)+'</div>';
    list.appendChild(row);
  });
  $("#scoresOverlay").classList.remove("hidden");
});
$("#scoresClose").addEventListener("click",function(){$("#scoresOverlay").classList.add("hidden");});
$("#scoresOverlay").addEventListener("click",function(e){if(e.target===this)this.classList.add("hidden");});
render();
})();
