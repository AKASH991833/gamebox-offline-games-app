(function(){
"use strict";
var SLUG="racer",W=300,H=480,LANES=3,laneW=W/LANES;
var cv=document.getElementById("cv"),ctx=GB.ctx(cv,W,H);
GB.shell({title:"Road Rush",chips:[{id:"score",label:"Score"},{id:"best",label:"Best",value:GB.best(SLUG)}],
 rules:"<ul><li><b>Swipe</b> or tap the left/right half to change lanes.</li><li>Dodge traffic. Each coin is <b>+25</b> points; distance adds up on its own.</li><li>Traffic gets faster and denser the longer you survive.</li><li>One crash ends the run.</li></ul>"});
var lane,playerX,cars,coins,speed,dist,alive,spawnT,coinT,roadT,coinBonus,lastShown;
function setChip(id,v){var e=document.getElementById(id);if(e)e.textContent=v;}
function laneX(l){return l*laneW+laneW/2;}
function start(){
 lane=1;playerX=laneX(1);cars=[];coins=[];speed=200;dist=0;alive=true;spawnT=0.9;coinT=1.6;roadT=0;coinBonus=0;lastShown=-1;
 setChip("score",0);setChip("best",GB.best(SLUG));draw();}
function shift(d){if(!alive||GB.paused)return;var nl=Math.max(0,Math.min(LANES-1,lane+d));
 if(nl!==lane){lane=nl;GB.sfx.flip();}}
function spawnCar(){
 var used=cars.filter(function(c){return c.y<140;}).map(function(c){return c.lane;});
 var free=[0,1,2].filter(function(l){return used.indexOf(l)<0;});
 if(!free.length)return;
 var l=free[(Math.random()*free.length)|0];
 cars.push({lane:l,y:-70,w:laneW*0.52,h:64,speed:speed*(0.55+Math.random()*0.2),
  color:["#F43F5E","#60A5FA","#FACC15","#C084FC"][(Math.random()*4)|0]});}
function step(dt){
 roadT+=dt;
 if(!alive)return;
 speed=200+Math.min(260,dist*0.5);
 dist+=speed*dt*0.02;
 var tot=Math.floor(dist)+coinBonus;
 if(tot!==lastShown){lastShown=tot;setChip("score",tot);
  if(tot>GB.best(SLUG)){GB.saveBest(SLUG,tot);setChip("best",tot);}}
 playerX+=(laneX(lane)-playerX)*Math.min(1,dt*14);
 spawnT-=dt;if(spawnT<=0){spawnCar();spawnT=Math.max(0.5,1.05-dist*0.004)+Math.random()*0.4;}
 coinT-=dt;if(coinT<=0){coins.push({lane:(Math.random()*3)|0,y:-20,taken:false});coinT=1.4+Math.random();}
 cars.forEach(function(c){c.y+=(speed-c.speed*0.35)*dt;});
 cars=cars.filter(function(c){return c.y<H+80;});
 coins.forEach(function(c){c.y+=speed*dt;});
 coins=coins.filter(function(c){return c.y<H+30&&!c.taken;});
 coins.forEach(function(c){
  if(!c.taken&&c.lane===lane&&Math.abs(c.y-(H-70))<40){c.taken=true;coinBonus+=25;GB.sfx.point();GB.buzz(12);}});
 for(var i=0;i<cars.length;i++){var c=cars[i];
  if(Math.abs(laneX(c.lane)-playerX)<(c.w+laneW*.5)/2-6&&Math.abs(c.y-(H-70))<(c.h+52)/2-8){
   alive=false;var t2=Math.floor(dist)+coinBonus;GB.saveBest(SLUG,t2);GB.sfx.die();GB.buzz(80);
   GB.gameOver({title:"Crash!",sub:"Score: <b>"+t2+"</b> &nbsp; Best: <b>"+GB.best(SLUG)+"</b>",onAgain:start});
   return;}}}
function rounded(x,y,w,h,r,col){ctx.fillStyle=col;ctx.beginPath();ctx.roundRect(x,y,w,h,r);ctx.fill();}
function drawCar(x,y,w,h,color){
 ctx.save();ctx.translate(x,y);ctx.shadowColor="#080c1b99";ctx.shadowBlur=5;ctx.shadowOffsetY=5;
 rounded(-w/2-3,-h*.31,6,h*.23,2,"#111621");rounded(w/2-3,-h*.31,6,h*.23,2,"#111621");rounded(-w/2-3,h*.2,6,h*.23,2,"#111621");rounded(w/2-3,h*.2,6,h*.23,2,"#111621");
 var body=ctx.createLinearGradient(-w/2,0,w/2,0);body.addColorStop(0,"#28334a");body.addColorStop(.18,color);body.addColorStop(.48,color);body.addColorStop(1,"#1b2942");rounded(-w/2,-h/2,w,h,9,body);ctx.shadowBlur=0;ctx.shadowOffsetY=0;
 rounded(-w*.33,-h*.19,w*.66,h*.36,5,color);var glass=ctx.createLinearGradient(0,-h*.22,0,h*.05);glass.addColorStop(0,"#b3e1e8");glass.addColorStop(1,"#283e58");rounded(-w*.34,-h*.24,w*.68,h*.18,3,glass);rounded(-w*.31,h*.19,w*.62,h*.12,3,"#1c3049");
 line(-w*.28,-h*.4,w*.28,-h*.4,"#ffffff66",1);line(-w*.3,h*.36,w*.3,h*.36,"#070c2277",1);
 rounded(-w*.38,-h*.45,w*.2,4,2,"#fff3bf");rounded(w*.18,-h*.45,w*.2,4,2,"#fff3bf");rounded(-w*.38,h*.4,w*.2,3,1,"#ff4e70");rounded(w*.18,h*.4,w*.2,3,1,"#ff4e70");ctx.restore();}
function line(x,y,a,b,col,w){ctx.strokeStyle=col;ctx.lineWidth=w;ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(a,b);ctx.stroke()}
function draw(){
 var bg=ctx.createLinearGradient(0,0,W,H);bg.addColorStop(0,"#174c54");bg.addColorStop(1,"#0b293c");ctx.fillStyle=bg;ctx.fillRect(0,0,W,H);
 ctx.fillStyle="#263548";ctx.fillRect(14,0,W-28,H);ctx.fillStyle="#ffffff04";for(var k=0;k<12;k++)ctx.fillRect(18+k*23,0,1,H);
 var off=(roadT*speed)%44;for(var y=-44+off;y<H;y+=44){ctx.fillStyle="#eae6c9";ctx.fillRect(10,y,5,22);ctx.fillRect(W-15,y,5,22);ctx.fillStyle="#e65d6b";ctx.fillRect(10,y+22,5,22);ctx.fillRect(W-15,y+22,5,22)}
 for(var l=1;l<LANES;l++)for(var y=-44+off;y<H;y+=44){ctx.fillStyle="#b8c8ca88";ctx.fillRect(l*laneW-1.5,y,3,22)}
 for(var j=0;j<6;j++){var ty=(j*98+roadT*speed*.65)%590-60;ctx.fillStyle="#175648";ctx.beginPath();ctx.arc(2,ty,12,0,7);ctx.arc(W-2,ty+30,13,0,7);ctx.fill();ctx.fillStyle="#2a7560";ctx.beginPath();ctx.arc(1,ty-3,7,0,7);ctx.arc(W-2,ty+27,8,0,7);ctx.fill()}
 coins.forEach(function(c){var p=1+Math.sin(performance.now()/180)*.08;ctx.shadowColor="#ecc76d55";ctx.shadowBlur=10;ctx.fillStyle="#e1a832";ctx.beginPath();ctx.arc(laneX(c.lane),c.y,10*p,0,7);ctx.fill();ctx.shadowBlur=0;ctx.strokeStyle="#ffe8a2";ctx.lineWidth=2;ctx.beginPath();ctx.arc(laneX(c.lane),c.y,7*p,0,7);ctx.stroke();ctx.fillStyle="#fff0b1";ctx.font="bold 11px sans-serif";ctx.textAlign="center";ctx.fillText("+",laneX(c.lane),c.y+4)});
 cars.forEach(function(c){drawCar(laneX(c.lane),c.y,c.w,c.h,c.color)});drawCar(playerX,H-70,laneW*.5,64,"#4ddbb4");
 var vignette=ctx.createLinearGradient(0,0,0,H);vignette.addColorStop(0,"#071a3c88");vignette.addColorStop(.2,"#071a3c00");vignette.addColorStop(1,"#071a3c44");ctx.fillStyle=vignette;ctx.fillRect(0,0,W,H);ctx.fillStyle="#d9e7e9aa";ctx.font="bold 10px sans-serif";ctx.textAlign="center";ctx.fillText("NIGHT DRIVE",W/2,22);
}
GB.loop(step,draw);
var sx=0,activePointer=false;cv.addEventListener("pointerdown",function(e){if(GB.paused)return;activePointer=true;sx=e.clientX;cv.setPointerCapture(e.pointerId)});cv.addEventListener("pointerup",function(e){if(!activePointer)return;activePointer=false;var dx=e.clientX-sx,r=cv.getBoundingClientRect();if(Math.abs(dx)>20)shift(dx>0?1:-1);else shift(e.clientX-r.left>r.width/2?1:-1)});
document.addEventListener("keydown",function(e){
 if(e.key==="ArrowLeft"){e.preventDefault();shift(-1);}
 else if(e.key==="ArrowRight"){e.preventDefault();shift(1);}});
GB.game.restart=start;
start();
cv.addEventListener("pointercancel",function(){activePointer=false});GB.onPauseChange(function(){activePointer=false});
})();
