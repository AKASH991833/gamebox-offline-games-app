(function(){
"use strict";
var SLUG="mole";
GB.shell({title:"Mole Smash",chips:[{id:"score",label:"Score"},{id:"best",label:"Best",value:GB.best(SLUG)}],
 rules:"<ul><li>You have <b>30 seconds</b> - tap every mole that pops up.</li><li>Normal mole: <b>+1</b>. Golden mole: <b>+5</b>.</li><li>Hit 5 in a row without a miss to start a <b>2x combo</b>.</li><li>The pace quickens as your score grows.</li></ul>"});
var holesEl=document.getElementById("holes"),statusEl=document.getElementById("status");
var score,combo,playing=false,secs,popTimer,clockTimer,goldFlags;
var cells=[];
function setChip(id,v){var e=document.getElementById(id);if(e)e.textContent=v;}
for(var i=0;i<9;i++){(function(i){
 var h=document.createElement("div");h.className="hole";
 h.innerHTML='<div class="mole">\u{1F439}</div>';
 h.addEventListener("touchstart",function(e){e.preventDefault();whack(i);},{passive:false});
 h.addEventListener("mousedown",function(){whack(i);});
 holesEl.appendChild(h);cells.push(h);})(i);}
function whack(i){
 if(!playing||!cells[i].classList.contains("up"))return;
 var gold=goldFlags[i];
 cells[i].classList.remove("up");cells[i].classList.add("hit");
 cells[i].querySelector(".mole").textContent=gold?"\u{2B50}":"\u{1F4A5}";
 setTimeout(function(){cells[i].classList.remove("hit");
  cells[i].querySelector(".mole").textContent=goldFlags[i]?"\u{1F430}":"\u{1F439}";},220);
 combo++;var mult=combo>=5?2:1,pts=(gold?5:1)*mult;
 score+=pts;setChip("score",score);
 GB.sfx.point();GB.buzz(gold?30:12);
 if(combo===5)GB.toast("Combo x2!");}
function pop(){
 if(!playing)return;
 var i=(Math.random()*9)|0;
 if(cells[i].classList.contains("up")){popTimer=setTimeout(pop,150);return;}
 goldFlags[i]=Math.random()<0.12;
 cells[i].classList.toggle("gold",goldFlags[i]);
 cells[i].querySelector(".mole").textContent=goldFlags[i]?"\u{1F430}":"\u{1F439}";
 cells[i].classList.add("up");
 var upMs=Math.max(420,820-score*6);
 setTimeout(function(){if(cells[i].classList.contains("up")){combo=0;}
  cells[i].classList.remove("up");},upMs);
 popTimer=setTimeout(pop,Math.max(280,640-score*4));}
function start(){
 score=0;combo=0;secs=30;playing=true;goldFlags={};
 setChip("score",0);
 document.getElementById("tfill").style.width="100%";
 statusEl.textContent="Go! 30s left";
 pop();
 clockTimer=setInterval(function(){
  if(GB.paused)return;
  secs--;document.getElementById("tfill").style.width=(secs/30*100)+"%";
  statusEl.textContent="Go! "+secs+"s left";
  if(secs<=0)end();},1000);}
function end(){
 playing=false;clearTimeout(popTimer);clearInterval(clockTimer);
 cells.forEach(function(c){c.classList.remove("up")});
 GB.saveBest(SLUG,score);setChip("best",GB.best(SLUG));GB.buzz(70);
 statusEl.textContent="Tap Start to play again!";
 GB.gameOver({title:"Time Up!",won:score>0&&score>=GB.best(SLUG),
  sub:"Score: <b>"+score+"</b> &nbsp; Best: <b>"+GB.best(SLUG)+"</b>",onAgain:start});}
document.getElementById("startBtn").addEventListener("click",function(){GB.sfx.tap();if(!playing)start();});
GB.game.restart=function(){if(!playing)start();};
GB.onPauseChange(function(p){
 if(p){clearTimeout(popTimer);}
 else if(playing){popTimer=setTimeout(pop,300);}});
setChip("best",GB.best(SLUG));
})();
